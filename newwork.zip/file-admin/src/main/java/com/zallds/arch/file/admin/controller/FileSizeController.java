package com.zallds.arch.file.admin.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zallds.arch.file.admin.base.annotatio.AoData;
import com.zallds.arch.file.admin.base.controller.BaseController;
import com.zallds.arch.file.admin.base.page.Page;
import com.zallds.arch.file.admin.base.vo.BootStrapFormVo;
import com.zallds.arch.file.admin.dao.IFileDao;
import com.zallds.arch.file.client.vo.AppInfoVo;
import com.zallds.arch.file.client.vo.FileGroupVo;
import com.zallds.arch.file.client.vo.FileSizeVo;



/**
* @ClassName: AppInfoController
* @Description: TODO(这里用一句话描述这个类的作用)
* @author yedengchu
* @date 2017年2月13日 下午3:56:45
*
*/
@Controller
@RequestMapping("/fileSize")
public class FileSizeController extends BaseController{ 
	private static final Logger log = LoggerFactory.getLogger(FileSizeController.class);
	@Autowired
	IFileDao fileDao;
	@RequestMapping("/init.do")
	public String init(HttpServletRequest request, HttpServletResponse response, Map<String, Object> model) {
		    AppInfoVo appInfo=new AppInfoVo();
	        List<AppInfoVo> appInfos=fileDao.selectListD("app.qryAllAppInfos",appInfo);
	        model.put("appInfos", appInfos);
	        return "file/fileSize";
		
	}
	/**
	 * 查询应用信息
	 * 
	 * @throws Exception
	 */
	@RequestMapping("/qryAllFileSizes.do")
	public void getAllAppInfos(HttpServletRequest request, HttpServletResponse response, Map<String, Object> model,@AoData BootStrapFormVo aoData) {
		try {
			int pageNumber = aoData.getPage(); // request.getParameter("page");
			int pageSize = aoData.getRows();
			FileGroupVo groupInfo=new FileGroupVo();
			if (StringUtils.isNotBlank(aoData.getSearch())) {
				groupInfo.setCode(aoData.getSearch());
			}
			Page pageQuery=fileDao.pageQuery("fileSize.qryAllFileSizesCount", "fileSize.qryAllFileSizes", groupInfo, pageNumber, pageSize);
			HashMap<String, Object> retMap = new HashMap<String, Object>();
			retMap.put("aaData", pageQuery.getResult());
			retMap.put("sEcho", aoData.getsEcho() + 1);
			retMap.put("iTotalRecords",pageQuery.getTotalCount());
			retMap.put("iTotalDisplayRecords",pageQuery.getTotalCount());
			writeJSON(response, retMap);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@ResponseBody
	@RequestMapping("/save.do")
	public Object save(HttpServletRequest request, HttpServletResponse response,FileSizeVo fileSizeVo){
		String createId=(String)request.getSession().getAttribute("userId");
		fileSizeVo.setCreateId(createId);
		fileSizeVo.setIsDeleted(0);
		fileDao.insert("fileSize.addFileSize", fileSizeVo);
		return "ok";
	}
	@ResponseBody
	@RequestMapping("/update.do")
   public Object update(HttpServletRequest request, HttpServletResponse response,FileSizeVo fileSizeVo){
		String updateId=(String)request.getSession().getAttribute("userId");
		fileSizeVo.setUpdateId(updateId);
		fileDao.update("fileSize.updateFileSizeById", fileSizeVo);
	   return "ok";
	}
	@ResponseBody
	@RequestMapping("/delete.do")
   public Object delete(HttpServletRequest request, HttpServletResponse response,FileSizeVo fileSizeVo){
		String updateId=(String)request.getSession().getAttribute("userId");
		fileSizeVo.setUpdateId(updateId);
		fileDao.update("fileSize.deleteFileSizeById", fileSizeVo);
	   return "ok";
	}
	@RequestMapping("/getFileSizesByAppCode.do")
	public void getParentCatalogs(HttpServletRequest request, HttpServletResponse response, Map<String, Object> model,String appCode) {
	        List<String> groupCodes=fileDao.selectList("fileSize.getFileSizesByAppCode",appCode);
	        model=new HashMap<String, Object>();
	        model.put("data", groupCodes);
	        try {
				writeJSON(response, model);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	public IFileDao getFileDao() {
		return fileDao;
	}
	public void setFileDao(IFileDao fileDao) {
		this.fileDao = fileDao;
	}
	
}
