/**
 * Page.java
 * 
 * Copyright(C)2008 Founder Corporation.
 * written by Founder Corp.
 */
package com.zallds.arch.file.admin.base.page;

/**
 * [类名]<br>
 * Page<br>
 * [功能概要]<br>
 * <br>
 * <br>
 * [変更履歴]<br>
 * 2009-3-24 ver1.00 新建 zhaoxinsheng<br>
 * 
 * @author FOUNDER CORPORATION
 * @version 1.00
 */
public interface Page {
    /**
     * 默认每页容量
     */
    int DEFAULT_PAGE_SIZE = 10;

    /**
     * 取得记录总数.
     * 
     * @return 记录总数
     */
    long getTotalCount();

    /**
     * 取得总页数.
     * 
     * @return 总页数
     */
    long getTotalPageCount();

    /**
     * 取每页数据容量.
     * 
     * @return 每页数据容量
     */
    int getPageSize();

    /**
     * 取当前页中的记录.
     * 
     * @return 前页中的记录
     */
    Object getResult();

    /**
     * @param data
     *            the data to set
     */
    void setData(Object data);

    /**
     * 取该页当前页,页码号.
     * 
     * @return 页当前页,页码号
     */
    long getCurrentPageNo();

    /**
     * 取该页当前开始数.
     * 
     * @return 页当前开始数
     */
    long getStart();

    /**
     * 该页是否有下一页.
     * 
     * @return 该页是否有下一页
     */
    boolean hasNextPage();

    /**
     * 该页是否有上一页.
     * 
     * @return 该页是否有上一页
     */
    boolean hasPreviousPage();

    /**
     * 取得首页页码号
     * 
     * @return 首页页码号
     */
    long getFirstPage();

    /**
     * 取得上一页页码号
     * 
     * @return 上一页页码号
     */
    long getPreviousPage();

    /**
     * 取得下一页页码号
     * 
     * @return 下一页页码号
     */
    long getNextPage();

    /**
     * 取得末页页码号
     * 
     * @return 末页页码号
     */
    long getLastPage();

}
