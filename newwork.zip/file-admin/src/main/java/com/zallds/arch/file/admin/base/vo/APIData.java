package com.zallds.arch.file.admin.base.vo;

/**
 * API数据对象
 * 
 * @author zongjin
 * 
 *         2015-12-2
 */
public class APIData {

	// 状态码
	private Integer code;

	// 提示信息
	private String info;

	// 数据
	private Object data;

	/**
	 * 获取状态码
	 * 
	 * @return 状态码
	 */
	public Integer getCode() {
		return code;
	}

	/**
	 * 设置状态码
	 * 
	 * @param code
	 *            状态码
	 */
	public void setCode(Integer code) {
		this.code = code;
	}

	/**
	 * 获取提示信息
	 * 
	 * @return 提示信息
	 */
	public String getInfo() {
		return info;
	}

	/**
	 * 设置提示信息
	 * 
	 * @param info
	 *            提示信息
	 */
	public void setInfo(String info) {
		this.info = info;
	}

	/**
	 * 获取数据
	 * 
	 * @return 数据
	 */
	public Object getData() {
		return data;
	}

	/**
	 * 设置数据
	 * 
	 * @param data
	 *            数据
	 */
	public void setData(Object data) {
		this.data = data;
	}
}
