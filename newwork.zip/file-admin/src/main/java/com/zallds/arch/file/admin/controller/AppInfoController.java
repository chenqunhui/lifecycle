package com.zallds.arch.file.admin.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zallds.arch.file.admin.base.annotatio.AoData;
import com.zallds.arch.file.admin.base.controller.BaseController;
import com.zallds.arch.file.admin.base.page.Page;
import com.zallds.arch.file.admin.base.vo.BootStrapFormVo;
import com.zallds.arch.file.admin.dao.IFileDao;
import com.zallds.arch.file.client.vo.AppInfoVo;



/**
* @ClassName: AppInfoController
* @Description: TODO(这里用一句话描述这个类的作用)
* @author yedengchu
* @date 2017年2月13日 下午3:56:45
*
*/
@Controller
@RequestMapping("/app")
public class AppInfoController extends BaseController{
	private static final Logger log = LoggerFactory.getLogger(AppInfoController.class);
	@Autowired
	IFileDao fileDao;
	/**
	 * 查询应用信息
	 * 
	 * @throws Exception
	 */
	@RequestMapping("/qryAllAppInfos.do")
	public void getAllAppInfos(HttpServletRequest request, HttpServletResponse response, Map<String, Object> model,@AoData BootStrapFormVo aoData) {
		try {
			int pageNumber = aoData.getPage(); // request.getParameter("page");
			int pageSize = aoData.getRows();
			AppInfoVo appInfo=new AppInfoVo();
			if (StringUtils.isNotBlank(aoData.getSearch())) {
				appInfo.setName(aoData.getSearch());
			}
			Page pageQuery=fileDao.pageQuery("app.qryAllAppInfosCount", "app.qryAllAppInfos", appInfo, pageNumber, pageSize);
			HashMap<String, Object> retMap = new HashMap<String, Object>();
			retMap.put("aaData", pageQuery.getResult());
			retMap.put("sEcho", aoData.getsEcho() + 1);
			retMap.put("iTotalRecords",pageQuery.getTotalCount());
			retMap.put("iTotalDisplayRecords",pageQuery.getTotalCount());
			writeJSON(response, retMap);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@ResponseBody
	@RequestMapping("/save.do")
	public Object save(HttpServletRequest request, HttpServletResponse response,AppInfoVo appInfo){
		String createId=(String)request.getSession().getAttribute("userId");
		appInfo.setCreateId(createId);
		appInfo.setIsDeleted(0);
		fileDao.insert("app.addAppInfo", appInfo);
		return "ok";
	}
	@ResponseBody
	@RequestMapping("/update.do")
   public Object update(HttpServletRequest request, HttpServletResponse response,AppInfoVo appInfo){
		String updateId=(String)request.getSession().getAttribute("userId");
		appInfo.setUpdateId(updateId);
		fileDao.update("app.updateAppInfoById", appInfo);
	   return "ok";
	}
	@ResponseBody
	@RequestMapping("/delete.do")
   public Object delete(HttpServletRequest request, HttpServletResponse response,AppInfoVo appInfo){
		String updateId=(String)request.getSession().getAttribute("userId");
		appInfo.setUpdateId(updateId);
		fileDao.update("app.deleteAppInfoById", appInfo);
	   return "ok";
	}
	public IFileDao getFileDao() {
		return fileDao;
	}
	public void setFileDao(IFileDao fileDao) {
		this.fileDao = fileDao;
	}
	
}
