package com.zallds.arch.file.admin.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
* @ClassName: DateUtil
* @Description: TODO(这里用一句话描述这个类的作用)
* @author yedengchu
* @date 2017年2月21日 下午2:41:56
*
*/
public class DateUtil {

 public static String dateFormatFromNow(String dateFormat){
	  SimpleDateFormat formatter=new SimpleDateFormat(dateFormat); 
	 return  formatter.format(new Date());
 }
}
