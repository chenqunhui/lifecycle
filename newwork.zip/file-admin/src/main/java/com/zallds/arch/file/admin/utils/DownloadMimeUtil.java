package com.zallds.arch.file.admin.utils;

import java.util.HashMap;
import java.util.Map;

import org.springframework.security.web.header.writers.frameoptions.StaticAllowFromStrategy;

/**
* @ClassName: DownloadMimeUtil
* @Description: TODO(这里用一句话描述这个类的作用)
* @author yedengchu
* @date 2017年3月15日 下午4:35:53
*
*/
public class DownloadMimeUtil {
private static Map<String,String> mimeTypes=new HashMap<String,String>();
static{
	mimeTypes.put("txt", "text/plain");
	mimeTypes.put("doc", "application/msword");
	mimeTypes.put("docx", "application/msword");
	mimeTypes.put("xls", "application/vnd.ms-excel");
	mimeTypes.put("xlsx", "application/vnd.ms-excel");
	mimeTypes.put("ppt", "vnd.ms-powerpoint");
	mimeTypes.put("pptx", "vnd.ms-powerpoint");
	mimeTypes.put("zip", "application/zip");
	mimeTypes.put("gif", "image/gif");
	mimeTypes.put("png", "image/png ");
	mimeTypes.put("xml", "application/xml");
	mimeTypes.put("html", "text/html");
	mimeTypes.put("htm", "text/html");
	mimeTypes.put("hml", "text/html");
}
public static String getMimeTypeByExt(String ext){
	if(mimeTypes.containsKey(ext)){
		return mimeTypes.get(ext);
	}else{
		return null;
	}
}
}
