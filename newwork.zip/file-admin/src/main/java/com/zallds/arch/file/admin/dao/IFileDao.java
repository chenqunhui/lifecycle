package com.zallds.arch.file.admin.dao;

import com.zallds.arch.file.admin.base.dao.IBaseDao;

/**
* @ClassName: ICommonDao
* @Description: TODO(这里用一句话描述这个类的作用)
* @author yedengchu
* @date 2017年2月13日 上午10:42:27
*
*/
public interface IFileDao extends IBaseDao {

}
