package com.zallds.arch.file.admin.base.vo;

import java.io.Serializable;

/**
* @ClassName: BootStrapFormVo
* @Description: TODO(这里用一句话描述这个类的作用)
* @author yedengchu
* @date 2016年11月3日 上午9:14:04
*
*/
public class BootStrapFormVo implements Serializable {
	/**
	* @Fields serialVersionUID : TODO(用一句话描述这个变量表示什么)
	*/ 
	private static final long serialVersionUID = -6537841966740525057L;
	Integer page = 0;
	Integer sEcho = 0;
	Integer rows = 0;
	String search = "";
	
	/**
	* <p>Title: </p>
	* <p>Description: </p>
	*/ 
	public BootStrapFormVo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getPage() {
		return page;
	}
	public void setPage(Integer page) {
		this.page = page;
	}
	public Integer getsEcho() {
		return sEcho;
	}
	public void setsEcho(Integer sEcho) {
		this.sEcho = sEcho;
	}
	public Integer getRows() {
		return rows;
	}
	public void setRows(Integer rows) {
		this.rows = rows;
	}
	public String getSearch() {
		return search;
	}
	public void setSearch(String search) {
		this.search = search;
	}
	
}
