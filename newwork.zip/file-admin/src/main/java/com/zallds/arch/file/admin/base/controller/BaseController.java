package com.zallds.arch.file.admin.base.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.zallds.arch.file.admin.base.vo.APIData;
import com.zallds.arch.file.admin.utils.JsonUtils;

import net.sf.json.JSONObject;


/**
 * 基础Action
 * 
 * @author founder
 * 
 * 更新历史：
 * 1.2012-6-12 增加page和rows两个属性，用于jQuery EasyUI分页控件。——李宗锦
 * 2.2015-12-12 增加isLogined 方法，用于验证用户是否已经登陆。——吕超
 * 
 */
@Controller
public abstract class BaseController  {
	
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 345498243316974623L;

	protected final Log logger = LogFactory.getLog(BaseController.class);


	/**
	 * redis 操作对象
	 */
//	@Autowired
//	private RedisCacheUtil redisCacheManager;
	/**
	 *  开启验证用户是否已登陆开关(供测试时使用)，临时以变量设置，后续需加入配置文件当中
	 */
	private boolean isCheckLogined = false;
	
	/**
	 * 路径列表
	 */
	protected Map<String, String> pathMap = new HashMap<String, String>();
	
	/**
	 * 请求数据
	 */
	protected String param;
	
	/**
	 * 数据对象
	 */
	protected Map<String, Object> dataMap = new HashMap<String, Object>();
	
	/**
	 * jQuery EasyUI 分页控件页码参数
	 */
	protected String page = "1";
	
	/**
	 * jQuery EasyUI 分页控件每页至多显示数
	 */
	protected String rows = "20";

	public String ulId;
	
	public String liId;
	
	public String getUlId() {
		return ulId;
	}

	public void setUlId(String ulId) {
		this.ulId = ulId;
	}

	public String getLiId() {
		return liId;
	}

	public void setLiId(String liId) {
		this.liId = liId;
	}

	/**
	 * 将字符串写入到response
	 * 
	 * @param text
	 * @throws Exception
	 */
	protected void writeText(HttpServletResponse response,String text) throws Exception {
		response.setContentType("text/html;charset=UTF-8");
		response.getWriter().write(text);
	}

	/**
	 * 将JSON对象写入到response
	 * 
	 * @param jsonObject
	 * @throws Exception
	 */
	protected void writeJSON(HttpServletResponse response,Object jsonObject) throws Exception {
		Gson gson = new Gson();
		String result = gson.toJson(jsonObject);
		response.setContentType("application/json;charset=UTF-8");
		response.getWriter().write(result);
	}
	/**
	 * 将JSON对象写入到response
	 * 
	 * @param jsonObject
	 * @throws Exception
	 */
	protected void writeJSONFromMap(HttpServletResponse response,Map<String,Object> model) throws Exception {
		String retSring = JsonUtils.toJson(model);
		try {
			response.setCharacterEncoding("UTF-8");
			response.getWriter().print(retSring);
			response.getWriter().flush();
			response.getWriter().close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * 判断用户是否在免登录时间范围内
	 * 
	 * @throws Exception
	 */
	protected boolean checkLogined() throws Exception {
		//验证用户是否登陆
		if(isCheckLogined){
			//访问用户ID
//			String memberId = (String)dataMap.get("memberId");
			//访问pcode
//			String pCode = (String)dataMap.get("pcode");
			//取出redis存储对应的redis
//			String redisPcode = (String)redisCacheManager.get(memberId);
//			//如果访问用户ID、pcode不为空，且接口列表中pcode与redis中存储一致，则验证通过
//			if(redisPcode!=null && pCode!=null && pCode.equals(redisPcode)){
//				return true;
//			}
			return false;
		}
		return true;
	}
	
	
	/**
	 * 将JSON对象写入到response
	 * 
	 * @param jsonObject
	 * @throws Exception
	 */
	protected void writeJSONP(HttpServletRequest request,HttpServletResponse response,Object jsonObject) throws Exception {
		String callback = request.getParameter("callback");
		Gson gson = new Gson();
		String result = gson.toJson(jsonObject);
		response.setContentType("application/json;charset=UTF-8");
		response.getWriter().write(callback + "(" + result + ")");
	}
	
	/**
	 * 将数据对象写入到response
	 * 
	 * @param jsonObject
	 * @throws Exception
	 */
	protected void writeData(HttpServletResponse response,Object dataObject, int code,String errMsg) throws Exception {
		Gson gson = new Gson();  
		final APIData apiData = new APIData();
		apiData.setCode(code);
		if(errMsg!=null && !"".equals(errMsg)) {
			apiData.setInfo(errMsg);
		} else {
			//apiData.setInfo(getText(String.valueOf(code)));
		}
		apiData.setData(dataObject);
		String result = gson.toJson(apiData);

		response.setContentType("application/json;charset=UTF-8");
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.getWriter().write(result);
	}
	
	/**
	 * 将数据对象写入到response(重写) -- 添加一个日期格式化String
	 * 
	 * @param jsonObject
	 * @throws Exception
	 */
	protected void writeData(HttpServletResponse response,Object dataObject, int code,String msgKey , String dateFormat) throws Exception {
		String format = dateFormat;
		if(format == null){
			format = "yyyy-MM-dd";
		}
		Gson gson = new GsonBuilder()  
		  .setDateFormat(format)  
		  .create();  
		final APIData apiData = new APIData();
		apiData.setCode(code);
		//apiData.setInfo(getText(String.valueOf(code)));
		apiData.setData(dataObject);
		String result = gson.toJson(apiData);

		response.setContentType("application/json;charset=UTF-8");
		response.getWriter().write(result);
	}
	
	/**
	 * 将数据对象写入到response
	 * 
	 * @param jsonObject
	 * @throws Exception
	 */
	protected void writeJsonData(HttpServletResponse response,Object dataObject, int code,String msgKey) throws Exception {
		final APIData apiData = new APIData();
		apiData.setCode(code);
		//apiData.setInfo(getText(String.valueOf(code)));
		apiData.setData(dataObject); 
		String result = JSONObject.fromObject(apiData).toString();
		response.setContentType("application/json;charset=UTF-8");
		response.getWriter().write(result);
	}
			
	/**
    * 对给定字符进行 URL 解码
    * 
    * @param value
    *            String
    * @return String
    */
    public String decode(String value) {
        String result = "";
        if (!isEmpty(value)) {
            try {
                result = java.net.URLDecoder.decode(value, "UTF-8");
                result = java.net.URLDecoder.decode(result, "UTF-8");
            } catch (UnsupportedEncodingException ex) {

            }
        }
        return result;
    }

    /**
    * 对给定字符进行 URL 编码
    * 
    * @param value
    *            String
    * @return String
    */
    public String encode(String value) {
        String result = "";
        if (!isEmpty(value)) {
            try {
                result = java.net.URLEncoder.encode(value, "UTF-8");
                result = java.net.URLEncoder.encode(result, "UTF-8");
            } catch (UnsupportedEncodingException ex) {

            }
        }
        return result;
    }
    public boolean isEmpty(String value) {
        if (null == value || "".equals(value.trim()))
            return true;
        else
            return false;
    }
    
    /**
	 * 获取登录用户ID（仅用于基于Session登录机制的场景）
	 */
	protected String getSessionUser(HttpServletRequest request) throws Exception {
		
		final Object userId = request.getSession().getAttribute("userId");
		return null != userId ? userId.toString() : null;
	}
	

	
	/**
	 * 获取用户ip
	 * @return
	 */
	protected String getIpAddr(HttpServletRequest request) {
		String ipAddress = null;
		ipAddress = request.getHeader("x-forwarded-for");
		if (ipAddress == null || ipAddress.length() == 0
				|| "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getHeader("Proxy-Client-IP");
		}
		if (ipAddress == null || ipAddress.length() == 0
				|| "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ipAddress == null || ipAddress.length() == 0
				|| "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getRemoteAddr();
			if (ipAddress.equals("127.0.0.1")) {
				// 根据网卡取本机配置的IP
				InetAddress inet = null;
				try {
					inet = InetAddress.getLocalHost();
				} catch (UnknownHostException e) {
					e.printStackTrace();
				}
				ipAddress = inet.getHostAddress();
			}

		}

		// 对于通过多个代理的情况，第一个IP为客户端真实IP,多个IP按照','分割
		if (ipAddress != null && ipAddress.length() > 15) {
			// "***.***.***.***".length() = 15
			if (ipAddress.indexOf(",") > 0) {
				ipAddress = ipAddress.substring(0, ipAddress.indexOf(","));
			}
		}
		return ipAddress;
	}
	    
	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getRows() {
		return rows;
	}

	public void setRows(String rows) {
		this.rows = rows;
	}
	public Map<String, String> getPathMap() {
		return pathMap;
	}

	public void setPathMap(Map<String, String> pathMap) {
		this.pathMap = pathMap;
	}

	public String getParam() {
		return param;
	}

	public void setParam(String param) {
		this.param = param;
	}

	public Map<String, Object> getDataMap() {
		return dataMap;
	}

	public void setDataMap(Map<String, Object> dataMap) {
		this.dataMap = dataMap;
	}
}
