package com.zallds.arch.file.admin.base.dao;

import java.util.List;

import com.zallds.arch.file.admin.base.page.Page;

/**
* @ClassName: IBaseDao
* @Description: TODO(这里用一句话描述这个类的作用)
* @author yedengchu
* @date 2017年2月13日 上午10:33:40
*
*/
public 	interface IBaseDao {
	public <T> void insert(String sqlName,T argObject);
	public <T> T select(String sqlName,T argObject);
	public <T,K> T selectD(String sqlName,K argObject);
	public <T> List<T> selectList(String sqlName,T argObject);
	public <T,K> List<T> selectListD(String sqlName,K argObject);
	public <T> void delete(String sqlName,T argObject);
	public <T> void update(String sqlName,T argObject);
	/**
	 * @param countKey
	 *            查询该表所有记录行的SQL语句ID
	 * @param sqlKey
	 *            需要查询记录的SQL语句ID
	 * @param param
	 *            传递给查询语句的参数
	 * @param pageNo
	 *            需要查询的实际页
	 * @param pageSize
	 *            每页记录行数
	 * @return page对象
	 */
	public Page pageQuery(String countKey, String sqlKey, Object param, Integer pageNo, Integer pageSize);

}
