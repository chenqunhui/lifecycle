package com.zallds.arch.file.admin.base.annotatio.resolver;
import org.apache.commons.lang.StringUtils;
import org.springframework.core.MethodParameter;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.zallds.arch.file.admin.base.annotatio.AoData;
import com.zallds.arch.file.admin.base.vo.BootStrapFormVo;
/**
* @ClassName: BootStrapArgumentsResolver
* @Description: TODO(这里用一句话描述这个类的作用)
* @author yedengchu
* @date 2016年11月3日 上午9:52:27
*
*/
public class BootStrapArgumentsResolver implements HandlerMethodArgumentResolver {

	/*
	 * @see org.springframework.web.method.support.HandlerMethodArgumentResolver#supportsParameter(org.springframework.core.MethodParameter)
	 */
	  /**
     * 解析器是否支持当前参数
     */
	@Override
	public boolean supportsParameter(MethodParameter parameter) {
		// 指定参数如果被应用MyParam注解，则使用该解析器。
        // 如果直接返回true，则代表将此解析器用于所有参数
		 return parameter.hasParameterAnnotation(AoData.class);
		
	}

	/*
	 * @see org.springframework.web.method.support.HandlerMethodArgumentResolver#resolveArgument(org.springframework.core.MethodParameter, org.springframework.web.method.support.ModelAndViewContainer, org.springframework.web.context.request.NativeWebRequest, org.springframework.web.bind.support.WebDataBinderFactory)
	 */
	 /**
     * 将request中的请求参数解析到当前Controller参数上
     * @param parameter 需要被解析的Controller参数，此参数必须首先传给{@link #supportsParameter}并返回true
     * @param mavContainer 当前request的ModelAndViewContainer
     * @param webRequest 当前request
     * @param binderFactory 生成{@link WebDataBinder}实例的工厂
     * @return 解析后的Controller参数
     */
	@Override
	public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer,
			NativeWebRequest webRequest, WebDataBinderFactory binderFactory) throws Exception {
		 String jsonString=webRequest.getParameter(parameter.getParameterName());
		 Object object=parameter.getParameterType().newInstance();
		 int start=0;
		 int pageSize=1;
		 if(StringUtils.isEmpty(jsonString)){
				((BootStrapFormVo)object).setsEcho(1);
				((BootStrapFormVo)object).setSearch("");
				((BootStrapFormVo)object).setRows(10);
				((BootStrapFormVo)object).setPage(1);
		 }else{
		 JSONArray ja = (JSONArray) JSONArray.parse(jsonString);
			for (int i = 0; i < ja.size(); i++) {
				JSONObject obj = (JSONObject) ja.get(i);
				if (obj.get("name").equals("sEcho"))
					((BootStrapFormVo)object).setsEcho((Integer) obj.get("value"));
				if (obj.get("name").equals("iDisplayStart"))
					 start=(Integer) obj.get("value");
				if (obj.get("name").equals("iDisplayLength"))
					pageSize=(Integer) obj.get("value");
					((BootStrapFormVo)object).setRows(pageSize);
				if (obj.get("name").equals("sSearch"))
					((BootStrapFormVo)object).setSearch(obj.getString("value"));
			}
			int pageNo=(start/pageSize)+1;
			((BootStrapFormVo)object).setPage(pageNo);
		 }
	    return object;
	}
	
}
