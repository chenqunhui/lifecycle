package com.zallds.arch.file.admin.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zallds.arch.file.admin.base.annotatio.AoData;
import com.zallds.arch.file.admin.base.controller.BaseController;
import com.zallds.arch.file.admin.base.page.Page;
import com.zallds.arch.file.admin.base.vo.BootStrapFormVo;
import com.zallds.arch.file.admin.dao.IFileDao;
import com.zallds.arch.file.client.vo.AppInfoVo;
import com.zallds.arch.file.client.vo.FileCataLogVo;



/**
* @ClassName: AppInfoController
* @Description: TODO(这里用一句话描述这个类的作用)
* @author yedengchu
* @date 2017年2月13日 下午3:56:45
*
*/
@Controller
@RequestMapping("/catalog")
public class CataLogController extends BaseController{
	private static final Logger log = LoggerFactory.getLogger(CataLogController.class);
	@Autowired
	IFileDao fileDao;
	@RequestMapping("/init.do")
	public String init(HttpServletRequest request, HttpServletResponse response, Map<String, Object> model) {
		    AppInfoVo appInfo=new AppInfoVo();
	        List<AppInfoVo> appInfos=fileDao.selectListD("app.qryAllAppInfos",appInfo);
	        model.put("appInfos", appInfos);
	        return "file/catalog";
		
	}
	@RequestMapping("/getParentCatalogs.do")
	public void getParentCatalogs(HttpServletRequest request, HttpServletResponse response, Map<String, Object> model,FileCataLogVo cataLogVo) {
	        List<FileCataLogVo> cataLogVos=fileDao.selectListD("catalog.getParentCatalogs",cataLogVo);
	        model=new HashMap<String, Object>();
	        model.put("data", cataLogVos);
	        try {
				writeJSON(response, model);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	/**
	 * 查询应用信息
	 * 
	 * @throws Exception
	 */
	@RequestMapping("/qryAllCatalogs.do")
	public void qryAllCatalogs(HttpServletRequest request, HttpServletResponse response, Map<String, Object> model,@AoData BootStrapFormVo aoData) {
		try {
			int pageNumber = aoData.getPage(); // request.getParameter("page");
			int pageSize = aoData.getRows();
			FileCataLogVo catalog=new FileCataLogVo();
			if (StringUtils.isNotBlank(aoData.getSearch())) {
				catalog.setName(aoData.getSearch());
			}
			Page pageQuery=fileDao.pageQuery("catalog.qryAllCatalogsCount", "catalog.qryAllCatalogs", catalog, pageNumber, pageSize);
			HashMap<String, Object> retMap = new HashMap<String, Object>();
			retMap.put("aaData", pageQuery.getResult());
			retMap.put("sEcho", aoData.getsEcho() + 1);
			retMap.put("iTotalRecords",pageQuery.getTotalCount());
			retMap.put("iTotalDisplayRecords",pageQuery.getTotalCount());
			writeJSON(response, retMap);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@ResponseBody
	@RequestMapping("/save.do")
	public Object save(HttpServletRequest request, HttpServletResponse response,FileCataLogVo catalog){
		String createId=(String)request.getSession().getAttribute("userId");
		catalog.setCreateId(createId);
		catalog.setIsDeleted(0);
		fileDao.insert("catalog.addCatalog", catalog);
		return "ok";
	}
	@ResponseBody
	@RequestMapping("/update.do")
   public Object update(HttpServletRequest request, HttpServletResponse response,FileCataLogVo catalog){
		String updateId=(String)request.getSession().getAttribute("userId");
		catalog.setUpdateId(updateId);
		fileDao.update("catalog.updateCatalogById", catalog);
	   return "ok";
	}
	@ResponseBody
	@RequestMapping("/delete.do")
   public Object delete(HttpServletRequest request, HttpServletResponse response,FileCataLogVo catalog){
		String updateId=(String)request.getSession().getAttribute("userId");
		catalog.setUpdateId(updateId);
		fileDao.update("catalog.deleteCatalogById", catalog);
	   return "ok";
	}
	public IFileDao getFileDao() {
		return fileDao;
	}
	public void setFileDao(IFileDao fileDao) {
		this.fileDao = fileDao;
	}
	
}
