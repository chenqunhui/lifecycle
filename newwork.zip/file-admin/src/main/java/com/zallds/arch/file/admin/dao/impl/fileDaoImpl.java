package com.zallds.arch.file.admin.dao.impl;


import com.zallds.arch.file.admin.base.dao.impl.BaseDaoImpl;
import com.zallds.arch.file.admin.dao.IFileDao;

/**
* @ClassName: CommonDaoImpl
* @Description: TODO(这里用一句话描述这个类的作用)
* @author yedengchu
* @date 2017年2月13日 上午10:43:44
*
*/
public class fileDaoImpl extends BaseDaoImpl implements IFileDao {


}
