package com.zallds.arch.file.admin.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.zallds.architecture.portal.service.IApplicationInfoQryService;
import com.zallds.architecture.portal.vo.AppModule;
import com.zallds.architecture.portal.vo.AppRole;

/**
* @ClassName: ApplicationInfoQryServiceImpl
* @Description: TODO(这里用一句话描述这个类的作用)
* @author yedengchu
* @date 2016年11月29日 下午2:09:05
*
*/
public class ApplicationInfoQryServiceImpl implements IApplicationInfoQryService {
	/*
	 * @see com.zallds.architecture.portal.service.IApplicationInfoQryService#qryAppRoles()
	 */ 
	@Override
	public List<AppRole> qryAppRoles() {
		List<AppRole> appRoles=new ArrayList<AppRole>(2);
		AppRole appRole1=new AppRole();
		appRole1.setRoleCode(AppRoleEnum.ADMIN.getRoleCode());
		appRole1.setName(AppRoleEnum.ADMIN.getName());
		appRole1.setIsDefault(0);
		appRoles.add(appRole1);
		AppRole appRole2=new AppRole();
		appRole2.setRoleCode(AppRoleEnum.USER.getRoleCode());
		appRole2.setName(AppRoleEnum.USER.getName());
		appRole2.setIsDefault(0);
		appRoles.add(appRole2);
		return appRoles;
	}

	/*
	 * @see com.zallds.architecture.portal.service.IApplicationInfoQryService#qryAppRoleModules(java.util.List)
	 */
	@Override
	public List<AppModule> qryAppRoleModules(String roleCode) {
	 if(StringUtils.isNotBlank(roleCode)){
		 List<AppModule> appModules=new ArrayList<AppModule>();
		 if(AppRoleEnum.USER.getRoleCode().equals(roleCode)){
				  AppModule appModule=AppModuleEnum.FILE_MANAGE.convertToAppModule();
				  appModules.add(appModule);
				  appModule=AppModuleEnum.APP_MANAGE.convertToAppModule();
				  appModules.add(appModule);
				  appModule=AppModuleEnum.CATEGORY_MANAGE.convertToAppModule();
				  appModules.add(appModule);
				  appModule=AppModuleEnum.GROUP_MANAGE.convertToAppModule();
				  appModules.add(appModule);
				  appModule=AppModuleEnum.FILE_SIZE_MANAGE.convertToAppModule();
				  appModules.add(appModule);
			  }else if(AppRoleEnum.ADMIN.getRoleCode().equals(roleCode)){
				  AppModule appModule=AppModuleEnum.FILE_MANAGE.convertToAppModule();
				  appModules.add(appModule);
				  appModule=AppModuleEnum.APP_MANAGE.convertToAppModule();
				  appModules.add(appModule);
				  appModule=AppModuleEnum.CATEGORY_MANAGE.convertToAppModule();
				  appModules.add(appModule);
				  appModule=AppModuleEnum.GROUP_MANAGE.convertToAppModule();
				  appModules.add(appModule);
				  appModule=AppModuleEnum.FILE_SIZE_MANAGE.convertToAppModule();
				  appModules.add(appModule);
				  appModule=AppModuleEnum.FILE_UPLOAD_MANAGE.convertToAppModule();
				  appModules.add(appModule);
				  appModule=AppModuleEnum.FILE_UPLOAD_TEST.convertToAppModule();
				  appModules.add(appModule);
				  appModule=AppModuleEnum.FILE_SELECT_TEST.convertToAppModule();
				  appModules.add(appModule);

		   }
		  return appModules;
	  } 

	 return null;
	}

	/*
	 * @see com.zallds.architecture.portal.service.IApplicationInfoQryService#qryAppSelfModules(java.lang.String)
	 */
	@Override
	public List<AppModule> qryAppSelfModules(String userId,String roleCodes) {
		 List<AppModule> appModules=new ArrayList<AppModule>();
//		if(StringUtils.isNotBlank(roleCodes)){
//			String[] roleArr=roleCodes.split(",");
//			if(roleArr!=null&&roleArr.length>0){
//				if(roleArr[0].equals(AppRoleEnum.ADMIN.getRoleCode())){
//					AppModule appModule=AppModuleEnum.SYS_MANAGE.convertToAppModule();
//					  appModules.add(appModule);
//					  List<AppModule> subModules=new ArrayList<AppModule>(2);
//					  AppModule appModule1=AppModuleEnum.APP_MANAGE.convertToAppModule();
//					  subModules.add(appModule1);
//					  AppModule appModule2=AppModuleEnum.POOL_MANAGE.convertToAppModule();
//					  subModules.add(appModule2);
//					  appModule.setSubModules(subModules);
//				}
//			}
//		}
		 return  appModules;
	}

}
enum AppRoleEnum{
	SUPER("超级管理员","super"),
	ADMIN("管理员","admin"),USER("普通用户","user");
	private String name;
	private String roleCode;
	/**
	* <p>Title: </p>
	* <p>Description: </p>
	* @param name
	* @param roleCode
	*/ 
	private AppRoleEnum(String name, String roleCode) {
		this.name = name;
		this.roleCode = roleCode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	
}
enum AppModuleEnum{
	FILE_MANAGE("0","1","","文件管理",0,""),
	APP_MANAGE("1","2","http://fadmin.zallds.com/jsp/file/appInfo.jsp","应用管理",1,""),
	CATEGORY_MANAGE("1","3","http://fadmin.zallds.com/catalog/init.do","文件目录管理",1,""),
	GROUP_MANAGE("1","4","http://fadmin.zallds.com/group/init.do","goup管理",1,""),
	FILE_SIZE_MANAGE("1","5","http://fadmin.zallds.com/fileSize/init.do","图片尺寸管理",1,""),
	FILE_UPLOAD_MANAGE("1","6","http://fadmin.zallds.com/file/init.do","文件维护",1,""),
	FILE_UPLOAD_TEST("1","7","http://fadmin.zallds.com/file/fileUploadTest.do","文件上传测试",1,""),
	FILE_SELECT_TEST("1","8","http://fadmin.zallds.com/file/fileSelectTest.do","文件选择测试",1,"");
	/**
	* <p>Title: </p>
	* <p>Description: </p>
	* @param parentCode
	* @param code
	* @param url
	* @param name
	* @param isLeaf
	* @param icon
	*/ 
	private AppModuleEnum(String parentCode, String code, String url, String name, Integer isLeaf, String icon) {
		this.parentCode = parentCode;
		this.code = code;
		this.url = url;
		this.name = name;
		this.isLeaf = isLeaf;
		this.icon = icon;
	}
	private String parentCode;
	private String code;
	private String url;
	private String name;
	private Integer isLeaf;
	private String icon;
	public String getParentCode() {
		return parentCode;
	}
	public void setParentCode(String parentCode) {
		this.parentCode = parentCode;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getIsLeaf() {
		return isLeaf;
	}
	public void setIsLeaf(Integer isLeaf) {
		this.isLeaf = isLeaf;
	}
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public AppModule convertToAppModule(){
		AppModule appModule=new AppModule();
		appModule.setCode(code);
		appModule.setParentCode(parentCode);
		appModule.setIsLeaf(isLeaf);
		appModule.setIcon(icon);
		appModule.setUrl(url);
		appModule.setName(name);
		return appModule;
	}
}