package com.zallds.arch.file.admin.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.zallds.arch.file.admin.base.annotatio.AoData;
import com.zallds.arch.file.admin.base.controller.BaseController;
import com.zallds.arch.file.admin.base.page.Page;
import com.zallds.arch.file.admin.base.vo.BootStrapFormVo;
import com.zallds.arch.file.admin.dao.IFileDao;
import com.zallds.arch.file.admin.utils.DownloadMimeUtil;
import com.zallds.arch.file.client.exception.FileDeleteExe;
import com.zallds.arch.file.client.exception.FileDownLoadCheckExe;
import com.zallds.arch.file.client.exception.FileDownLoadExe;
import com.zallds.arch.file.client.exception.FileUploadExe;
import com.zallds.arch.file.client.service.IFileDownLoadService;
import com.zallds.arch.file.client.service.IFileUploadService;
import com.zallds.arch.file.client.vo.AppInfoVo;
import com.zallds.arch.file.client.vo.FileEntity;
import com.zallds.arch.file.client.vo.FileInfoVo;
import com.zallds.architecture.portal.config.ZalldsGlobalEnvPropertyConfigurer;



/**
* @ClassName: AppInfoController
* @Description: TODO(这里用一句话描述这个类的作用)
* @author yedengchu
* @date 2017年2月13日 下午3:56:45
*
*/
@Controller
@RequestMapping("/file")
public class FileController extends BaseController{
	private static final Logger log = LoggerFactory.getLogger(FileController.class);
	@Autowired
	IFileDao fileDao;
	@Autowired
	IFileUploadService fileUploadService;
	@Autowired
	IFileDownLoadService fileDLoadService; 
	@RequestMapping("/init.do")
	public String init(HttpServletRequest request, HttpServletResponse response, Map<String, Object> model) throws Exception {
		    AppInfoVo appInfo=new AppInfoVo();
	        List<AppInfoVo> appInfos=fileDao.selectListD("app.qryAllAppInfos",appInfo);
	        model.put("appInfos", appInfos);
	        if(ZalldsGlobalEnvPropertyConfigurer.getEnv().equals("test")){
				model.put("domain", "fcenter-test.zallds.com");
				  model.put("port", "80");
			}else if(ZalldsGlobalEnvPropertyConfigurer.getEnv().equals("stage")){
				model.put("domain", "fcenter-stg.zallds.com");
			    model.put("port", "80");
			}else{
				model.put("domain", "fcenter.zallds.com");
			    model.put("port", "80");
			}
	        return "file/fileInfo";
		
	}
	@RequestMapping("/fileUploadTest.do")
	public String fileUploadTest(HttpServletRequest request, HttpServletResponse response, Map<String, Object> model) throws Exception {
		if(ZalldsGlobalEnvPropertyConfigurer.getEnv().equals("test")){
			model.put("domain", "fcenter-test.zallds.com");
		    model.put("port", "80");
		}else if(ZalldsGlobalEnvPropertyConfigurer.getEnv().equals("stage")){
			model.put("domain", "fcenter-stg.zallds.com");
		    model.put("port", "80");
		}else{
			model.put("domain", "fcenter.zallds.com");
		    model.put("port", "80");
		}
	        return "file/fileUploadTest";
	}
	@RequestMapping("/fileSelectTest.do")
	public String fileSelectTest(HttpServletRequest request, HttpServletResponse response, Map<String, Object> model) throws Exception {
		if(ZalldsGlobalEnvPropertyConfigurer.getEnv().equals("test")){
			model.put("domain", "fcenter-test.zallds.com");
			  model.put("port", "80");
		}else if(ZalldsGlobalEnvPropertyConfigurer.getEnv().equals("stage")){
			model.put("domain", "fcenter-stg.zallds.com");
		    model.put("port", "80");
		}else{
			model.put("domain", "fcenter.zallds.com");
		    model.put("port", "80");
		}
		return "file/fileSelectTest";
	}
	
	/**
	 * 查询应用信息
	 * 
	 * @throws Exception
	 */
	@RequestMapping("/qryAllFiles.do")
	public void qryAllFiles(HttpServletRequest request, HttpServletResponse response, Map<String, Object> model,@AoData BootStrapFormVo aoData,FileInfoVo fileInfoVo) {
		try {
			int pageNumber = aoData.getPage(); 
			int pageSize = aoData.getRows();
			//FileCataLogVo catalog=new FileCataLogVo();
//			if (StringUtils.isNotBlank(aoData.getSearch())) {
//				catalog.setName(aoData.getSearch());
//			}
			if("-1".equals(fileInfoVo.getAppCode())){
				fileInfoVo.setAppCode(null);
			}
			if("-1".equals(fileInfoVo.getCatalogCode())){
				fileInfoVo.setCatalogCode(null);
			}
			if("-1".equals(fileInfoVo.getGroupCode())){
				fileInfoVo.setGroupCode(null);
			}
			if(fileInfoVo.getStatus()!=null&&-1==fileInfoVo.getStatus()){
				fileInfoVo.setStatus(null);
			}
			if(StringUtils.isBlank(fileInfoVo.getName())){
				fileInfoVo.setName(null);
			}
			Page pageQuery=fileDao.pageQuery("file.qryAllFilesCount", "file.qryAllFiles", fileInfoVo, pageNumber, pageSize);
			HashMap<String, Object> retMap = new HashMap<String, Object>();
			retMap.put("aaData", pageQuery.getResult());
			retMap.put("sEcho", aoData.getsEcho() + 1);
			retMap.put("iTotalRecords",pageQuery.getTotalCount());
			retMap.put("iTotalDisplayRecords",pageQuery.getTotalCount());
			writeJSON(response, retMap);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@RequestMapping("/upload.do")
	public void upload(HttpServletRequest request, HttpServletResponse response,FileInfoVo fileInfoVo){
		StringBuilder result=new StringBuilder();
		if(StringUtils.isBlank(fileInfoVo.getAppCode())){
			log.error("---------------appCode为空");
		}else{
			if(StringUtils.isBlank(fileInfoVo.getCatalogCode())||"-1".equals(fileInfoVo.getCatalogCode())){
				fileInfoVo.setCatalogCode("");
			}
			if(StringUtils.isBlank(fileInfoVo.getGroupCode())||"-1".equals(fileInfoVo.getGroupCode())){
				fileInfoVo.setGroupCode("");
			}
			List<String> successFiles=new ArrayList<String>();
			List<String> faileFiles=new ArrayList<String>();	
			 //创建一个通用的多部分解析器  
	        CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver(request.getSession().getServletContext());  
	        //判断 request 是否有文件上传,即多部分请求  
	        if(multipartResolver.isMultipart(request)){  
	            //转换成多部分request    
	            MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest)request;  
	            //取得request中的所有文件名  
	            Iterator<String> iter = multiRequest.getFileNames();  
	            String ext=null;
	            List<FileEntity> fList=new ArrayList<FileEntity>();
	            while(iter.hasNext()){  
	                //记录上传过程起始时的时间，用来计算上传时间  
	                int pre = (int) System.currentTimeMillis();  
	                //取得上传文件  
	                MultipartFile file = multiRequest.getFile(iter.next());  
	                if(file != null){  
	                    //取得当前上传文件的文件名称  
	                    String myFileName = file.getOriginalFilename();  
	                    faileFiles.add(myFileName);
	                    //如果名称不为“”,说明该文件存在，否则说明该文件不存在  
	                    
	                    try {
							if(StringUtils.isNotBlank(myFileName)&&file.getBytes()!=null&&file.getBytes().length>0){  
								if(myFileName.indexOf(".")!=-1){
									ext=myFileName.substring(myFileName.lastIndexOf(".")+1);
								}
							    FileEntity ftEntity=new FileEntity(myFileName,file.getBytes(),ext);
							    fList.add(ftEntity);
							
							}
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}  
	                }  
	            }  
	            List<FileInfoVo> fileInfoVos=null;
	            if(CollectionUtils.isNotEmpty(fList)){
	              try {
					fileInfoVos=fileUploadService.batchUploadFiles(fList, fileInfoVo.getAppCode(), fileInfoVo.getCatalogCode(), fileInfoVo.getGroupCode(), fileInfoVo.getAuthorizeCode(), fileInfoVo.getEncryptKey(), fileInfoVo.getEncryptKey());
				} catch (FileUploadExe e) {
					e.printStackTrace();
				}
	            }
	            if(CollectionUtils.isNotEmpty(fileInfoVos)){
	            	for(FileInfoVo f:fileInfoVos){
	            		if(faileFiles.contains(f.getName())){
	            			faileFiles.remove(f.getName());
	            		}
	            	}
	            	if(CollectionUtils.isNotEmpty(faileFiles)){
	            		result.append("成功上传：").append(successFiles).append(";").append("失败上传：").append(faileFiles).append(".");
	            	}else{
	            		result.append("全部上传成功！");
	            	}
	            }else{
	            	result.append("全部上传失败！");
	            }
	        } 
		}
		   try {
			writeText(response,result.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@ResponseBody
	@RequestMapping("/recycleFile.do")
   public Object recycleFile(HttpServletRequest request, HttpServletResponse response,FileInfoVo fileInfoVo){
		String updateId=(String)request.getSession().getAttribute("userId");
		fileInfoVo.setUpdateId(updateId);
		fileInfoVo.setStatus(1);
		fileDao.update("file.updateFileStatusById", fileInfoVo);
	   return "ok";
	}
	@ResponseBody
	@RequestMapping("/deleteFile.do")
   public Object deleteFile(HttpServletRequest request, HttpServletResponse response,FileInfoVo fileInfoVo){
		FileInfoVo resFileInfo= fileDao.select("file.getFileInfoById", fileInfoVo);
		boolean res=false;
		try {
			res = fileUploadService.deleteFile(resFileInfo.getUrl(), resFileInfo.getAppCode(), resFileInfo.getAuthorizeCode(),"",-1);
		} catch (FileDownLoadCheckExe e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileDeleteExe e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(res){
			return "ok";
		}else{
			return "error";
		}
	   
	}
	@ResponseBody
	@RequestMapping("/downloadFile.do")
	   public void downloadFile(HttpServletRequest request, HttpServletResponse response,FileInfoVo fileInfoVo){
			//
			FileInfoVo resFileInfo= fileDao.select("file.getFileInfoById", fileInfoVo);
			FileEntity fileEntity=null;
			try {
				fileEntity = fileDLoadService.downloadSingleFile(resFileInfo.getUrl(), fileInfoVo.getDecryptKey(), resFileInfo.getAppCode(), fileInfoVo.getAuthorizeCode());
			} catch (FileDownLoadCheckExe | FileDownLoadExe e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(fileEntity!=null){
				try {
					response.setContentLength(fileEntity.getContent().length);
					//response.setContentType(request.getSession().getServletContext().getMimeType(fileEntity.getName()));
					String contentType=DownloadMimeUtil.getMimeTypeByExt(resFileInfo.getType());
					response.setContentType(contentType==null?"application/x-download":contentType);  
					response.setHeader("Content-Disposition", "attachment; filename="+fileEntity.getName());
					response.getOutputStream().write(fileEntity.getContent());
				} catch (IOException e) {
					e.printStackTrace();
				}
				String updateId=(String)request.getSession().getAttribute("userId");
				fileInfoVo.setUpdateId(updateId);
				fileInfoVo.setStatus(1);
				fileDao.update("file.updateFileLastAccessTimeById", fileInfoVo);
			}else{
				try {
					response.getWriter().write("文件下载失败，请检查解密秘钥和权限编码！");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	public IFileDao getFileDao() {
		return fileDao;
	}
	public void setFileDao(IFileDao fileDao) {
		this.fileDao = fileDao;
	}
}
