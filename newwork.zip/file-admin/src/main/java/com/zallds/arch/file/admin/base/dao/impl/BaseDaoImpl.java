package com.zallds.arch.file.admin.base.dao.impl;

import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.mybatis.spring.support.SqlSessionDaoSupport;

import com.zallds.arch.file.admin.base.dao.IBaseDao;
import com.zallds.arch.file.admin.base.page.JspPage;
import com.zallds.arch.file.admin.base.page.Page;

/**
* @ClassName: LogDaoImpl
* @Description: TODO(这里用一句话描述这个类的作用)
* @author yedengchu
* @date 2016年11月21日 下午5:59:36
*
*/
public class BaseDaoImpl extends SqlSessionDaoSupport implements IBaseDao {

	/*
	 * @see com.zallds.architecture.base.dao.IBaseDao#save(java.lang.String, java.lang.Object)
	 */
	@Override
	public <T> void insert(String sqlName, T argObject) {
		this.getSqlSession().insert(sqlName,argObject);
	}

	/*
	 * @see com.zallds.architecture.base.dao.IBaseDao#select(java.lang.String, java.lang.Object)
	 */
	@Override
	public <T> T select(String sqlName, T argObject) {
		return this.getSqlSession().selectOne(sqlName, argObject);
	}

	/*
	 * @see com.zallds.architecture.base.dao.IBaseDao#selectList(java.lang.String, java.lang.Object)
	 */
	@Override
	public <T> List<T> selectList(String sqlName, T argObject) {
		return this.getSqlSession().selectList(sqlName, argObject);
	}

	/*
	 * @see com.zallds.architecture.base.dao.IBaseDao#delete(java.lang.String, java.lang.Object)
	 */
	@Override
	public <T> void delete(String sqlName, T argObject) {
		this.getSqlSession().delete(sqlName,argObject);
		
	}
	/*
	 * @see com.zallds.architecture.base.dao.IBaseDao#update(java.lang.String, java.lang.Object)
	 */
	@Override
	public <T> void update(String sqlName, T argObject) {
		
		this.getSqlSession().update(sqlName,argObject);
	}
	/**
	 * @param countKey
	 *            查询该表所有记录行的SQL语句ID
	 * @param sqlKey
	 *            需要查询记录的SQL语句ID
	 * @param param
	 *            传递给查询语句的参数
	 * @param pageNo
	 *            需要查询的实际页
	 * @param pageSize
	 *            每页记录行数
	 * @return page对象
	 */
	public Page pageQuery(String countKey, String sqlKey, Object param, Integer pageNo, Integer pageSize) {
		try {
			Page result = null;
			// 实际起始位置
			int skipResults = JspPage.getStartOfPage(pageNo, pageSize);
			int totalSize = (Integer) getSqlSession().selectOne(countKey, param);
			
			/*while(totalSize >0 && totalSize <= skipResults){
				skipResults= skipResults - pageSize;
				pageNo = pageNo -1;
			}*/
			
			List data = getSqlSession().selectList(sqlKey, param, new RowBounds(skipResults, pageSize));

			result = new JspPage(skipResults, totalSize, pageSize, data);
			return result;
		} finally {
			
		}
	}
	/*
	 * @see com.zallds.architecture.base.dao.IBaseDao#selectD(java.lang.String, java.lang.Object)
	 */
	@Override
	public <T, K> T selectD(String sqlName, K argObject) {
	
		return this.getSqlSession().selectOne(sqlName, argObject);
	}

	/*
	 * @see com.zallds.architecture.base.dao.IBaseDao#selectListD(java.lang.String, java.lang.Object)
	 */
	@Override
	public <T, K> List<T> selectListD(String sqlName, K argObject) {
		
		return this.getSqlSession().selectList(sqlName, argObject);
	}


}
