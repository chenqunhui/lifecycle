package test;

import java.io.Serializable;

/**
 * Created with IntelliJ IDEA.
 * User: yangbo
 * Date: 2017/2/22
 * Time: 16:21
 */
public class TestVo implements Serializable{

    private Integer id;

    private String name;

    private String code;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
