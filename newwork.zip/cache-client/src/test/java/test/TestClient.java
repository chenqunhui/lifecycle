package test;

import com.lambdaworks.redis.RedisURI;
import com.lambdaworks.redis.cluster.ClusterClientOptions;
import com.lambdaworks.redis.cluster.RedisAdvancedClusterConnection;
import com.lambdaworks.redis.cluster.RedisClusterClient;
import com.zallds.architecture.cache.codec.StringBytesCodec;
import com.zallds.architecture.cache.exception.CacheException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created with IntelliJ IDEA.
 * User: yangbo
 * Date: 2017/2/22
 * Time: 16:23
 */
public class TestClient {
    static ApplicationContext applicationContext = null;

    private  static   List<RedisURI> uri = new ArrayList<>();

    // 获取spring上下文
    public static synchronized void loadContext() {

        applicationContext = new ClassPathXmlApplicationContext("spring-beans.xml");

    }

    // 通过spring上下文获取bean
    public static Object getBean(String name) {
        if (applicationContext == null) {
            loadContext();
        }

        return applicationContext.getBean(name);
    }

    public static void main(String[] args) throws CacheException {

//        RedisClient cc = (RedisClient) TestClient.getBean("redisClient");



//        cc.putString("aa","00");
//        System.out.println(cc.getString("aa"));
//
//        cc.putObject("bbd","00",(long)123);
//        System.out.println(cc.getObject("bbd"));
//
//        TestVo vo = new TestVo();
//        vo.setId(1);
//        vo.setName("dsada");
//        vo.setCode("aaaa");
//        cc.putObject("test1111",vo,(long)123);
//        String v = (String)cc.getObject("test1111");
//        System.out.println(JSON.toJSON(v));

//        cc.setHashObject("key","hashkey","da");
//        System.out.println(cc.getHashObject("key","hashkey"));

        String server[] = "192.168.137.128:6300,192.168.137.128:6301,192.168.137.128:6302".split(",");

        for (int i = 0; i < server.length; i++) {
            String s[] = server[i].trim().split(":");
            if (s.length == 2) {
                String host = s[0];
                int port = Integer.parseInt(s[1]);
                RedisURI u = new RedisURI();
                u.setHost(host);
                u.setPort(port);
                uri.add(u);
            }
        }

        for (int i =0;i< 50;i++){
            new Thread(new Runnable() {
                @Override
                public void run() {
                    while (true){
                        try{
                            RedisClusterClient clusterClient = new RedisClusterClient(uri);
                            clusterClient.setOptions(new ClusterClientOptions.Builder().refreshClusterView(true)
                                    .refreshPeriod(1, TimeUnit.SECONDS).build());
                            RedisAdvancedClusterConnection<String, byte[]> connection = clusterClient
                                    .connectCluster(new StringBytesCodec());
//                            connection.set(i+"",serialize(i+""));
                        }
                        catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                }
            }).start();
        }
    }

    protected static byte[] serialize(Object value) {
        if (value == null) {
            throw new NullPointerException("Can't serialize null");
        }
        byte[] rv = null;
        ByteArrayOutputStream bos = null;
        ObjectOutputStream os = null;
        try {
            bos = new ByteArrayOutputStream();
            os = new ObjectOutputStream(bos);
            os.writeObject(value);
            os.close();
            bos.close();
            rv = bos.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("serialize error");
        } finally {
            close(os);
            close(bos);
        }
        return rv;
    }

    private static void close(Closeable closeable) {
        if (closeable != null)
            try {
                closeable.close();
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("close stream error");
            }
    }
}
