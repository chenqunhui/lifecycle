package com.zallds.architecture.cache.redis3;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.pool.ObjectPool;
import org.apache.commons.pool.PoolableObjectFactory;
import org.apache.commons.pool.impl.StackObjectPool;

import com.lambdaworks.redis.RedisURI;
import com.lambdaworks.redis.cluster.ClusterClientOptions;
import com.lambdaworks.redis.cluster.RedisAdvancedClusterConnection;
import com.lambdaworks.redis.cluster.RedisClusterClient;
import com.zallds.architecture.cache.codec.StringBytesCodec;
import com.zallds.architecture.cache.exception.CacheException;

public class RedisManager {

	protected static ObjectPool pool = null;

	private static RedisClusterClient clusterClient = null;

	private String prefix;

	protected String poolId;

	protected int poolMax = 10;

	protected long maxSize = 10000;

	private String servers;
	
	private String version;

	public String getServers() {
		return servers;
	}

	public void setServers(String servers) {
		this.servers = servers;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	public void setPoolId(String poolId) {
		this.poolId = poolId;
	}

	public void setPoolMax(int poolMax) {
		this.poolMax = poolMax;
	}

	public void setMaxSize(long maxSize) {
		this.maxSize = maxSize;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	/**
	 * 初始化加载
	 * 
	 * @throws CacheException
	 */
	public void init() throws CacheException {
		if (pool == null) {
			String server[] = servers.split(",");
			List<RedisURI> uri = new ArrayList<RedisURI>();
			for (int i = 0; i < server.length; i++) {
				String s[] = server[i].trim().split(":");
				if (s.length == 2) {
					String host = s[0];
					int port = Integer.parseInt(s[1]);
					RedisURI u = new RedisURI();
					u.setHost(host);
					u.setPort(port);
					uri.add(u);
				}
			}

			if (uri.size() == 0) {
				throw new CacheException("No server is define !Please check Config of ${arch.redis.servers}");
			}

			clusterClient = new RedisClusterClient(uri);
			clusterClient.setOptions(new ClusterClientOptions.Builder().refreshClusterView(true)
					.refreshPeriod(1, TimeUnit.SECONDS).build());
			PoolableObjectFactory factory = new RedisStringPoolableObjectFactory(clusterClient);
			pool = new StackObjectPool(factory);
			for (int i = 0; i < poolMax; i++) {
				RedisAdvancedClusterConnection<String, byte[]> connection = clusterClient
						.connectCluster(new StringBytesCodec());
				try {
					pool.returnObject(connection);
				} catch (Exception exp) {
					throw new CacheException(exp.getMessage(), exp);
				}
			}
			if (prefix == null || prefix.length() == 0) {
				poolId = "";
			} else {
				poolId = prefix.replace("/", "-") + "/";
			}
			if(version != null){
				poolId = poolId + "_"+ version + "-";
			}
		}
		
	}



	/**
	 * 类型转换，list转string[]
	 * 
	 * @param keys
	 * @return
	 */
	protected String[] getKeyArray(List<String> keys) {
		String k[] = new String[keys.size()];
		for (int i = 0; i < keys.size(); i++) {
			k[i] = keys.get(i);
		}
		return k;
	}

	protected static byte[] serialize(Object value) {
		if (value == null) {
			throw new NullPointerException("Can't serialize null");
		}
		byte[] rv = null;
		ByteArrayOutputStream bos = null;
		ObjectOutputStream os = null;
		try {
			bos = new ByteArrayOutputStream();
			os = new ObjectOutputStream(bos);
			os.writeObject(value);
			os.close();
			bos.close();
			rv = bos.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("serialize error");
		} finally {
			close(os);
			close(bos);
		}
		return rv;
	}

	protected static <T> T deserialize(byte[] in, Class<T>... requiredType) {
		if (in == null || in.length == 0) {
			return null;
		}
		Object rv = null;
		ByteArrayInputStream bis = null;
		ObjectInputStream is = null;
		try {
			if (in != null) {
				bis = new ByteArrayInputStream(in);
				is = new ObjectInputStream(bis);
				rv = is.readObject();
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("deserialize error");
		} finally {
			close(is);
			close(bis);
		}
		return (T) rv;
	}

	private static void close(Closeable closeable) {
		if (closeable != null)
			try {
				closeable.close();
			} catch (IOException e) {
				e.printStackTrace();
				System.out.println("close stream error");
			}
	}

}
