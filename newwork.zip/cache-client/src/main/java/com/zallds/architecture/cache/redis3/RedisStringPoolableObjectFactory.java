package com.zallds.architecture.cache.redis3;

import org.apache.commons.pool.PoolableObjectFactory;

import com.lambdaworks.redis.RedisClusterConnection;
import com.lambdaworks.redis.cluster.RedisClusterClient;
import com.zallds.architecture.cache.codec.StringBytesCodec;

public class RedisStringPoolableObjectFactory implements PoolableObjectFactory{

	private RedisClusterClient clusterClient;
	public RedisStringPoolableObjectFactory(RedisClusterClient clusterClient) {
		this.clusterClient = clusterClient;
	}

	public void activateObject(Object obj) throws Exception {
		
	}

	public void destroyObject(Object obj) throws Exception {
		RedisClusterConnection<String, byte[]> connection = (RedisClusterConnection<String, byte[]>) obj;
		connection.close();
	}

	public Object makeObject() throws Exception {
		RedisClusterConnection<String, byte[]> connection = clusterClient.connectCluster(new StringBytesCodec());
		return connection;
	}

	public void passivateObject(Object obj) throws Exception {
		
		
	}

	public boolean validateObject(Object obj) {
		RedisClusterConnection<String, byte[]> connection = (RedisClusterConnection<String, byte[]>) obj;
		return true;
	}

}
