package com.zallds.architecture.cache.redis3;

public class CacheConstants {

	protected static final Long TIMEOUT = (long) 86400;
	
	protected static final String SET = "set";
	
	protected static final String GET = "get";
	
	protected static final String SETEX = "setex";
	
	protected static final String SETNX = "setnx";
	
	protected static final String DEL = "del";
	
	protected static final String TTL = "ttl";
	
	protected static final String KEYS = "keys";
	
	protected static final String EXISTS = "exists";
	
	protected static final String RENAMENX = "renamenx";
	
	protected static final String INCR = "incr";
	
	protected static final String DECR = "decr";
	
	protected static final String MGET = "mget";
	
	protected static final String HSET = "hset";
	
	protected static final String HGET = "hget";
	
	protected static final String HGETALL = "hgetall";
	
	protected static final String HKEYS = "hkeys";
	
	protected static final String HVALS = "hvals";
	
	protected static final String HLEN = "hlen";
	
	protected static final String HEXISTS = "hexists";
	
	protected static final String HDEL = "hdel";
	
	protected static final String HMGET = "hmget";
	
	protected static final String HMSET = "hmset";
	
	protected static final String LPUSH = "lpush";
	
	protected static final String RPUSH = "rpush";
	
	protected static final String LPOP = "lpop";
	
	protected static final String RPOP = "rpop";
	
	protected static final String LLEN = "llen";
	
	protected static final String LRANGE = "lrange";
	
	protected static final String LSET = "lset";
	
	protected static final String LREM = "lrem";
	
	protected static final String SADD = "sadd";
	
	protected static final String SISMEMBER = "sismember";
	
	protected static final String SMEMBERS = "smembers";
}
