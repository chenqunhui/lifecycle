package com.zallds.architecture.cache.redis3;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.lambdaworks.redis.RedisClusterConnection;
import com.zallds.architecture.cache.CacheClient;
import com.zallds.architecture.cache.exception.CacheException;

public class RedisClient extends RedisMonitorManager implements CacheClient {

	@Override
	public boolean putString(String key, String value, Long timeout) throws CacheException {
		return  putString(key, value, timeout,true);
	}

	@Override
	public boolean putString(String key, String value, Long timeout, Boolean usePoolId) throws CacheException {
		return this.putObject(key,value,timeout,usePoolId);
	}

	@Override
	public boolean putObject(String key, Object value, Long timeout) throws CacheException {
		return  this.putObject(key,value,timeout,true);
	}

	@Override
	public boolean putObject(String key, Object value, Long timeout, Boolean usePoolId) throws CacheException {
		if(timeout > CacheConstants.TIMEOUT){
			timeout = CacheConstants.TIMEOUT;
		}
		key = monitor(CacheConstants.SET, key,usePoolId);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				client.set(key, serialize(value));
				return expire(key, timeout,false);
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}


	@Override
	public boolean putString(String key, String value) throws CacheException {
		return putString(key, value, CacheConstants.TIMEOUT);
	}

	@Override
	public boolean putObject(String key, Object value) throws CacheException {
		return putObject(key, value, CacheConstants.TIMEOUT);
	}


	@Override
	public boolean setnx(String key, Object value) throws CacheException {
		return setnx(key,value, CacheConstants.TIMEOUT);
	}

	@Override
	public boolean setnx(String key, Object value, Long timeout) throws CacheException {
		if(timeout > CacheConstants.TIMEOUT){
			timeout = CacheConstants.TIMEOUT;
		}
		key = monitor(CacheConstants.SETNX, key);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				boolean bo =client.setnx(key, serialize(value));
				if(bo){
					expire(key, timeout,false);
				}
				return bo;
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	@Override
	public String getString(String key, Boolean usePoolId) throws CacheException {
		return (String) this.getObject(key,usePoolId);
	}

	@Override
	public String getString(String key) throws CacheException {
		return getString(key,true);
	}

	@Override
	public Object getObject(String key) throws CacheException {
		return getObject(key, true);
	}


	@Override
	public Object getObject(String key, Boolean usePoolId) throws CacheException {
		key = monitor(CacheConstants.GET, key,usePoolId);
		RedisClusterConnection<String, byte[]> client = null;
		Object ret = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				ret = deserialize(client.get(key),Object.class);
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
		return ret;
	}

	public boolean delete(String key) throws CacheException {
		key = monitor(CacheConstants.DEL, key);
		RedisClusterConnection<String, byte[]> client = null;
		boolean result = false;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				client.del(key);
				result = true;
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
		return result;
	}

	public boolean expire(String key, int timeout) throws CacheException {
		return this.expire(key, (long) timeout);
	}


	@Override
	public boolean expire(String key, Long timeout) throws CacheException {
		return this.expire(key, timeout, true);
	}



	@Override
	public boolean expire(String key, Long timeout, Boolean usePoolId) throws CacheException {
		key = monitor(CacheConstants.TTL, key,usePoolId);
		RedisClusterConnection<String, byte[]> client = null;
		boolean result = false;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				if (timeout > CacheConstants.TIMEOUT) {
					timeout = (long) CacheConstants.TIMEOUT;
				}
				client.expire(key, timeout);
				result = true;
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
		return result;
	}


	public boolean expire(String key, Date date) throws CacheException {
		RedisClusterConnection<String, byte[]> client = null;
		boolean result = false;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				client.expireat(key, date);
				result = true;
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
		return result;
	}

	public List<String> getKeys(String key) throws CacheException {
		key = monitor(CacheConstants.KEYS, key);
		RedisClusterConnection<String, byte[]> client = null;
		List<String> keys = new ArrayList<String>();
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				keys = client.keys(key);
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
		return keys;
	}

	public boolean exists(String key) throws CacheException {
		key = monitor(CacheConstants.EXISTS, key);
		RedisClusterConnection<String, byte[]> client = null;
		boolean result = false;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				return client.exists(key);
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}

	}

	public boolean rename(String key, String newKey) throws CacheException {
		key = monitor(CacheConstants.RENAMENX, key);
		RedisClusterConnection<String, byte[]> client = null;
		boolean result = false;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				result = client.renamenx(key, newKey);
				return result;
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	public long incr(String key) throws CacheException {
		return incr(key, CacheConstants.TIMEOUT);
	}



	@Override
	public long incr(String key, Long timeout) throws CacheException {
		if(timeout > CacheConstants.TIMEOUT){
			timeout = CacheConstants.TIMEOUT;
		}
		key = monitor(CacheConstants.INCR, key);
		RedisClusterConnection<String, byte[]> client = null;
		long result = 0;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				result = client.incr(key);
				expire(key, timeout,false);
				return result;
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	public long decr(String key) throws CacheException {
		return decr(key, CacheConstants.TIMEOUT);
	}


	@Override
	public long decr(String key, Long timeout) throws CacheException {
		if(timeout > CacheConstants.TIMEOUT){
			timeout = CacheConstants.TIMEOUT;
		}
		key = monitor(CacheConstants.DECR, key);
		RedisClusterConnection<String, byte[]> client = null;
		long result = 0;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				result = client.decr(key);
				return result;
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	@Override
	public List<String> getValuesString(List<String> keys) throws CacheException {
		return getValuesString(keys,true);
	}


	@Override
	public List<String> getValuesString(List<String> keys, Boolean usePoolId) throws CacheException {
		RedisClusterConnection<String, byte[]> client = null;
		List<String> result = new ArrayList<>();
		List<byte[]> values = new ArrayList<byte[]>();
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				String k[] = new String[keys.size()];
				for (int i = 0; i < keys.size(); i++) {
					k[i] = monitor(CacheConstants.MGET, keys.get(i),usePoolId);
				}
				values = client.mget(k);
				if(values == null || values.size() == 0){
					return null;
				}

				for(byte[] b : values){
					result.add(deserialize(b,String.class));
				}
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
		return result;
	}

	@Override
	public List<Object> getValuesObject(List<String> keys) throws CacheException {
		return getValuesObject(keys,true);
	}


	@Override
	public List<Object> getValuesObject(List<String> keys, Boolean usePoolId) throws CacheException {
		RedisClusterConnection<String, byte[]> client = null;
		List<Object> result = new ArrayList<>();
		List<byte[]> values = new ArrayList<byte[]>();
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				String k[] = new String[keys.size()];
				for (int i = 0; i < keys.size(); i++) {
					k[i] = monitor(CacheConstants.MGET, keys.get(i),usePoolId);
				}
				values = client.mget(k);
				if(values == null || values.size() == 0){
					return null;
				}

				for(byte[] b : values){
					result.add(deserialize(b,Object.class));
				}
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
		return result;
	}

	@Override
	public boolean setHashObject(String key, String hashKey, Object hashValue) throws CacheException {
		return setHashObject(key,hashKey,hashValue,true);
	}



	@Override
	public boolean setHashObject(String key, String hashKey, Object hashValue, Boolean usePoolId)
			throws CacheException {
		return setHashObject(key,hashKey,hashValue,CacheConstants.TIMEOUT,usePoolId);
	}

	@Override
	public boolean setHashObject(String key, String hashKey, Object hashValue, Long timeout) throws CacheException {
		return setHashObject(key,hashKey,hashValue,CacheConstants.TIMEOUT,true);
	}

	@Override
	public boolean setHashObject(String key, String hashKey, Object hashValue, Long timeout, Boolean usePoolId)
			throws CacheException {
		if(timeout > CacheConstants.TIMEOUT){
			timeout = CacheConstants.TIMEOUT;
		}
		if(!vaildHashLength(key)){
			throw new CacheException("this key ["+key+"] lenth more than "+maxSize+",error command by hset");
		}
		key = monitor(CacheConstants.HSET, key,usePoolId);
		RedisClusterConnection<String, byte[]> client = null;
		boolean result = false;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				client.hset(key, hashKey, serialize(hashValue));
				return expire(key,timeout);
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}


	@Override
	public Object getHashObject(String key, String hashKey) throws CacheException {
		return getHashObject(key, hashKey, true);
	}



	@Override
	public Object getHashObject(String key, String hashKey, Boolean usePoolId) throws CacheException {
		key = monitor(CacheConstants.HGET, key,usePoolId);
		RedisClusterConnection<String, byte[]> client = null;
		boolean result = false;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				Object json = deserialize(client.hget(key, hashKey),Object.class);
				return json;
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}


	@Override
	public Map<String, Object> getHashAll(String key) throws CacheException {
		return  getHashAll(key, true);
	}

	@Override
	public Map<String, Object> getHashAll(String key, Boolean usePoolId) throws CacheException {
		key = monitor(CacheConstants.HGETALL, key,usePoolId);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				Map<String, byte[]> r = client.hgetall(key);
				Set<String> set = r.keySet();
				Map<String, Object> ret = new HashMap<String, Object>();
				Iterator<String> iter = set.iterator();
				while (iter.hasNext()) {
					String k = iter.next();
					ret.put(k, deserialize(r.get(k),Object.class));
				}
				return ret;
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	@Override
	public List<String> getHashKeys(String key) throws CacheException {
		return this.getHashKeys(key, true);
	}

	@Override
	public List<String> getHashKeys(String key, Boolean usePoolId) throws CacheException {
		key = monitor(CacheConstants.HKEYS, key,usePoolId);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				List<String> keys = client.hkeys(key);
				return keys;
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	@Override
	public List<Object> getHashObjects(String key) throws CacheException {
		key = monitor(CacheConstants.HVALS, key);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				List<byte[]> keys = client.hvals(key);
				List<Object> ret = new ArrayList<Object>();
				for (int i = 0; i < keys.size(); i++) {
					ret.add(deserialize(keys.get(i),Object.class));
				}
				return ret;
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	@Override
	public long getHashLength(String key) throws CacheException {
		return getHashLength(key,true);
	}

	@Override
	public long getHashLength(String key, Boolean usePoolId) throws CacheException {
		key = monitor(CacheConstants.HLEN, key,usePoolId);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				return client.hlen(key);
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	@Override
	public boolean hashExists(String key, String hashKey) throws CacheException {
		return hashExists(key,hashKey, true);
	}

	@Override
	public boolean hashExists(String key, String hashKey, Boolean usePoolId) throws CacheException {
		key = monitor(CacheConstants.HEXISTS, key,usePoolId);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				return client.hexists(key, hashKey);
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	@Override
	public boolean deleteHashObject(String key, String hashKey) throws CacheException {
		return this.deleteHashObject(key, hashKey, true);
	}


	@Override
	public boolean deleteHashObject(String key, String hashKey, Boolean usePoolId) throws CacheException {
		key = monitor(CacheConstants.HDEL, key,usePoolId);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				return client.hdel(key, hashKey) == 1;
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	public long deleteHashObjects(String key, List<String> hashKeys) throws CacheException {
		key = monitor(CacheConstants.HDEL, key);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				return client.hdel(key, getKeyArray(hashKeys));
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	@Override
	public List<Object> getHashObjectWithKeys(String key, List<String> hashKeys) throws CacheException {
		return getHashObjectWithKeys(key,hashKeys, true);
	}



	@Override
	public List<Object> getHashObjectWithKeys(String key, List<String> hashKeys, Boolean usePoolId)
			throws CacheException {
		key = monitor(CacheConstants.HMGET, key,usePoolId);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				List<byte[]> datas = client.hmget(key, getKeyArray(hashKeys));
				List<Object> ret = new ArrayList<Object>();
				for (int i = 0; i < datas.size(); i++) {
					ret.add(deserialize(datas.get(i),Object.class));
				}
				return ret;
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	@Override
	public boolean setHashObjects(String key, Map<String, Object> objMap) throws CacheException {
		return setHashObjects(key, objMap, CacheConstants.TIMEOUT);
	}



	@Override
	public boolean setHashObjects(String key, Map<String, Object> objMap, Long timeout) throws CacheException {
		if(timeout > CacheConstants.TIMEOUT){
			timeout = CacheConstants.TIMEOUT;
		}
		if(!vaildHashLength(key)){
			throw new CacheException("this key ["+key+"] lenth more than "+maxSize+",error command by hmset");
		}
		key = monitor(CacheConstants.HMSET, key);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				Map<String, byte[]> datas = new HashMap<String, byte[]>();
				Iterator<String> iter = objMap.keySet().iterator();
				while (iter.hasNext()) {
					String k = iter.next();
					datas.put(k, serialize(objMap.get(k)));
				}
				client.hmset(key, datas);
				expire(key, timeout,false);
				return true;
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	@Override
	public long pushFirst(String key, Object value) throws CacheException {
		return pushFirst(key, value, CacheConstants.TIMEOUT);
	}



	@Override
	public long pushFirst(String key, Object value, Long timeout) throws CacheException {
		if(timeout > CacheConstants.TIMEOUT){
			timeout = CacheConstants.TIMEOUT;
		}
		key = monitor(CacheConstants.LPUSH, key);
		if(!vaildListLength(key)){
			throw new CacheException("this key ["+key+"] lenth more than "+maxSize+",error command by lpush");
		}
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				long l= client.lpush(key, serialize(value));
				expire(key, timeout,false);
				return l;
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	@Override
	public Object popFirst(String key) throws CacheException {
		key = monitor(CacheConstants.LPOP, key);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				byte[] v = client.lpop(key);
				return deserialize(v,Object.class);
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	@Override
	public long getListLength(String key) throws CacheException {
		return getListLength(key,true);
	}

	@Override
	public long getListLength(String key, Boolean usePoolId) throws CacheException {
		key = monitor(CacheConstants.LLEN, key,usePoolId);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				return client.llen(key);
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}



	@Override
	public List<Object> getListObjects(String key, long start, long end) throws CacheException {
		return getListObjects(key, start, end,true);
	}

	@Override
	public List<Object> getListObjects(String key, long start, long end, Boolean usePoolId) throws CacheException {
		key = monitor(CacheConstants.LRANGE, key,usePoolId);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				List<byte[]> datas = client.lrange(key, start, end);
				List<Object> ret = new ArrayList<Object>();
				for (int i = 0; i < datas.size(); i++) {
					ret.add(deserialize(datas.get(i),Object.class));
				}
				return ret;

			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	@Override
	public boolean setListObject(String key, long index, Object value) throws CacheException {
		return setListObject(key, index, value, CacheConstants.TIMEOUT);
	}



	@Override
	public boolean setListObject(String key, long index, Object value, Long timeout) throws CacheException {
		if(timeout > CacheConstants.TIMEOUT){
			timeout = CacheConstants.TIMEOUT;
		}
		key = monitor(CacheConstants.LSET, key);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				client.lset(key, index, serialize(value));
				expire(key, timeout,false);
				return true;
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	@Override
	public long pushEnd(String key, Object value) throws CacheException {
		return pushEnd(key, value, CacheConstants.TIMEOUT);
	}



	@Override
	public long pushEnd(String key, Object value, Long timeout) throws CacheException {
		if(timeout > CacheConstants.TIMEOUT){
			timeout = CacheConstants.TIMEOUT;
		}
		if(!vaildListLength(key)){
			throw new CacheException("this key ["+key+"] lenth more than "+maxSize+",error command by rpush");
		}
		key = monitor(CacheConstants.RPUSH, key);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				Long l = client.rpush(key, serialize(value));
				expire(key, timeout,false);
				return l;
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	@Override
	public Object popEnd(String key) throws CacheException {
		key = monitor(CacheConstants.RPOP, key);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				byte[] data = client.rpop(key);
				return deserialize(data,Object.class);
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	@Override
	public boolean deleteListObject(String key, Object value) throws CacheException {
		key = monitor(CacheConstants.LREM, key);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				client.lrem(key, 1, serialize(value));
				return true;
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}


	@Override
	public long sadd(String key, List<Object> object) throws CacheException{
		return sadd(key, object, CacheConstants.TIMEOUT);
	}

	@Override
	public long sadd(String key, List<Object> object, Long timeout) throws CacheException{
		if(timeout > CacheConstants.TIMEOUT){
			timeout = CacheConstants.TIMEOUT;
		}
		if(!vaildSetLength(key)){
			throw new CacheException("this key ["+key+"] lenth more than "+maxSize+",error command by sadd");
		}
		key = monitor(CacheConstants.SADD, key);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				byte[][] arr = new byte[object.size()][];
				for (int i = 0; i < object.size(); i++) {
					arr[i] = serialize(object.get(i));
				}
				Long l = client.sadd(key, arr);
				expire(key, timeout,false);
				return l;
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}


	@Override
	public long sadd(String key, Object member) throws CacheException {
		return sadd(key, member, CacheConstants.TIMEOUT);
	}

	@Override
	public long sadd(String key, Object member, Long timeout) throws CacheException {
		if(timeout > CacheConstants.TIMEOUT){
			timeout = CacheConstants.TIMEOUT;
		}
		if(!vaildSetLength(key)){
			throw new CacheException("this key ["+key+"] lenth more than "+maxSize+",error command by sadd");
		}
		key = monitor(CacheConstants.SADD, key);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				Long l = client.sadd(key, serialize(member));
				expire(key, timeout,false);
				return l;
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	@Override
	public Boolean sismember(String key, String field) throws CacheException {
		return sismember(key, field,true);
	}

	@Override
	public Boolean sismember(String key, Object field) throws CacheException {
		return sismember(key, serialize(field));
	}

	@Override
	public Boolean sismember(String key, String field, Boolean usePoolId) throws CacheException {
		key = monitor(CacheConstants.SISMEMBER, key,usePoolId);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				return client.sismember(key, serialize(field));
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}

	@Override
	public Boolean sismember(String key, Object field, Boolean usePoolId) throws CacheException {
		return sismember(key, serialize(field),usePoolId);
	}

	@Override
	public Set<Object> smembersObject(String key) throws CacheException {
		return smembersObject(key,true);
	}

	@Override
	public Set<Object> smembersObject(String key, Boolean usePoolId) throws CacheException {
		key = monitor(CacheConstants.SMEMBERS, key,usePoolId);
		RedisClusterConnection<String, byte[]> client = null;
		try {
			client = (RedisClusterConnection<String, byte[]>) pool.borrowObject();
			try {
				Set<byte[]> set = client.smembers(key);
				if (set.size() == 0) {
					return null;
				}
				Set<Object> ret = new HashSet<>();
				for (byte[] str : set) {
					ret.add(deserialize(str,Object.class));
				}
				return ret;
			} catch (Exception e) {
				pool.invalidateObject(client);
				client.close();
				client = null;
				throw new CacheException(e);
			} finally {
				if (null != client) {
					pool.returnObject(client);
				}
			}
		} catch (Exception e) {
			throw new CacheException(e);
		}
	}


	private Boolean  vaildSetLength(String key){
		Set<Object> s = smembersObject(key);
		if(s == null){
			return true;
		}
		long length = s.size();
		if(length > maxSize){
			return false;
		}
		return true;
	}

	private Boolean  vaildListLength(String key){
		long length = getListLength(key);
		if(length > maxSize){
			return false;
		}
		return true;
	}


	private Boolean vaildHashLength(String key){
		long length = getHashLength(key);
		if(length > maxSize){
			return false;
		}
		return true;
	}

}
