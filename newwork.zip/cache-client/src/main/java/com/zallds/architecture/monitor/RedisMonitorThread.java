package com.zallds.architecture.monitor;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;

public class RedisMonitorThread implements Runnable {

	private static final Logger logger = LoggerFactory.getLogger(RedisMonitorThread.class);

	private static RedisConfigurer redisConfig = null;

	private String url = null;

	public RedisMonitorThread(String url) {
		this.url = url;
	}

	@Override
	public void run() {
		redisConfig = RedisConfigurer.getInstance();
		if (url == null) {
			return;
		}
		Map<String, Integer> map = redisConfig.getData();
		if (map != null && !map.isEmpty()) {
			try {
				post(JSONObject.toJSONString(map));
				redisConfig.clear();
			} catch (Exception e) {
				logger.error(e.getMessage());
//				e.printStackTrace();
			}

		}
	}

	public void post(String param) throws Exception {
		DefaultHttpClient httpclient = new DefaultHttpClient();
		logger.debug("create http post:" + url);
		logger.debug("send param:" + param);
		HttpPost post = postForm(param);
		invoke(httpclient, post);
		httpclient.getConnectionManager().shutdown();
	}

	private void invoke(DefaultHttpClient httpclient, HttpUriRequest httpost) throws Exception {
		HttpResponse response = sendRequest(httpclient, httpost);
		paseResponse(response);
	}

	private void paseResponse(HttpResponse response) {
		HttpEntity entity = response.getEntity();
		String charset = EntityUtils.getContentCharSet(entity);
		String body = null;
		try {
			body = EntityUtils.toString(entity);
			logger.debug("get response from http server :" + body);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

	private HttpResponse sendRequest(DefaultHttpClient httpclient, HttpUriRequest httpost) throws Exception {
		HttpResponse response = null;
		httpclient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 3000);
		httpclient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, 3000);
		response = httpclient.execute(httpost);
		return response;
	}

	private HttpPost postForm(String param) {
		HttpPost httpost = new HttpPost(url);
		List<NameValuePair> nvps = new ArrayList<NameValuePair>();
		nvps.add(new BasicNameValuePair("data", param));
		try {
			httpost.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
		} catch (UnsupportedEncodingException e) {
			logger.error(e.getMessage());
		}
		return httpost;
	}
}
