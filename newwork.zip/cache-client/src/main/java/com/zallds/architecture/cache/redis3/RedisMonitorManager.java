package com.zallds.architecture.cache.redis3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Level;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.zallds.architecture.cache.exception.CacheException;
import com.zallds.architecture.monitor.RedisConfigurer;
import com.zallds.architecture.monitor.RedisMonitorThread;

public class RedisMonitorManager extends RedisManager {

	private static final Logger logger = LoggerFactory.getLogger(RedisMonitorManager.class);

	private ScheduledExecutorService executorService = null;

	private String monitorUrl = null;

	private String validKeys = "";

	private static Set<String> regexSet = new HashSet<>();

	RedisConfigurer redisConfig = null;
	
	private static Boolean state = false;

	public void setMonitorUrl(String monitorUrl) {
		this.monitorUrl = monitorUrl;
	}

	public void setValidKeys(String validKeys) {
		this.validKeys = validKeys;
	}

	/**
	 * 初始化加载
	 */
	@Override
	public void init() throws CacheException {
		org.apache.log4j.Logger log4j = org.apache.log4j.Logger.getLogger("com.lambdaworks"); 
		log4j.setLevel(Level.WARN);
		super.init();
//		if (regexSet.size() == 0 && !validKeys.isEmpty()) {
//			regexSet = new HashSet<>();
//			String[] validList = validKeys.split("\\s+");
//			for (String valid : validList) {
//				regexSet.add(valid);
//			}
//		}
//		redisConfig = RedisConfigurer.getInstance();
//		if(!state){
//			if (monitorUrl != null && !monitorUrl.isEmpty()) {
//				executorService = Executors.newSingleThreadScheduledExecutor(
//						new ThreadFactoryBuilder().setNameFormat("redis-monitor-poller-%d").build());
//				RedisMonitorThread redisMonitor = new RedisMonitorThread(monitorUrl);
//				executorService.scheduleWithFixedDelay(redisMonitor, 0, 1, TimeUnit.MINUTES);
//			}
//			state = true;
//		}
	}

	protected String monitor(String command, String key) {
		return this.monitor(command, key, true);
	}
	

	protected String monitor(String command, String key,Boolean usePoolId) {
		if(usePoolId){
			key = poolId  + key;
		}
//		if (bo) {
//			pushData(command, key);
//		}
		return key;
	}

	/**
	 * 监控数据推入
	 * @param command
	 * @param key
	 */
	private void pushData(String command, String key) {
		Map<String, Integer> map = redisConfig.getData();
		try {
			if (map == null) {
				map = new HashMap<String, Integer>();
			}
			int value = map.containsKey(command) ? map.get(command) + 1 : 1;
			map.put(command, value);
			if (regexSet.size() > 0) {
				pushKey(command,map, key);
			}
		} catch (Exception e) {
			logger.error("push data error ", e);
		}
	}

	/**
	 * 监控敏感key方法
	 * @param command
	 * @param map
	 * @param key
	 */
	private void pushKey(String command,Map<String, Integer> map, String key) {
		String shortKey = key.replace(poolId, "");
		List<String> list = new ArrayList<String>(regexSet);
		int i = 0;
		Boolean bo = false;
		for (; i < list.size();) {
			String regex = list.get(i);
			try {
				if (shortKey.matches(regex)) {
					regex = command + "-" + regex;
					int mapV = map.containsKey(regex) ? map.get(regex) + 1 : 1;
					map.put(regex, mapV);
					break;
				}
				i++;
			} catch (Exception e) {
				bo = true;
				System.err.println("regex is wrong by " + regex);
				logger.error("regex is wrong by " + regex, e);
				list.remove(i);
			}
		}
		if (bo) {
			regexSet.clear();
			regexSet.addAll(list);
		}
	}

}
