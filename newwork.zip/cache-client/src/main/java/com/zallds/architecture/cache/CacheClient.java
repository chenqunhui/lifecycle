package com.zallds.architecture.cache;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.zallds.architecture.cache.exception.CacheException;

/**
 * 缓存客户端  建议使用此类
 * @author zhengchen
 *
 */
public interface CacheClient {
	
	/**
	 * String类型set方法,默认过期时间为1天
	 * @param key 键
	 * @param value 值,String类型
	 * @return
	 * @throws CacheException
	 */
	public boolean putString(String key,String value) throws CacheException;
	
	/**
	 * String类型set方法
	 * @param key 键
	 * @param value 值,String类型
	 * @param timeout 过期时间，单位秒
	 * @return
	 * @throws CacheException
	 */
	public boolean putString(String key,String value,Long timeout) throws CacheException; 
	
	/**
	 * String类型set方法
	 * @param key 键
	 * @param value 值,String类型
	 * @param timeout 过期时间，单位秒
	 * @param usePoolId 是否使用poolid
	 * @return
	 * @throws CacheException
	 */
	public boolean putString(String key,String value,Long timeout,Boolean usePoolId) throws CacheException; 
	
	
	/**
	 * String类型GET方法,返回String类型
	 * @param key 键
	 * @return
	 * @throws CacheException
	 */
	public String getString(String key) throws CacheException;
	
	/**
	 * String类型GET方法,返回String类型
	 * @param key 键
	 * @param usePoolId 是否使用poolid
	 * @return
	 * @throws CacheException
	 */
	public String getString(String key,Boolean usePoolId) throws CacheException;
	
	
	/**
	 * String类型SET方法，值为任意类型，存储时经过json格式封装(尽量避免String类型),默认过期时间为1天
	 * @param key 键
	 * @param value 值，非String类型
	 * @return
	 * @throws CacheException
	 */
	public boolean putObject(String key,Object value) throws CacheException;
	
	
	/**
	 * String类型setnx方法,默认过期时间为1天
	 * @param key 键
	 * @param value 值,Object类型
	 * @return
	 * @throws CacheException
	 */
	public boolean setnx(String key,Object value) throws CacheException;
	
	/**
	 * String类型setnx方法,默认过期时间为1天
	 * @param key 键
	 * @param value 值,Object类型
	 * @return
	 * @throws CacheException
	 */
	public boolean setnx(String key,Object value,Long timeout) throws CacheException;
	
	/**
	 * String类型SET方法，值为任意类型，存储时经过json格式封装(尽量避免String类型)
	 * @param key 键
	 * @param value 值，非String类型
	 * @return
	 * @throws CacheException
	 */
	public boolean putObject(String key,Object value,Long timeout) throws CacheException;
	
	/**
	 * String类型SET方法，值为任意类型，存储时经过json格式封装(尽量避免String类型)
	 * @param key 键
	 * @param value 值，非String类型
	 * @param usePoolId 是否使用poolid
	 * @return
	 * @throws CacheException
	 */
	public boolean putObject(String key,Object value,Long timeout,Boolean usePoolId) throws CacheException;
	
	/**
	 * String类型GET方法，对应putObject方法,返回非String类型
	 * @param key 键
	 * @return
	 * @throws CacheException
	 */
	public Object getObject(String key) throws CacheException;
	
	/**
	 * String类型GET方法，对应putObject方法,返回非String类型
	 * @param key 键
	 * @param usePoolId 是否使用poolid
	 * @return
	 * @throws CacheException
	 */
	public Object getObject(String key,Boolean usePoolId) throws CacheException;
	
	/**
	 * 设置键的有效期
	 * @param key 键
	 * @param timeout 过期时间，单位秒
	 * @return
	 * @throws CacheException
	 */
	public boolean expire(String key,int timeout) throws CacheException;
	
	/**
	 * 设置键的有效期
	 * @param key 键
	 * @param timeout 过期时间，单位秒
	 * @return
	 * @throws CacheException
	 */
	public boolean expire(String key,Long timeout) throws CacheException;
	
	/**
	 * 设置键的有效期
	 * @param key 键
	 * @param timeout 过期时间，单位秒
	 * @param usePoolId 是否使用poolid
	 * @return
	 * @throws CacheException
	 */
	public boolean expire(String key,Long timeout,Boolean usePoolId) throws CacheException;
	

	/**
	 * 设置键的有效期
	 * @param key 键
	 * @param date 过期日期
	 * @return
	 * @throws CacheException
	 */
	public boolean expire(String key,Date date) throws CacheException;
	
	/**
	 * 查询符合给定模式的所有键
	 * @param key 键，可以为pattern
	 * @return
	 * @throws CacheException
	 */
	public List<String> getKeys(String key) throws CacheException;
	
	/**
	 * 返回所有(一个或多个)给定 key 的值
	 * @param keys 值的数组
	 * @return
	 * @throws CacheException
	 */
	public List<String> getValuesString(List<String> keys) throws CacheException;
	
	/**
	 * 返回所有(一个或多个)给定 key 的值
	 * @param keys 值的数组
	 * @param usePoolId 是否使用poolid
	 * @return
	 * @throws CacheException
	 */
	public List<String> getValuesString(List<String> keys, Boolean usePoolId) throws CacheException;
	
	/**
	 * 返回所有(一个或多个)给定 key 的值，其value存储为任意类型，通过json解析后返回的结果
	 * @param keys 值的数组
	 * @return
	 * @throws CacheException
	 */
	public List<Object> getValuesObject(List<String> keys) throws CacheException;
	
	/**
	 * 返回所有(一个或多个)给定 key 的值，其value存储为任意类型，通过json解析后返回的结果
	 * @param keys 值的数组
	 * @param usePoolId 是否使用poolid
	 * @return
	 * @throws CacheException
	 */
	public List<Object> getValuesObject(List<String> keys, Boolean usePoolId) throws CacheException;
	
	/**
	 * 删除指定key
	 * @param key 键
	 * @return
	 * @throws CacheException
	 */
	public boolean delete(String key) throws CacheException;
	
	/**
	 * 判断key是否存在
	 * @param key 键
	 * @return
	 * @throws CacheException
	 */
	public boolean exists(String key) throws CacheException;
	
	/**
	 * key更改名称
	 * @param key 原key
	 * @param newKey 新key
	 * @return
	 * @throws CacheException
	 */
	public boolean rename(String key,String newKey) throws CacheException;
	
	/**
	 * String类型的incr方法。将 key 中储存的数字值增一
	 * @param key 键
	 * @return
	 * @throws CacheException
	 */
	public long incr(String key) throws CacheException;
	
	/**
	 * String类型的incr方法。将 key 中储存的数字值增一
	 * @param key 键
	 * @param key 有效时间
	 * @return
	 * @throws CacheException
	 */
	public long incr(String key,Long timeout) throws CacheException;
	
	/**
	 * String类型的decr方法。将 key 中储存的数字值减一
	 * @param key 键
	 * @return
	 * @throws CacheException
	 */
	public long decr(String key) throws CacheException;
	
	/**
	 * String类型的decr方法。将 key 中储存的数字值减一
	 * @param key 键
	 * @param key 有效时间
	 * @return
	 * @throws CacheException
	 */
	public long decr(String key,Long timeout) throws CacheException;
	
	/**
	 * hash类型的HSET方法。将哈希表 key 中的域 hashKey 的值设为 value，默认过期时间为1天
	 * @param key 哈希表key
	 * @param hashKey 域key
	 * @param hashValue 值
	 * @param usePoolId 是否需要poolId
	 * @return
	 * @throws CacheException
	 */
	public boolean setHashObject(String key,String hashKey,Object hashValue, Boolean usePoolId)throws CacheException;

	/**
	 * hash类型的HSET方法。将哈希表 key 中的域 hashKey 的值设为 value，默认过期时间为1天
	 * @param key 哈希表key
	 * @param hashKey 域key
	 * @param hashValue 值
	 * @return
	 * @throws CacheException
	 */
	public boolean setHashObject(String key,String hashKey,Object hashValue)throws CacheException;
	
	/**
	 * hash类型的HSET方法。将哈希表 key 中的域 hashKey 的值设为 value
	 * @param key 哈希表key
	 * @param hashKey 域key
	 * @param hashValue 值
	 * @param usePoolId 是否需要poolId
	 * @return
	 * @throws CacheException
	 */
	public boolean setHashObject(String key,String hashKey,Object hashValue,Long timeout, Boolean usePoolId)throws CacheException;
	
	/**
	 * hash类型的HSET方法。将哈希表 key 中的域 hashKey 的值设为 value
	 * @param key 哈希表key
	 * @param hashKey 域key
	 * @param hashValue 值
	 * @return
	 * @throws CacheException
	 */
	public boolean setHashObject(String key,String hashKey,Object hashValue,Long timeout)throws CacheException;
	
	/**
	 * hash类型的HGET方法。返回哈希表 key 中给定域 hashKey 的值
	 * @param key 哈希表 key 
	 * @param hashKey 域 Key
	 * @return
	 * @throws CacheException
	 */
	public Object getHashObject(String key,String hashKey) throws CacheException;
	
	/**
	 * hash类型的HGET方法。返回哈希表 key 中给定域 hashKey 的值
	 * @param key 哈希表 key 
	 * @param hashKey 域 Key
	 * @param usePoolId 是否使用poolid
	 * @return
	 * @throws CacheException
	 */
	public Object getHashObject(String key,String hashKey, Boolean usePoolId) throws CacheException;
	
	/**
	 * hash类型的HGETALL方法。返回哈希表 key中，所有的域和值
	 * @param key 哈希表key
	 * @return
	 * @throws CacheException
	 */
	public Map<String,Object> getHashAll(String key)throws CacheException;
	
	/**
	 * hash类型的HGETALL方法。返回哈希表 key中，所有的域和值
	 * @param key 哈希表key
	 * @param usePoolId 是否使用poolid
	 * @return
	 * @throws CacheException
	 */
	public Map<String,Object> getHashAll(String key, Boolean usePoolId)throws CacheException;
	
	/**
	 * Hash类型的HKEYS方法。返回哈希表 key 中的所有域key
	 * @param key 哈希表 key
	 * @return
	 * @throws CacheException
	 */
	public List<String> getHashKeys(String key) throws CacheException;
	
	/**
	 * Hash类型的HKEYS方法。返回哈希表 key 中的所有域key
	 * @param key 哈希表 key
	 * @param usePoolId 是否使用poolid
	 * @return
	 * @throws CacheException
	 */
	public List<String> getHashKeys(String key, Boolean usePoolId) throws CacheException;
	
	/**
	 * hash类型的HVALS方法。返回哈希表 key 中所有域key的值。
	 * @param key 哈希表 key
	 * @return
	 * @throws CacheException
	 */
	public List<Object> getHashObjects(String key) throws CacheException;
	
	/**
	 * hash类型的HLEN方法，返回哈希表 key 中域的数量。
	 * @param key 哈希key
	 * @return
	 * @throws CacheException
	 */
	public long getHashLength(String key) throws CacheException;
	
	/**
	 * hash类型的HLEN方法，返回哈希表 key 中域的数量。
	 * @param key 哈希key
	 * @param usePoolId 是否使用poolid
	 * @return
	 * @throws CacheException
	 */
	public long getHashLength(String key, Boolean usePoolId) throws CacheException;
	
	/**
	 * hash类型的HEXISTS方法。查看哈希表 key 中，给定域 field 是否存在
	 * @param key 哈希key
	 * @param hashKey 域key
	 * @return
	 * @throws CacheException
	 */
	public boolean hashExists(String key,String hashKey) throws CacheException;
	
	/**
	 * hash类型的HEXISTS方法。查看哈希表 key 中，给定域 field 是否存在
	 * @param key 哈希key
	 * @param hashKey 域key
	 * @param usePoolId 是否使用poolid
	 * @return
	 * @throws CacheException
	 */
	public boolean hashExists(String key,String hashKey, Boolean usePoolId) throws CacheException;
	
	/**
	 * hash类型的HDEL方法。删除哈希表 key 中的一个指定域，不存在的域将被忽略。
	 * @param key 哈希key
	 * @param hashKey 域key
	 * @return
	 * @throws CacheException
	 */
	public boolean deleteHashObject(String key,String hashKey) throws CacheException;
	
	/**
	 * hash类型的HDEL方法。删除哈希表 key 中的一个指定域，不存在的域将被忽略。
	 * @param key 哈希key
	 * @param hashKey 域key
	 * @param usePoolId 是否使用poolid
	 * @return
	 * @throws CacheException
	 */
	public boolean deleteHashObject(String key,String hashKey, Boolean usePoolId) throws CacheException;
	
	
	/**
	 * hash类型的HDEL方法。删除哈希表 key 中的多个指定域，不存在的域将被忽略。
	 * @param key 哈希key
	 * @param hashKey 域key数组
	 * @return
	 * @throws CacheException
	 */
	public long deleteHashObjects(String key,List<String> hashKeys)throws CacheException;
	
	/**
	 * hash类型的HMGET方法。返回哈希表 key 中，多个给定域的值。
	 * @param key 哈希key
	 * @param hashKeys 域key数组
	 * @return
	 * @throws CacheException
	 */
	public List<Object> getHashObjectWithKeys(String key,List<String> hashKeys) throws CacheException;
	
	/**
	 * hash类型的HMGET方法。返回哈希表 key 中，多个给定域的值。
	 * @param key 哈希key
	 * @param hashKeys 域key数组
	 * @param usePoolId 是否使用poolid
	 * @return
	 * @throws CacheException
	 */
	public List<Object> getHashObjectWithKeys(String key,List<String> hashKeys, Boolean usePoolId) throws CacheException;
	
	/**
	 * hash类型的HMSET方法。同时将多个 field-value (域-值)对设置到哈希表 key 中。默认过期时间为1天
	 * @param key 哈希key
	 * @param objMap hashkey-value
	 * @return
	 * @throws CacheException
	 */
	public boolean setHashObjects(String key,Map<String,Object> objMap) throws CacheException;
	
	/**
	 * hash类型的HMSET方法。同时将多个 hashkey-value (域-值)对设置到哈希表 key 中
	 * @param key 哈希key
	 * @param objMap hashkey-value
	 * @param timeout 过期时间，单位秒
	 * @return
	 * @throws CacheException
	 */
	public boolean setHashObjects(String key,Map<String,Object> objMap,Long timeout) throws CacheException;
	
	/**
	 * list类型的LPUSH方法。将一个value 插入到列表 key 的表头，默认过期时间为1天
	 * @param key 键
	 * @param value 值
	 * @return
	 * @throws CacheException
	 */
	public long pushFirst(String key,Object value) throws CacheException;
	
	/**
	 * list类型的LPUSH方法。将一个value 插入到列表 key 的表头
	 * @param key 键
	 * @param value 值
	 * @param timeout 过期时间
	 * @return
	 * @throws CacheException
	 */
	public long pushFirst(String key,Object value,Long timeout) throws CacheException;
	
	/**
	 * list类型的LPOP方法。移除并返回列表 key 的头元素。
	 * @param key 键
	 * @return
	 * @throws CacheException
	 */
	public Object popFirst(String key) throws CacheException;
	
	/**
	 * list类型的LLEN方法。返回列表 key 的长度。
	 * @param key 键
	 * @return
	 * @throws CacheException
	 */
	public long getListLength(String key)  throws CacheException;
	
	/**
	 * list类型的LLEN方法。返回列表 key 的长度。
	 * @param key 键
	 * @param usePoolId 是否使用poolid
	 * @return
	 * @throws CacheException
	 */
	public long getListLength(String key, Boolean usePoolId)  throws CacheException;
	
	/**
	 * list类型的LRANGE方法。返回列表 key 中指定区间内的元素
	 * @param key 键
	 * @param start 下标起始位置
	 * @param end 下标截止位置
	 * @return
	 * @throws CacheException
	 */
	public List<Object> getListObjects(String key,long start,long end) throws CacheException;
	
	/**
	 * list类型的LRANGE方法。返回列表 key 中指定区间内的元素
	 * @param key 键
	 * @param start 下标起始位置
	 * @param end 下标截止位置
	 * @param usePoolId 是否使用poolid
	 * @return
	 * @throws CacheException
	 */
	public List<Object> getListObjects(String key,long start,long end, Boolean usePoolId) throws CacheException;
	
	/**
	 * list类型的LSET方法。将列表 key 下标为 index 的元素的值设置为 value，默认过期时间为1天
	 * @param key 键
	 * @param index 下标元素
	 * @param value 值
	 * @return
	 * @throws CacheException
	 */
	public boolean setListObject(String key,long index,Object value) throws CacheException;
	
	/**
	 *  list类型的LSET方法。将列表 key 下标为 index 的元素的值设置为 value
	 * @param key 键
	 * @param index 下标元素
	 * @param value 值
	 * @param timeout 过期时间，单位秒
	 * @return
	 * @throws CacheException
	 */
	public boolean setListObject(String key,long index,Object value,Long timeout) throws CacheException;
	
	/**
	 * list类型的RPUSH方法。将一个或多个值 value 插入到列表 key 的表尾(最右边)。默认过期时间为1天
	 * @param key 键
	 * @param value 值
	 * @return
	 * @throws CacheException
	 */
	public long pushEnd(String key,Object value) throws CacheException;
	
	/**
	 * list类型的RPUSH方法。将一个或多个值 value 插入到列表 key 的表尾(最右边)。
	 * @param key 键
	 * @param value 值
	 * @param timeout 过期时间
	 * @return
	 * @throws CacheException
	 */
	public long pushEnd(String key,Object value,Long timeout) throws CacheException;
	
	/**
	 * list类型的RPOP方法。移除并返回列表 key 的尾元素。
	 * @param key 键
	 * @return
	 * @throws CacheException
	 */
	public Object popEnd(String key) throws CacheException;
	
	/**
	 * list类型的LREM方法。移除列表中第一个与参数 value 相等的元素。
	 * @param key 键
	 * @param value 值
	 * @return
	 * @throws CacheException
	 */
	public boolean deleteListObject(String key,Object value) throws CacheException;
	
	
	/**
	 * set类型的SADD方法。将一个member 元素加入到集合 key 当中，已经存在于集合的 member 元素将被忽略。默认过期时间为1天
	 * @param key 键
	 * @param member 值
	 * @return
	 * @throws CacheException
	 */
	public long sadd(String key, Object member) throws CacheException;
	
	/**
	 * set类型的SADD方法。将一个member 元素加入到集合 key 当中，已经存在于集合的 member 元素将被忽略。
	 * @param key 键
	 * @param member 值
	 * @param timeout 过期时间，单位秒
	 * @return
	 * @throws CacheException
	 */
	public long sadd(String key, Object member,Long timeout) throws CacheException;
	
	/**
	 * set类型的SADD方法。将多个member 元素加入到集合 key 当中，已经存在于集合的 member 元素将被忽略。默认过期时间为1天
	 * @param key 键
	 * @param object 数组
	 * @return
	 * @throws CacheException
	 */
	public long sadd(String key, List<Object> object) throws CacheException;
	
	/**
	 * set类型的SADD方法。将多个member 元素加入到集合 key 当中，已经存在于集合的 member 元素将被忽略
	 * @param key 键
	 * @param object 数组
	 * @param timeout 过期时间，单位秒
	 * @return
	 * @throws CacheException
	 */
	public long sadd(String key, List<Object> object,Long timeout) throws CacheException;
	
	/**
	 * set类型的SISMEMBER方法。判断 member 元素是否集合 key 的成员(未经过json封装)
	 * @param key 键
	 * @param field 值
	 * @return
	 * @throws CacheException
	 */
	public Boolean sismember(String key, String field) throws CacheException;
	
	/**
	 * set类型的SISMEMBER方法。判断 member 元素是否集合 key 的成员(未经过json封装)
	 * @param key 键
	 * @param field 值
	 * @param usePoolId 是否使用poolid
	 * @return
	 * @throws CacheException
	 */
	public Boolean sismember(String key, String field,Boolean usePoolId) throws CacheException;
	
	/**
	 * set类型的SISMEMBER方法。判断 member 元素是否集合 key 的成员(经过json封装)
	 * @param key 键
	 * @param field 值
	 * @return
	 * @throws CacheException
	 */
	public Boolean sismember(String key, Object field) throws CacheException;
	
	/**
	 * set类型的SISMEMBER方法。判断 member 元素是否集合 key 的成员(经过json封装)
	 * @param key 键
	 * @param field 值
	 * @param usePoolId 是否使用poolid
	 * @return
	 * @throws CacheException
	 */
	public Boolean sismember(String key, Object field,Boolean usePoolId) throws CacheException;
	
	
	/**
	 * set类型的SMEMBERS方法。返回集合 key 中的所有成员
	 * @param key 键
	 * @return
	 * @throws CacheException
	 */
	public Set<Object> smembersObject(String key) throws CacheException;
	
	/**
	 * set类型的SMEMBERS方法。返回集合 key 中的所有成员
	 * @param key 键
	 * @param usePoolId 是否使用poolid
	 * @return
	 * @throws CacheException
	 */
	public Set<Object> smembersObject(String key,Boolean usePoolId) throws CacheException;
}
