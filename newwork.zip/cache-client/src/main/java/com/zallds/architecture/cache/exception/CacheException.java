package com.zallds.architecture.cache.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CacheException extends RuntimeException{

	private static final Logger logger = LoggerFactory.getLogger(CacheException.class);
	/**
	 * 
	 */
	private static final long serialVersionUID = -2133896889762458222L;

	public CacheException() {
        super();

    }


    public CacheException(String message, Throwable cause) {
        super(message, cause);

    }


    public CacheException(String message) {
        super(message);

    }


    public CacheException(Throwable cause) {
        super(cause);
        logger.error(cause.getMessage());
    }
}
