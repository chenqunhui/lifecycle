package com.zallds.architecture.monitor;

import java.util.HashMap;
import java.util.Map;

public class RedisConfigurer {


	private static RedisConfigurer instance = null;

	private static Map<String, Integer> map = null;


	public RedisConfigurer() {}

	public static RedisConfigurer getInstance() {
		if (instance == null) {
			syncInit();
		}
		return instance;
	}

	private static synchronized void syncInit() {
		if (instance == null) {
			map = new HashMap<String, Integer>();
			instance = new RedisConfigurer();
		}
	}

	
	public Map<String, Integer> getData() {
		return map;
	}

	public void clear() {
		map.clear();
	}
}
