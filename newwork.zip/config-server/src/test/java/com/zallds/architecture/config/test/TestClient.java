package com.zallds.architecture.config.test;

import java.util.List;

import com.alibaba.dubbo.config.ApplicationConfig;
import com.alibaba.dubbo.config.ReferenceConfig;
import com.alibaba.dubbo.config.RegistryConfig;
import com.zallds.architecture.config.ConfigService;
import com.zallds.architecture.config.model.DBInfo;
import com.zallds.architecture.config.model.DBInstance;



public class TestClient {
public static void main(String[] args) throws Exception {  
        
		ApplicationConfig application =new ApplicationConfig();
		application.setName("eros-server");
		
		RegistryConfig registry =new RegistryConfig();
		// TODO :移到配置文件
		registry.setAddress("zookeeper://192.168.62.220:2182");

		ReferenceConfig<ConfigService> reference =new ReferenceConfig<ConfigService>();// 此实例很重，封装了与注册中心的连接以及与提供者的连接，请自行缓存，否则可能造成内存和连接泄漏
		reference.setApplication(application);
		reference.setRegistry(registry);// 多个注册中心可以用setRegistries()
		reference.setInterface(ConfigService.class);  
		//reference.setUrl("dubbo://192.168.10.58:20880/com.zallgo.search.proxy.service.ProductIndexService");
		//reference.setUrl("dubbo://192.168.62.43:20880/com.zallgo.search.proxy.service.ProductIndexService");
		
		
		ConfigService configService = reference.get();
		List<DBInfo> list = configService.getDatabases("", "test");
        List<DBInstance> l1 = configService.getDatabaseInstance("", "test", "zallgo_order");
        
        DBInstance i1 = configService.getDatabaseInstanceWithType("", "test", "zallgo_order", true);
        DBInstance i2 = configService.getDatabaseInstanceWithType("", "test", "zallgo_order", false);
    }  
}
