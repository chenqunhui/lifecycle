$(document).ready(
	function(){
		 loadGrid();  
	}
)

function loadGrid()  
{  
    //加载数据  
    $('#itemdatas').datagrid({
        width: 'auto',  
        fit:true,               
        striped: true,  
        singleSelect : true,  
        url:'./sys.do?method=getModelKvList', 
        queryParams:{
        	type: $('input:radio:checked').val(),
        	env: $('#env-0').combobox('getValue')
        },
        //queryParams:{},  
        loadMsg:'数据加载中请稍后……',  
        pagination: true,  
        rownumbers: true,     
        columns:[[  
            {field:'key',title: 'Key',align: 'center',width:150},  
            {field:'value',title: 'Value',align: 'center',width:150},
            {field:'env',title: '环境',align: 'center',width:80,
            	formatter:function(val,rec){
            		if(val == 'dev') return '开发环境';
            		if(val == 'test') return '测试环境';
            		if(val == 'stage') return 'STG环境';
            		if(val == 'product') return '生产环境';
            		return "";
            }},
            {field:'type',title: '模板类型',align: 'center',width:150},
//            {field:'group',title: '配置组',align: 'center',width:150},
            {field:'oper',title: '操作',align: 'center',width: 80,
            	formatter:function(val,rec){
            		// href="javascript:void(0);" onclick="executeSql()" class="easyui-linkbutton"
                    return "<a href='javascript:void(0);' onclick='deleteItem("+rec.id+",\""+rec.key+"\")' class='easyui-linkbutton'>删除</a>&nbsp;&nbsp;"
                    //+"<a href='javascript:void(0);' onclick='checkItem("+rec.id+")' class='easyui-linkbutton'>检查</a>"
                    ;  
               } 
            }
        ]]  
    });  
}  

function addItem(){
	var type = $('input:radio:checked').val();
	var env = $('#env-0').combobox('getValue');
	if (type) {
		$('#type').combobox('select', type);
	}
	if (env) {
		$('#env').combobox('select', env);
	}
	$('#editwin').window('open');
}


function editSubmitForm() {
	var key = $('#key').val();
	var value = $('#value').val();
	var env = $('#env').combobox('getValue');
	var type = $('#type').combobox('getValue');
	var group = $('#group').val();
	if(key == null||key.length == 0){
		$.messager.alert("错误", "请填写key","error");  
		return;
	}
	if(value == null||value.length == 0){
		$.messager.alert("错误", "请填写默认value","error");  
		return;
	}

	var _json = jQuery.param({"method":"addModelKv","key":key ,"value":value,"env":env,"type":type,"group":group});  
    var request = $.ajax({  
        url: "./sys.do",  
        type: "POST",  
        async: false,  
        data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
        dataType: "json",  
        //contentType: "charset=utf-8",  
        cache: false,  
        success: function(data, textStatus) {  
        	$('#editwin').window('close');
        	loadGrid();
        },  
        error: function (XMLHttpRequest, textStatus, errorThrown) { 
        	
        }  
    });  
}

function editClearForm() {
	$('#editwin').window('close');
}

function deleteItem(id,name){
	$.messager.confirm('确定','确定要删除'+name+'吗？',function(r){
	    if (r){
	    	var _json = jQuery.param({"method":"delModelKv","id":id });  
	        var request = $.ajax({  
	            url: "./sys.do",  
	            type: "POST",  
	            async: false,  
	            data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
	            dataType: "json",  
	            //contentType: "charset=utf-8",  
	            cache: false,  
	            success: function(data, textStatus) {  
	            	loadGrid();
	            },  
	            error: function (XMLHttpRequest, textStatus, errorThrown) { 
	            	
	            }  
	        });  
	    }
	});
}

