$(document).ready(
	function(){
		 loadGrid();  
	}
)

function loadGrid()  
{  
    //加载数据  
    $('#itemdatas').datagrid({  
        width: 'auto',  
        fit:true,               
        striped: true,  
        singleSelect : true,  
        url:'./sys.do?method=getDbList',  
                //queryParams:{},  
                loadMsg:'数据加载中请稍后……',  
                pagination: true,  
                rownumbers: true,     
                columns:[[  
                    {field:'dbname',title: '数据库名称',align: 'center',width:150},  
                    {field:'dbalias',title: '数据库别名',align: 'center',width:150},  
                    {field:'oper',title: '操作',align: 'center',width: 80,
                    	formatter:function(val,rec){  
                    		// href="javascript:void(0);" onclick="executeSql()" class="easyui-linkbutton"
                            return "<a href='javascript:void(0);' onclick='deleteItem("+rec.id+",\""+rec.dbalias+"\")' class='easyui-linkbutton'>删除</a>&nbsp;&nbsp;"
                            //+"<a href='javascript:void(0);' onclick='checkItem("+rec.id+")' class='easyui-linkbutton'>检查</a>"
                            ;  
                       } 
                    }                                                  
                ]]  
            });  
}  

function addItem(){
	$('#editwin').window('open');
}


function editSubmitForm() {
	var dbName = $('#dbName').val();
	var dbAlias = $('#dbAlias').val();
	if(dbName == null||dbName.length == 0){
		$.messager.alert("错误", "请填写数据库名称","error");  
		return;
	}
	if(dbAlias == null||dbAlias.length == 0){
		$.messager.alert("错误", "请填写数据库别名","error");  
		return;
	}

	var _json = jQuery.param({"method":"addDb","dbName":dbName ,"dbAlias":dbAlias});  
    var request = $.ajax({  
        url: "./sys.do",  
        type: "POST",  
        async: false,  
        data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
        dataType: "json",  
        //contentType: "charset=utf-8",  
        cache: false,  
        success: function(data, textStatus) {  
        	$('#editwin').window('close');
        	loadGrid();
        },  
        error: function (XMLHttpRequest, textStatus, errorThrown) { 
        	
        }  
    });  
}

function editClearForm() {
	$('#editwin').window('close');
}

function deleteItem(id,name){
	$.messager.confirm('确定','确定要删除'+name+'吗？',function(r){
	    if (r){
	    	var _json = jQuery.param({"method":"delDb","id":id });  
	        var request = $.ajax({  
	            url: "./sys.do",  
	            type: "POST",  
	            async: false,  
	            data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
	            dataType: "json",  
	            //contentType: "charset=utf-8",  
	            cache: false,  
	            success: function(data, textStatus) {  
	            	loadGrid();
	            },  
	            error: function (XMLHttpRequest, textStatus, errorThrown) { 
	            	
	            }  
	        });  
	    }
	});
}

