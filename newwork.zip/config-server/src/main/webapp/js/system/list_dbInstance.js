$(document).ready(
	function(){
		 loadGrid();  
		 $('dbName').attr('readonly',true);
		 $('#dbs').combobox({
			 onChange: function (n, o) {
				 var db = $('#dbs').combobox('getValue');
					$('#defaultDb').val(db);
					 loadGrid() ;
			 }
		});
	}
)

function loadGrid()  
{  
	var defaultDb = $('#defaultDb').val();
    //加载数据  
    $('#itemdatas').datagrid({  
        width: 'auto',  
        fit:true,               
        striped: true,  
        singleSelect : true,  
        url:'./sys.do?method=getDbInstanceList&dbid='+defaultDb,  
                //queryParams:{},  
                loadMsg:'数据加载中请稍后……',  
                pagination: true,  
                rownumbers: true,     
                columns:[[  
                    {field:'dbname',title: '数据库名称',align: 'center',width:120},  
                    {field:'dbalias',title: '数据库别名',align: 'center',width:120}, 
                    {field:'server',title: '服务域名',align: 'center',width:120}, 
                    {field:'port',title: '服务端口',align: 'center',width:80},
                    {field:'user',title: '登录用户',align: 'center',width:80},
                    {field:'password',title: '登录密码',align: 'center',width:120},
                    {field:'env',title: '环境',align: 'center',width:80,
                    	formatter:function(val,rec){
                    		if(val == 'dev') return '开发环境';
                    		if(val == 'test') return '测试环境';
                    		if(val == 'stage') return 'STG环境';
                    		if(val == 'product') return '生产环境';
                    		return "";
                    }}, 
                    {field:'master',title: '主备',align: 'center',width:80,
                    	formatter:function(val,rec){
                    		if(val == 'master') return 'Master';
                    		if(val == 'slave') return 'Slave';
                    		return "";
                    }}, 
                    {field:'oper',title: '操作',align: 'center',width: 80,
                    	formatter:function(val,rec){  
                    		// href="javascript:void(0);" onclick="executeSql()" class="easyui-linkbutton"
                            return "<a href='javascript:void(0);' onclick='deleteItem("+rec.id+",\""+rec.dbalias+"\")' class='easyui-linkbutton'>删除</a>&nbsp;&nbsp;"
                            //+"<a href='javascript:void(0);' onclick='checkItem("+rec.id+")' class='easyui-linkbutton'>检查</a>"
                            ;  
                       } 
                    }                                                  
                ]]  
            });  
}  

function addItem(){
	$('#editwin').window('open');
	var db = $('#dbs').combobox('getText');
	$('#dbName').val(db);
	$('#dbAlias').val(db);
	$('#dbServer').val("");
	$('#dbPort').val("3306");
}


function editSubmitForm() {
	var dbid = $('#defaultDb').val();
	var dbName = $('#dbName').val();
	var dbAlias = $('#dbAlias').val();
	var dbServer = $('#dbServer').val();
	var dbPort = $('#dbPort').val();
	var dbUser = $('#dbUser').val();
	var dbPass = $('#dbPass').val();
	
	var dbEnv = $('#dbEnv').combobox('getValue');
	var dbMaster = $('#dbMaster').combobox('getValue');
	if(dbName == null||dbName.length == 0){
		$.messager.alert("错误", "请填写数据库名称","error");  
		return;
	}
	if(dbAlias == null||dbAlias.length == 0){
		$.messager.alert("错误", "请填写数据库别名","error");  
		return;
	}
	if(dbServer == null||dbServer.length == 0){
		$.messager.alert("错误", "请填写服务域名","error");  
		return;
	}
	if(dbPort == null||dbPort.length == 0){
		$.messager.alert("错误", "请填写服务端口","error");  
		return;
	}
	if(dbUser == null||dbUser.length == 0){
		$.messager.alert("错误", "请填写登录用户","error");  
		return;
	}
	if(dbPass == null||dbPass.length == 0){
		$.messager.alert("错误", "请填写登录密码","error");  
		return;
	}
	
	var _json = jQuery.param({"method":"addDbInstance","dbid":dbid,"dbname":dbName ,"dbalias":dbAlias,
		"server":dbServer,"port":dbPort,"env":dbEnv,"master":dbMaster,'user':dbUser,'password':dbPass});  
    var request = $.ajax({  
        url: "./sys.do",  
        type: "POST",  
        async: false,  
        data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
        dataType: "json",  
        //contentType: "charset=utf-8",  
        cache: false,  
        success: function(data, textStatus) {  
        	$('#editwin').window('close');
        	loadGrid();
        },  
        error: function (XMLHttpRequest, textStatus, errorThrown) { 
        	
        }  
    });  
}

function editClearForm() {
	$('#editwin').window('close');
}

function deleteItem(id,name){
	$.messager.confirm('确定','确定要删除'+name+'吗？',function(r){
	    if (r){
	    	var dbid = $('#defaultDb').val();
	    	var _json = jQuery.param({"method":"delDbInstance","dbid":dbid,"id":id });  
	        var request = $.ajax({  
	            url: "./sys.do",  
	            type: "POST",  
	            async: false,  
	            data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
	            dataType: "json",  
	            //contentType: "charset=utf-8",  
	            cache: false,  
	            success: function(data, textStatus) {  
	            	loadGrid();
	            },  
	            error: function (XMLHttpRequest, textStatus, errorThrown) { 
	            	
	            }  
	        });  
	    }
	});
}

