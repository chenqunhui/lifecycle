$(document).ready(
	function(){
		 loadGrid();  
	}
)

function loadGrid()  
{  
    //加载数据  
    $('#itemdatas').datagrid({  
        width: 'auto',  
        fit:true,               
        striped: true,  
        singleSelect : true,  
        url:'./sys.do?method=getPoolList',  
                //queryParams:{},  
                loadMsg:'数据加载中请稍后……',  
                pagination: true,  
                rownumbers: true,     
                columns:[[  
                    {field:'pool',title: 'POOL名称',align: 'center',width:200},  
                    {field:'oper',title: '操作',align: 'center',width: 80,
                    	formatter:function(val,rec){  
                    		return getOper(val,rec);
                    		// href="javascript:void(0);" onclick="executeSql()" class="easyui-linkbutton"
                            //return "<a href='javascript:void(0);' onclick='deleteItem("+rec.id+",\""+rec.pool+"\")' class='easyui-linkbutton'>删除</a>&nbsp;&nbsp;"
                            //+"<a href='javascript:void(0);' onclick='checkItem("+rec.id+")' class='easyui-linkbutton'>检查</a>"
                            ;  
                       } 
                    }                                                  
                ]]  
            });  
}  

function addItem(){
	$('#editwin').window('open');
}


function editSubmitForm() {
	var poolName = $('#poolName').val();
	
	if(poolName == null||poolName.length == 0){
		$.messager.alert("错误", "请填写POOL名称","error");  
		return;
	}

	var _json = jQuery.param({"method":"addPool","poolName":poolName });  
    var request = $.ajax({  
        url: "./sys.do",  
        type: "POST",  
        async: false,  
        data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
        dataType: "json",  
        //contentType: "charset=utf-8",  
        cache: false,  
        success: function(data, textStatus) {  
        	$('#editwin').window('close');
        	loadGrid();
        },  
        error: function (XMLHttpRequest, textStatus, errorThrown) { 
        	
        }  
    });  
}

function editClearForm() {
	$('#editwin').window('close');
}

function deleteItem(id,name){
	$.messager.confirm('确定','确定要删除'+name+'吗？',function(r){
	    if (r){
	    	var _json = jQuery.param({"method":"delPool","id":id });  
	        var request = $.ajax({  
	            url: "./sys.do",  
	            type: "POST",  
	            async: false,  
	            data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
	            dataType: "json",  
	            //contentType: "charset=utf-8",  
	            cache: false,  
	            success: function(data, textStatus) {  
	            	loadGrid();
	            },  
	            error: function (XMLHttpRequest, textStatus, errorThrown) { 
	            	
	            }  
	        });  
	    }
	});
}

