$(document).ready(
	function(){
		 loadGrid();  
		 
		 $('#pools').combobox({
			 onChange: poolChange
		});
	}
)

function poolChange(n, o) {
	var pool = $('#pools').combobox('getText');
	$('#defaultPool').val(pool);
	loadGrid();
}

function loadGrid()  
{  
	
	var defaultPool = $('#defaultPool').val()
    //加载数据  
    $('#itemdatas').datagrid({  
        width: 'auto',  
        fit:true,               
        striped: true,  
        singleSelect : true,  
        url:'./sys.do?method=getGroups&pool='+defaultPool,  
                //queryParams:{},  
                loadMsg:'数据加载中请稍后……',  
                pagination: true,  
                rownumbers: true,     
                columns:[[  
                    {field:'pool',title: 'POOL名称',align: 'center',width:200},  
                    {field:'env',title: '环境',align: 'center',width:200,
                    	formatter:function(val,rec){
                    		if(rec.env == 'dev'){
                    			return "开发环境";
                    		}else if(rec.env == 'test'){
                    			return "测试环境";
                    		}else {
                    			return "";
                    		}
                    		
                    	}}, 
                    {field:'group',title: '配置组名称',align: 'center',width:200}, 
                    {field:'oper',title: '操作',align: 'center',width: 80,
                    	formatter:function(val,rec){  
                    		// href="javascript:void(0);" onclick="executeSql()" class="easyui-linkbutton"
                            return "<a href='javascript:void(0);' onclick='deleteItem("+rec.id+",\""+rec.group+"\")' class='easyui-linkbutton'>删除</a>&nbsp;&nbsp;"
                            //+"<a href='javascript:void(0);' onclick='checkItem("+rec.id+")' class='easyui-linkbutton'>检查</a>"
                            ;  
                       } 
                    }                                                  
                ]]  
            });  
}  

function addItem(){
	var pool = $('#pools').combobox('getValue');
	if(pool == null){
		$.messager.alert("错误", "请选择POOL","error");
	}else {
		$('#editwin').window('open');
	}
}


function editSubmitForm() {
	var groupName = $('#groupName').val();
	var poolName = $('#pools').combobox('getText');
	var env = $('#env').combobox('getValue');
	if(groupName == null||groupName.length == 0){
		$.messager.alert("错误", "请填写配置组名称","error");  
		return;
	}

	var _json = jQuery.param({"method":"addGroup","groupName":groupName ,"poolName":poolName,"env":env});  
    var request = $.ajax({  
        url: "./sys.do",  
        type: "POST",  
        async: false,  
        data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
        dataType: "json",  
        //contentType: "charset=utf-8",  
        cache: false,  
        success: function(data, textStatus) {  
        	$('#editwin').window('close');
        	loadGrid();
        },  
        error: function (XMLHttpRequest, textStatus, errorThrown) { 
        	
        }  
    });  
}

function editClearForm() {
	$('#editwin').window('close');
}

function deleteItem(id,name){
	$.messager.confirm('确定','确定要删除'+name+'吗？',function(r){
	    if (r){
	    	var _json = jQuery.param({"method":"delGroup","id":id });  
	        var request = $.ajax({  
	            url: "./sys.do",  
	            type: "POST",  
	            async: false,  
	            data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
	            dataType: "json",  
	            //contentType: "charset=utf-8",  
	            cache: false,  
	            success: function(data, textStatus) {  
	            	loadGrid();
	            },  
	            error: function (XMLHttpRequest, textStatus, errorThrown) { 
	            	
	            }  
	        });  
	    }
	});
}

