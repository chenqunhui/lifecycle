$(document).ready(
	function(){

		 //loadGrid();
		 $('#pools').combobox({
			 onSelect: function (n, o) {
				 var pool = $('#pools').combobox('getValue');
					$('#defaultPool').val(pool);
					$('#defaultGroup').val("");
					loadGroup();
			 }
		});
		 var defaultPool = $('#defaultPool').val();
		 if(defaultPool == null || defaultPool.length == 0){
			 var pool = $('#pools').combobox('getValue');
			 if(pool != null && pool.length >0){
				 $('#defaultPool').val(pool);
					loadGroup();
			 }
		 } else {
			 $('#pools').combobox("setValue",defaultPool);
			 loadGroup();
		 }
		
		 $("#file_upload").uploadify({  
             'buttonText' : '请选择',  
             'height' : 30,  
             'queueID':'file_queue',
             'swf' : './js/uploadify.swf',  
             //buttonImage:'./images/upload.png',
             //buttonClass:'my-uploadify-button',
             'uploader' : getRootPath()+'/uploadFile.do',  
             'width' : 120,  
             'auto':false, 
             'multi' : true,
             'fileSizeLimit' : '1000KB',
             'fileObjName'   : 'file',  
             'onUploadSuccess' : function(file, data, response) {  
            	 var fileinfo = $.parseJSON( data );
                 onFileUpload(fileinfo.fileid);
             }  
         });  
	}
)

function onFileUpload(fileid){
	var pool = $('#defaultPool').val();
	var group = $('#defaultGroup').val();
	var _json = jQuery.param({"method":"uploadProperty","pool":pool ,"group":group,
		"fileid":fileid,"env":"dev"});  
    var request = $.ajax({  
        url: "./admin.do",  
        type: "POST",  
        async: false,  
        data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
        dataType: "json",  
        //contentType: "charset=utf-8",  
        cache: false,  
        success: function(data, textStatus) {  
        	loadGrid();
        },  
        error: function (XMLHttpRequest, textStatus, errorThrown) { 
        	
        }  
    });
}

function getRootPath(){
    //获取当前网址，如： http://localhost:8083/uimcardprj/share/meun.jsp
    var curWwwPath=window.document.location.href;
    //获取主机地址之后的目录，如： uimcardprj/share/meun.jsp
    var pathName=window.document.location.pathname;
    var pos=curWwwPath.indexOf(pathName);
    //获取主机地址，如： http://localhost:8083
    var localhostPaht=curWwwPath.substring(0,pos);
    //获取带"/"的项目名，如：/uimcardprj
    var projectName=pathName.substring(0,pathName.substr(1).indexOf('/')+1);
    //projectName = "/AircrewHealth";
    return(localhostPaht+projectName);
};

function loadGroup() {
	var pool = $('#defaultPool').val();
	if ($('#groups').hasClass('combobox-f')) {
		$('#groups').combobox('clear');
	}
	
	$('#groups').combobox({
        url: './admin.do?method=getGroups&env=dev&pool='+pool,
        valueField:'id', textField:'group', required:false, editable:false,
        onSelect: function (n, o) {
			 var group = $('#groups').combobox('getValue');
			 $('#defaultGroup').val(group);
			 loadGrid();
		},
        onLoadSuccess:function(data){
        	var value = data;
        	var defaultGroup = $('#defaultGroup').val();
        	if(defaultGroup == null || defaultGroup.length == 0){
        		$('#defaultGroup').val(value[0].id);
        		$('#groups').combobox("setValue",value[0].id);
        	} else {
        		var find = false;
        		for(var i=0;i<value.length;i++){
        			if(value[i].id == defaultGroup){
        				find = true;
        				break;
        			}
        		}
        		if(find)
        			$('#groups').combobox("setValue",defaultGroup);
        		else{
        			$('#groups').combobox("setValue",value[0].id);
        			$('#defaultGroup').val(value[0].id);
        		}
        	}
        	loadGrid();
        }
    });   
}

function loadGrid() {
	var pool = $('#defaultPool').val();
	var group = $('#defaultGroup').val();
    //加载数据  
    $('#itemdatas').datagrid({
        width: 'auto',
        fit:true,
        striped: true,
        singleSelect : true,
        url:'./admin.do?method=getConfigList&env=dev&status=published&pool='+pool+'&group='+group,
            //queryParams:{},  
            loadMsg:'数据加载中请稍后……',
            pagination: true,
            rownumbers: true,
            columns:[[
                {field:'pool',title: 'Pool',align: 'center',width:200},
                {field:'group',title: '配置组',align: 'center',width:200},
                {field:'data',title: '配置文件',align: 'center',width:250},
                {field:'createtime',title: '创建时间',align: 'center',width:150},
                {field:'oper',title: '操作',align: 'center',width: 160, formatter: getOper }
            ]]
    });
}

function addTxtProperty() {
	var pool = $('#defaultPool').val();
	var group = $('#defaultGroup').val();
	addTab('添加配置文件',basePath+'/admin.do?method=editTxtProperty&env=dev&pool='+pool+'&group='+group);
}

function addDbProperty() {
	var pool = $('#defaultPool').val();
	var group = $('#defaultGroup').val();
	addTab('添加数据库配置',basePath+'/admin.do?method=editDbProperty&env=dev&pool='+pool+'&group='+group);
}

function editItem(pool,group,id) {
	addTab('编辑配置文件',basePath+'/admin.do?method=editTxtProperty&env=dev&pool='+pool+'&group='+group+"&id="+id);
}

function editDbItem (pool,group,id) {
	addTab('编辑数据库配置',basePath+'/admin.do?method=editDbProperty&env=dev&pool='+pool+'&group='+group+"&id="+id);
}

function viewItem (pool,group,id) {
	addTab('查看配置文件',basePath+'/admin.do?method=viewProperty&env=dev&pool='+pool+'&group='+group+"&id="+id);
}

function downloadItem (pool,group,id) {
	window.location.href ='./admin.do?method=downloadProperty&env=dev&pool='+pool+'&group='+group+"&id="+id;
}

function historyItem(pool,group,id) {
	addTab('历史配置',basePath+'/admin.do?method=historydProperty&env=dev&pool='+pool+'&group='+group+"&id="+id);
}

function downloadProperty(){
	var pool = $('#pools').combobox('getValue');
	var group = $('#defaultGroup').val();
	window.location.href ='./admin.do?method=downloadPropertys&env=dev&status=published&pool='+pool+'&group='+group;
}

function deleteItem(id,name){
	$.messager.confirm('确定','确定要删除'+name+'吗？',function(r){
	    if (r){
	    	var _json = jQuery.param({"method":"delConfig","id":id });  
	        var request = $.ajax({
	            url: "./admin.do",  
	            type: "POST",  
	            async: false,  
	            data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
	            dataType: "json",  
	            //contentType: "charset=utf-8",  
	            cache: false,  
	            success: function(data, textStatus) {  
	            	loadGrid();
	            },  
	            error: function (XMLHttpRequest, textStatus, errorThrown) { 
	            	
	            }  
	        });  
	    }
	});
}

function uploadProperty() {
	//$('#file_queue').html("");
	$('#uploadwin').window('open');
}

function startUpload() {
	$("#file_upload").uploadify("settings","formData",{'JSESSIONID':'${pageContext.session.id}'}); 
	$('#file_upload').uploadify('upload', '*');
}

function stopUpload() {
	$('#file_upload').uploadify('stop');
}

function closeWindow() {
	$('#file_upload').uploadify('cancel','*');
	$('#uploadwin').window('close');
}