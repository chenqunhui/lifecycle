$(document).ready(
	function(){

		 //loadGrid();  
		 $('#pools').combobox({
			 onSelect: function (n, o) {
				 var pool = $('#pools').combobox('getValue');
					$('#defaultPool').val(pool);
					$('#defaultGroup').val("");
					loadGroup();
			 }
		});
		 var defaultPool = $('#defaultPool').val();
		 if(defaultPool == null || defaultPool.length == 0){
			 var pool = $('#pools').combobox('getValue');
			 if(pool != null && pool.length >0){
				 $('#defaultPool').val(pool);
					loadGroup();
			 }
		 } else {
			 $('#pools').combobox("setValue",defaultPool);
			 loadGroup();
		 }
		
		 
		 
		 $("#file_upload").uploadify({  
             'buttonText' : '请选择',  
             'height' : 30,  
             'queueID':'file_queue',
             'swf' : './js/uploadify.swf',  
             //buttonImage:'./images/upload.png',
             //buttonClass:'my-uploadify-button',
             'uploader' : getRootPath()+'/uploadFile.do',  
             'width' : 120,  
             'auto':false, 
             'multi' : true,
             'fileSizeLimit' : '1000KB',
             'fileObjName'   : 'file',  
             'onUploadSuccess' : function(file, data, response) {  
            	 var fileinfo = $.parseJSON( data );
                 onFileUpload(fileinfo.fileid);
             }  
         });  
	}
)

function onFileUpload(fileid){
	var pool = $('#defaultPool').val();
	var group = $('#defaultGroup').val();
	var _json = jQuery.param({"method":"uploadProperty","pool":pool ,"group":group,
		"fileid":fileid,"env":"product","status":"submit"});  
    var request = $.ajax({  
        url: "./admin.do",  
        type: "POST",  
        async: false,  
        data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
        dataType: "json",  
        //contentType: "charset=utf-8",  
        cache: false,  
        success: function(data, textStatus) {  
        	loadGrid();
        },  
        error: function (XMLHttpRequest, textStatus, errorThrown) { 
        	
        }  
    });
}

function getRootPath(){
    //获取当前网址，如： http://localhost:8083/uimcardprj/share/meun.jsp
    var curWwwPath=window.document.location.href;
    //获取主机地址之后的目录，如： uimcardprj/share/meun.jsp
    var pathName=window.document.location.pathname;
    var pos=curWwwPath.indexOf(pathName);
    //获取主机地址，如： http://localhost:8083
    var localhostPaht=curWwwPath.substring(0,pos);
    //获取带"/"的项目名，如：/uimcardprj
    var projectName=pathName.substring(0,pathName.substr(1).indexOf('/')+1);
    //projectName = "/AircrewHealth";
    return(localhostPaht+projectName);
};

function loadGroup() {
	var pool = $('#defaultPool').val();
	if ($('#groups').hasClass('combobox-f')) {
		$('#groups').combobox('clear');
	}
	
	
	$('#groups').combobox({
        url: './admin.do?method=getGroups&pool='+pool+"&env=product",
        valueField:'id',   
        textField:'group',
        required:false,
        editable:false,
        
        onSelect: function (n, o) {
			 var group = $('#groups').combobox('getValue');
			 $('#defaultGroup').val(group);
			 loadGrid();	
		},
        onLoadSuccess:function(data){
        	var value = data;
        	var defaultGroup = $('#defaultGroup').val();
        	if(defaultGroup == null || defaultGroup.length == 0){
        		$('#defaultGroup').val(value[0].id);
        		$('#groups').combobox("setValue",value[0].id);
        	} else {
        		var find = false;
        		for(var i=0;i<value.length;i++){
        			if(value[i].id == defaultGroup){
        				find = true;
        				break;
        			}
        		}
        		if(find)
        			$('#groups').combobox("setValue",defaultGroup);
        		else{
        			$('#groups').combobox("setValue",value[0].id);
        			$('#defaultGroup').val(value[0].id);
        		}
        			
        	}
        	
        	loadGrid();	
        }
    });   
}

function loadGrid()  
{  
	var pool = $('#defaultPool').val();
	var group = $('#defaultGroup').val();
	
	var _json = jQuery.param({"method":"getConfigStatus","pool":pool,"group":group });  
    var request = $.ajax({  
        url: "./admin.do",  
        type: "POST",  
        async: false,  
        data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
        dataType: "json",  
        //contentType: "charset=utf-8",  
        cache: false,  
        success: function(data, textStatus) {  
        	if(data.status == 0||data.status==1){
        		$('#manage_btns').css('display','');
        		$('#submit_datas').css('display','');
        		$('#approve_datas').css('display','none');
        		$('#submit_btns').css('display','');
        		$('#cancel_btns').css('display','none');
        		$('#move_btns').css('display','');
        	} else {
        		$('#manage_btns').css('display','none');
        		$('#submit_datas').css('display','none');
        		$('#approve_datas').css('display','');
        		$('#submit_btns').css('display','none');
        		if(data.status == 2||data.status == 3){
        			$('#cancel_btns').css('display','');
        		} else {
        			
        		}
        		
        		$('#move_btns').css('display','none');
        	}
        },  
        error: function (XMLHttpRequest, textStatus, errorThrown) { 
        	
        }  
    });  
	
    $('#approvedatas').datagrid({
    	 width: 'auto',  
        fit:false,               
        striped: true,  
        singleSelect : true,  
        url:'./admin.do?method=getApproveConfigList&env=product&page=1&rows=1000&pool='+pool+'&group='+group,  
            //queryParams:{},  
            loadMsg:'数据加载中请稍后……',  
            pagination: false,  
            rownumbers: true,     
            columns:[[  
                {field:'pool',title: 'Pool',align: 'center',width:150},  
                {field:'group',title: '配置组',align: 'center',width:150},  
                {field:'datas',title: '配置文件',align: 'center',width:200,
                	formatter:function(val,rec){
                		var ret = "";
	            		for(var i=0;i<rec.files.length;i++){
	            			ret = ret +"<div>"+rec.files[i].filename+"</div>";
	            		}
	            		return ret;
                	}	
                },  
                {field:'approvedby',title: '审核者',align: 'center',width:200},  
                {field:'status',title: '状态',align: 'center',width:150,
                	formatter:function(val,rec){
                		return "<div style='color:#F00'>"+rec.status+"</div>";
                	}
                },  
                                                             
            ]] ,
         
    })
	
    //加载数据  
    $('#itemdatas').datagrid({  
        width: 'auto',  
        fit:false,               
        striped: true,  
        singleSelect : true,  
        url:'./admin.do?method=getConfigList&env=product&status=submit&page=1&rows=1000&pool='+pool+'&group='+group,  
            //queryParams:{},  
            loadMsg:'数据加载中请稍后……',  
            pagination: false,  
            rownumbers: true,     
            columns:[[  
                {field:'pool',title: 'Pool',align: 'center',width:150},  
                {field:'group',title: '配置组',align: 'center',width:150},  
                {field:'data',title: '配置文件',align: 'center',width:200},  
                {field:'createtime',title: '创建时间',align: 'center',width:150},  
                {field:'status',title: '状态',align: 'center',width:150,
                	formatter:function(val,rec){
                		return "<div style='color:#F00'>待审核</div>";
                	}
                },  
                {field:'oper',title: '操作',align: 'center',width: 160,
                  	formatter:function(val,rec){  
                  		return getOper(val,rec);
                        //return "<a href='javascript:void(0);' onclick='deleteItem("+rec.id+",\""+rec.username+"\")' class='easyui-linkbutton'>删除</a>&nbsp;&nbsp;"
                        //    ;  
                    } 
                }                                                  
            ]] ,
            
    });  
    $('#stagedatas').datagrid({  
        width: 'auto',  
        fit:false,               
        striped: true,  
        singleSelect : true,  
        url:'./admin.do?method=checkConfigList&page=1&rows=1000&pool='+pool+'&group='+group,  
            //queryParams:{},  
            loadMsg:'数据加载中请稍后……',  
            pagination: false,  
            rownumbers: true,     
            singleSelect: false,
            checkOnSelect: false, 
            columns:[[  
                { field:'ck',checkbox:true },      
                {field:'stgFileName',title: 'STG配置',align: 'center',width:200,
                	formatter:function(val,rec){  
                		if(rec.fileType !="txt"&&rec.fileType !="db")
                			return rec.stgFileName;
                		if(rec.stgFileName.length >0){
                			return "<a href='javascript:void(0);' onclick='viewItem(\""+pool+"\",\""+group+"\","+rec.stgId+")' class='easyui-linkbutton' style='margin-right:5px'>"+rec.stgFileName+"</a>"+
                			"&nbsp;&nbsp;[<a href='javascript:void(0);' onclick='diffItem("+rec.stgId+","+rec.subId+")' class='easyui-linkbutton'>比较</a>]";
                		} else {
                			return "";
                		}
                	}
                },  
                {field:'pubFileName',title: '线上配置',align: 'center',width:200,
                	formatter:function(val,rec){  
                		if(rec.fileType !="txt"&&rec.fileType !="db")
                			return rec.pubFileName;
                		if(rec.pubFileName.length >0){
                			return "<a href='javascript:void(0);' onclick='viewItem(\""+pool+"\",\""+group+"\","+rec.pubId+")' class='easyui-linkbutton' style='margin-right:5px'>"+rec.pubFileName+"</a>"+
                			"&nbsp;&nbsp;[<a href='javascript:void(0);' onclick='diffItem("+rec.pubId+","+rec.subId+")' class='easyui-linkbutton'>比较</a>]";
                		} else {
                			return "";
                		}
                	}
                },  
                {field:'subFileName',title: '待审核配置',align: 'center',width:200,
                	formatter:function(val,rec){  
                		if(rec.fileType !="txt"&&rec.fileType !="db")
                			return rec.subFileName;
                		if(rec.subFileName.length >0){
                			return "<a href='javascript:void(0);' onclick='viewItem(\""+pool+"\",\""+group+"\","+rec.subId+")' class='easyui-linkbutton' style='margin-right:5px'>"+rec.subFileName+"</a>"
                		} else {
                			return "";
                		}
                	}
                },  
                {field:'createtime',title: '与线上对比结果',align: 'center',width:200,
                	formatter:function(val,rec){  
                		if(rec.pubMD5 == rec.subMD5){
                			return "<div style='color:#000'>相等</div>";
                		} else {
                			if(rec.pubMD5 == "")
                				return "<div style='color:#45c018'>新增</div>";
                			else if(rec.subMD5 == "")
                				return "<div style='color:#F00'>删除</div>";
                			else
                				return "<div style='color:#F00'>变更</div>"
                		}
                		
                        //return "<a href='javascript:void(0);' onclick='deleteItem("+rec.id+",\""+rec.username+"\")' class='easyui-linkbutton'>删除</a>&nbsp;&nbsp;"
                        //    ;  
                    }
                }                                                 
            ]]  ,
            onLoadSuccess:function(data){//加载完毕后获取所有的checkbox遍历
            	if (data.rows.length > 0) {  
                    for (var i = 0; i < data.rows.length; i++) {  
                    	if(data.rows[i].subFileName != null && data.rows[i].subFileName.length !=0)
                            $("input[type='checkbox']")[i + 1].disabled = true;  
                    }  
                }  
          	},
          	onCheckAll: function(rows) {  
                $("input[type='checkbox']").each(function(index, el) {  
                    console.log(el.disabled)  
                    if (el.disabled) {  
                        $("#stagedatas").datagrid('uncheckRow', index - 1);//此处参考其他人的代码，原代码为unselectRow  
                    }  
                })  
            }
    });  
}  

function diffItem(lid,rid){
	addTab('添加配置文件',basePath+'/admin.do?method=diffProperty&lid='+lid +"&rid="+rid);
}

function addTxtProperty() {
	var pool = $('#defaultPool').val();
	var group = $('#defaultGroup').val();
	addTab('添加配置文件',basePath+'/admin.do?method=editTxtProperty&env=product&pool='+pool+'&group='+group);
}

function addDbProperty() {
	var pool = $('#defaultPool').val();
	var group = $('#defaultGroup').val();
	addTab('添加数据库配置',basePath+'/admin.do?method=editDbProperty&env=product&pool='+pool+'&group='+group);
}

function editItem(pool,group,id) {
	addTab('编辑配置文件',basePath+'/admin.do?method=editTxtProperty&env=product&pool='+pool+'&group='+group+"&id="+id);
}

function editDbItem (pool,group,id) {
	addTab('编辑数据库配置',basePath+'/admin.do?method=editDbProperty&env=product&pool='+pool+'&group='+group+"&id="+id);
}

function viewItem (pool,group,id) {
	addTab('查看配置文件',basePath+'/admin.do?method=viewProperty&env=product&pool='+pool+'&group='+group+"&id="+id);
}

function downloadItem (pool,group,id) {
	window.location.href ='./admin.do?method=downloadProperty&env=product&pool='+pool+'&group='+group+"&id="+id;
}

function historyItem(pool,group,id) {
	addTab('历史配置',basePath+'/admin.do?method=historydProperty&env=product&pool='+pool+'&group='+group+"&id="+id);
}

function downloadProperty(){
	var pool = $('#defaultPool').val();
	var group = $('#defaultGroup').val();
	window.location.href ='./admin.do?method=downloadPropertys&env=product&status=published&pool='+pool+'&group='+group;
}

function cancelConfig() {
	var pool = $('#defaultPool').val();
	var group = $('#defaultGroup').val();
	
	var _json = jQuery.param({"method":"cancelSubmit","pool":pool,"group":group });  
    var request = $.ajax({  
        url: "./admin.do",  
        type: "POST",  
        async: false,  
        data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
        dataType: "json",  
        //contentType: "charset=utf-8",  
        cache: false,  
        success: function(data, textStatus) {  
        	loadGrid();
        },  
        error: function (XMLHttpRequest, textStatus, errorThrown) { 
        	
        }  
    });  
}

function submitConfig() {
	var pool = $('#defaultPool').val();
	var group = $('#defaultGroup').val();
	var approver = $('#approver').val();
	if(approver==null || approver.length == 0){
		$.messager.alert("错误", "请填写审核人","error");
		return;
	}
	
	var _json = jQuery.param({"method":"submitConfig","pool":pool,"group":group,"approver":approver });  
    var request = $.ajax({  
        url: "./admin.do",  
        type: "POST",  
        async: false,  
        data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
        dataType: "json",  
        //contentType: "charset=utf-8",  
        cache: false,  
        success: function(data, textStatus) {  
        	loadGrid();
        },  
        error: function (XMLHttpRequest, textStatus, errorThrown) { 
        	
        }  
    });  
}

function deleteItem(id,name){
	$.messager.confirm('确定','确定要删除'+name+'吗？',function(r){
	    if (r){
	    	var _json = jQuery.param({"method":"delConfig","id":id });  
	        var request = $.ajax({  
	            url: "./admin.do",  
	            type: "POST",  
	            async: false,  
	            data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
	            dataType: "json",  
	            //contentType: "charset=utf-8",  
	            cache: false,  
	            success: function(data, textStatus) {  
	            	loadGrid();
	            },  
	            error: function (XMLHttpRequest, textStatus, errorThrown) { 
	            	
	            }  
	        });  
	    }
	});
}

function submitFromStage() {
	var checkedItems = $('#stagedatas').datagrid('getChecked');
	var names = [];
	$.each(checkedItems, function(index, item){
		if(item.stgId != 0)
			names.push(item.stgId);
	});               
	if(names.length == 0){
		$.messager.alert("错误", "请选中待审核配置","error");
		return;
	}
	var ids = names.join(",");
	var pool = $('#defaultPool').val();
	var group = $('#defaultGroup').val();
	var _json = jQuery.param({"method":"submitFromIds","ids":ids,"pool":pool,"group":group });  
    var request = $.ajax({  
        url: "./admin.do",  
        type: "POST",  
        async: false,  
        data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
        dataType: "json",  
        //contentType: "charset=utf-8",  
        cache: false,  
        success: function(data, textStatus) {  
        	loadGrid();
        },  
        error: function (XMLHttpRequest, textStatus, errorThrown) { 
        	
        }  
    });  
}

function submitFromProduct() {
	var checkedItems = $('#stagedatas').datagrid('getChecked');
	var names = [];
	$.each(checkedItems, function(index, item){
		if(item.pubId != 0)
			names.push(item.pubId);
	});               
	if(names.length == 0){
		$.messager.alert("错误", "请选中待审核配置","error");
		return;
	}
	var ids = names.join(",");
	var pool = $('#defaultPool').val();
	var group = $('#defaultGroup').val();
	var _json = jQuery.param({"method":"submitFromIds","ids":ids,"pool":pool,"group":group });  
    var request = $.ajax({  
        url: "./admin.do",  
        type: "POST",  
        async: false,  
        data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
        dataType: "json",  
        //contentType: "charset=utf-8",  
        cache: false,  
        success: function(data, textStatus) {  
        	loadGrid();
        },  
        error: function (XMLHttpRequest, textStatus, errorThrown) { 
        	
        }  
    });  
}


function uploadProperty() {
	//$('#file_queue').html("");
	$('#uploadwin').window('open');
}

function startUpload() {
	$("#file_upload").uploadify("settings","formData",{'JSESSIONID':'${pageContext.session.id}'}); 
	$('#file_upload').uploadify('upload', '*');
}

function stopUpload() {
	$('#file_upload').uploadify('stop');
}

function closeWindow() {
	$('#file_upload').uploadify('cancel','*');
	$('#uploadwin').window('close');
}