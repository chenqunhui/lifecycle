$(document).ready(
	function(){
		var group = $('#defaultGroup').val();
		var env = $('#env').val();
		
		 $('#groups').combobox('setValue',group);
		 
		 $('#groups').combobox({
			 editable:false,
			 onChange: function (n, o) {
				 var group = $('#groups').combobox('getValue');
				 $('#defaultGroup').val(group);
			 }
		}); 
		$('#dbparams').combobox({ 
			 url: './admin.do?method=getDbParams&env='+env,
				valueField:'id',
				textField:'name',
				required:false,
				editable:false,
				onLoadSuccess:function(data){
					document.dbparams = data;
				},
				onSelect: function (n, o) {
					var value = $('#dbparams').combobox('getValue');
					for(var i=0;i<document.dbparams.length;i++){
						if(document.dbparams[i].id == value){
							$('#dbparamvalue').val(document.dbparams[i].value);
						}
					}
				},
		});
		var defaultDb = $('#defaultDb').val();
		
		loadDb(defaultDb,env);
		
		
		 
	}
	
)
function loadDb(defaultDb,env) {
	var defaultDbInst = $('#defaultDbInst').val();
	$('#dbs').combobox({
		url: './admin.do?method=getDbs&env='+env,
		valueField:'id',
		textField:'name',
		required:false,
		editable:false,
		onChange: function (n, o) {
			 var dbid = $('#dbs').combobox('getValue');
			 $('#defaultDb').val(dbid);
			loadDbInst(null);
		},
		onLoadSuccess:function(data){
			if(defaultDb != null && defaultDb.length >0){
				$('#dbs').combobox("setValue",defaultDb);
				$('#defaultDb').val(defaultDb);
				loadDbInst(defaultDbInst);
			} else {
				var value = $('#dbs').combobox("getData");
				if(value.length >0){
					$('#dbs').combobox("setValue",value[0].id);
					$('#defaultDb').val(value[0].id);
					loadDbInst(null);
				}
			}
			//$('#defaultGroup').val(value[0].id);
			//$('#groups').combobox("setValue",value[0].id);
		}
	});
}
function loadDbInst(dbinstid){
	var dbid = $('#defaultDb').val();
	var env = $('#env').val();
	$('#dbinsts').combobox({
		url: './admin.do?method=getDbInsts&env='+env+"&dbid="+dbid,
		valueField:'id',
		textField:'name',
		required:false,
		editable:false,
		onSelect: function (n, o) {
			var value=$('#dbinsts').combobox("getValue");
			$('#defaultDbInst').val(value);
			loadDbProperty();
		},
		onLoadSuccess:function(data){
			if(dbinstid == null || dbinstid.length == "")
			{
				var value = $('#dbinsts').combobox("getData");
				if(value.length >0){
					$('#dbinsts').combobox("setValue",value[0].id);
					$('#defaultDbInst').val(value[0].id);
					loadDbProperty();
				}
			} else {
				$('#dbinsts').combobox("setValue",dbinstid);
				$('#defaultDbInst').val(dbinstid);
				//loadDbProperty();
			}
		}
	});
}

function loadDbProperty() {
	var dbid = $('#defaultDbInst').val();
	
	var _json = jQuery.param({"method":"loadDbProperty","dbid":dbid });
	var request = $.ajax({
		url: "./admin.do",
		type: "POST",
		async: false,
		data: _json, //不能直接写成 {id:"123",code:"tomcat"}
		dataType: "json",
		//contentType: "charset=utf-8",
		cache: false,
		success: function(data, textStatus) {
			if(textStatus == "success" ){
				$('#dataname').val(data.data);
				$('#content').html(data.content);
			}else {
				
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) { 
			
		}
	});
}

function modifyDbParam() {
	var item = $('#dbparams').combobox("getText");
	var value = $('#dbparamvalue').val();
	if(item == null || item.length == 0){
		$.messager.alert("操作提示", "请选择数据库参数", "error");
	}
	if(value == null || value.length == 0){
		$.messager.alert("操作提示", "请输入参数", "error");
	}
	var content = $('#content').html();
	content = Base64.encode(content);
	
	var _json = jQuery.param({"method":"updateDbParam","param":item ,"value":value,
		"content":content});
	var request = $.ajax({
		url: "./admin.do",
		type: "POST",
		async: false,
		data: _json, //不能直接写成 {id:"123",code:"tomcat"}
		dataType: "json",
		//contentType: "charset=utf-8",
		cache: false,
		success: function(data, textStatus) {
			if(textStatus == "success" ){
				$('#content').html(data.content);
				
				for(var i=0;i<document.dbparams.length;i++){
					if(document.dbparams[i].id == item){
						document.dbparams[i].value = value;
					}
				}
				/*$.messager.alert("操作提示", "文件更新成功!" , "info",function (data) {
					window.location.href = './admin.do?method=devConfig';
				});*/
			}else {
				//$.messager.alert("操作提示", "文件更新失败!", "error");
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) { 
			
		}
	}); 
}

function updateDbProperty(pool,group,data,content,env) {
	var status ;
	if (env=="product"){
		status="submit";
	}else{
		status="published";
	}
	var dbid = $('#dbinsts').combobox("getValue");
	var _json = jQuery.param({"method":"updateDbProperty","pool":pool ,"group":group,
		"data":data,"content":content,"env":env,"dbid":dbid,"status":status});
	var request = $.ajax({
		url: "./admin.do",
		type: "POST",
		async: false,
		data: _json, //不能直接写成 {id:"123",code:"tomcat"}
		dataType: "json",
		//contentType: "charset=utf-8",
		cache: false,
		success: function(data, textStatus) {
			if(data.success == true ){
				$.messager.alert("操作提示", "文件更新成功!" , "info",function (data) {
					viewConfigList(pool,group,env);
				});
			}else {
				$.messager.alert("操作提示", "文件更新失败!", "error");
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) { 
			
		}
	});
}
function addDbProperty () {
	var dataname = $('#dataname').val();
	if(dataname == null || dataname.length == 0){
		$.messager.alert("错误", "请填写配置文件名","error");
		return;
	}
	var content = $('#content').val();
	if(content == null || content.length == 0){
		$.messager.alert("错误", "请填写配置文件内容","error");
		return;
	}
	var encodeContent = Base64.encode(content);
	var group =$('#defaultGroup').val();
	var pool = $('#poolname').val();
	var env = $('#env').val();
	var dbid = $('#dbinsts').combobox("getValue");
	var status ;
	if (env=="product"){
		status="submit";
	}else{
		status="published";
	}
		
	var _json = jQuery.param({"method":"addDbProperty","pool":pool ,"group":group,
		"data":dataname,"content":encodeContent,"env":env,"dbid":dbid,"status":status});
	var request = $.ajax({
		url: "./admin.do",
		type: "POST",
		async: false,
		data: _json, //不能直接写成 {id:"123",code:"tomcat"}
		dataType: "json",
		//contentType: "charset=utf-8",
		cache: false,
		success: function(data, textStatus) {
			if(data.success == true)
			{
				$.messager.alert("操作提示", "文件添加成功!", "info",function (data) {
					viewConfigList(pool,group,env);
				});
			} else if( data.errorMessage =='文件已存在'){
				$.messager.confirm("操作提示", "文件已存在,是否覆盖原文件？", function (data) {
					if (data) {
						updateDbProperty(pool,group,dataname,encodeContent,env);
					}
				});
			}else {
				$.messager.alert("操作提示", data.errorMessage, "error");
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) { 
			
		}
	});
}

function viewConfigList(pool,group,env){
	if(env == 'dev'){
		addTab('查看配置文件',basePath+'/admin.do?method=devConfig&pool='+pool+"&group="+group);
	}
	if(env == 'test'){
		addTab('查看配置文件',basePath+'/admin.do?method=testConfig&pool='+pool+"&group="+group);
	}
	if(env == 'stage'){
		addTab('查看配置文件',basePath+'/admin.do?method=stageConfig&pool='+pool+"&group="+group);
	}
	if(env=='product') {
		addTab('查看配置文件',basePath+'/admin.do?method=productSubmitConfig&pool='+pool+"&group="+group);
	}
}