$(document).ready(
	function(){
		var pool = $('#poolname').val();
		var env = $('#env').val();
		
		 $('#groups').combobox({
			 url: './admin.do?method=getGroups&pool='+pool+"&env="+env,
		     valueField:'id',   
		     textField:'group',
		     required:false,
		     editable:false,
		     onLoadSuccess:function(data){
		    	 var group = $('#defaultGroup').val();
				 $('#groups').combobox('setValue',group);	
		     },
			 onSelect: function (n, o) {
				 var group = $('#groups').combobox('getValue');
				 $('#defaultGroup').val(group);
			 }
		});
		 
		var data = $('#dataname').val();
		if(data != null&&data.length >0){
			$('#dataname').attr("readonly","value");
			$('#groups').combobox({ disabled: true });
		}
	}
	
)
function updateTxtProperty(pool,group,data,content,env) {
	var status ;
	if (env=="product"){
		status="submit";
	}else{
		status="published";
	}
	var _json = jQuery.param({"method":"updateTxtProperty","pool":pool ,"group":group,
		"data":data,"content":content,"env":env,"status":status});  
    var request = $.ajax({  
        url: "./admin.do",  
        type: "POST",  
        async: false,  
        data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
        dataType: "json",  
        //contentType: "charset=utf-8",  
        cache: false,  
        success: function(data, textStatus) {  
        	if(data.success==true ){
        		$.messager.alert("操作提示", "文件更新成功!" , "info",function (data) {
        			viewConfigList(pool,group,env);
                });
        	}else {
        		$.messager.alert("操作提示", "文件更新失败!", "error");
        	}
        },  
        error: function (XMLHttpRequest, textStatus, errorThrown) { 
        	
        }  
    });  
}
function addTxtProperty() {
	var dataname = $('#dataname').val();
	if(dataname == null || dataname.length == 0){
		$.messager.alert("错误", "请填写配置文件名","error");  
		return;
	}
	var content = $('#content').val();
	if(content == null || content.length == 0){
		$.messager.alert("错误", "请填写配置文件内容","error");  
		return;
	}
	var encodeContent = Base64.encode(content);
	var group =  $('#defaultGroup').val();
	var pool = $('#poolname').val();
	var env = $('#env').val();
	var status ;
	if (env=="product"){
		status="submit";
	}else{
		status="published";
	}
	
	var _json = jQuery.param({"method":"addTxtProperty","pool":pool ,"group":group,
		"data":dataname,"content":encodeContent,"env":env,"status":status});  
    $.ajax({  
        url: "./admin.do",  
        type: "POST",  
        async: true,  
        data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
        dataType: "json",  
        //contentType: "charset=utf-8",  
        cache: false,  
        success: function(data, textStatus) {
        	if(data.success==true )
        	{
        		$.messager.alert("操作提示", "文件添加成功!", "info",function (data) {
        			viewConfigList(pool,group,env);
                });
        	} else if( data.errorMessage =='文件已存在'){
        		$.messager.confirm("操作提示", "文件已存在,是否覆盖原文件？", function (data) {
                    if (data) {
                    	updateTxtProperty(pool,group,dataname,encodeContent,env);
                    }
                });
        	}else {
        		$.messager.alert("操作提示", data.errorMessage, "error");
        	}
        },  
        error: function (XMLHttpRequest, textStatus, errorThrown) { 
        	
        }  
    });  
}

function getModelTxtProperty() {
	var type = $('#type').combobox('getValue');
	var group = $('#defaultGroup').val();
	var env = $('#env').val();
	$.ajax({
		url:'./sys.do?method=getModelKvList', 
        data:{
        	type: type, env: env, group: group,
        	page: 1, rows: 1000
        },
		type : "POST",
		async : true,
		dataType : "json",
		// contentType: "charset=utf-8",
		cache : false,
		success : function(data, textStatus) {
			var rs = data.rows;
			if (rs && rs.length > 0) {
				for ( var i in rs) {
					var t = rs[i].key + '=' + rs[i].value + '\n';
					$('#content').val($('#content').val() + t);
				}
			} else {
				$.messager.alert("操作提示", '配置模板不存在', "error");
			}
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {

		}
	});
}

function viewConfigList(pool,group,env){
	if(env == 'dev'){
		addTab('查看配置文件',basePath+'/admin.do?method=devConfig&pool='+pool+"&group="+group);
	}
	if(env == 'test'){
		addTab('查看配置文件',basePath+'/admin.do?method=testConfig&pool='+pool+"&group="+group);
	}
	if(env == 'stage'){
		addTab('查看配置文件',basePath+'/admin.do?method=stageConfig&pool='+pool+"&group="+group);
	}
	if(env=='product') {
		addTab('查看配置文件',basePath+'/admin.do?method=productSubmitConfig&pool='+pool+"&group="+group);
	}
}