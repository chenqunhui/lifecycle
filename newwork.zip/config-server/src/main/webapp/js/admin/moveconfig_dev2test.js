$(document).ready(
	function(){

		 //loadGrid();  
		 $('#pools').combobox({
			 onSelect: function (n, o) {
				 var pool = $('#pools').combobox('getValue');
					$('#defaultPool').val(pool);
					$('#fromGroup').val("");
					$('#toGroup').val("");
					loadGroup();
			 }
		});
		 var defaultPool = $('#defaultPool').val();
		 if(defaultPool == null || defaultPool.length == 0){
			 var pool = $('#pools').combobox('getValue');
			 if(pool != null && pool.length >0){
				 $('#defaultPool').val(pool);
					loadGroup();
			 }
		 } else {
			 $('#pools').combobox("setValue",defaultPool);
			 loadGroup();
		 }
		
	}
)

function loadGroup() {
	var pool = $('#defaultPool').val();
	if ($('#fromGroups').hasClass('combobox-f')) {
		$('#fromGroups').combobox('clear');
	}

	$('#fromGroups').combobox({
        url: './admin.do?method=getGroups&pool='+pool+'&env=dev',
        valueField:'id',   
        textField:'group',
        required:false,
        editable:false,
        
        onSelect: function (n, o) {
			 var group = $('#fromGroups').combobox('getValue');
			 $('#fromGroup').val(group);
			 loadGrid();
		},
        onLoadSuccess:function(data){
        	var value = data;
        	var defaultGroup = $('#fromGroup').val();
        	if(defaultGroup == null || defaultGroup.length == 0){
        		$('#fromGroup').val(value[0].id);
        		$('#fromGroups').combobox("setValue",value[0].id);
        	} else {
        		var find = false;
        		for(var i=0;i<value.length;i++){
        			if(value[i].id == defaultGroup){
        				find = true;
        				break;
        			}
        		}
        		if(find)
        			$('#fromGroups').combobox("setValue",defaultGroup);
        		else{
        			$('#fromGroups').combobox("setValue",value[0].id);
        			$('#fromGroup').val(value[0].id);
        		}
        	}

        	if ($('#toGroups').hasClass('combobox-f')) {
        		$('#toGroups').combobox('clear');
        	}

        	$('#toGroups').combobox({
                url: './admin.do?method=getGroups&pool='+pool+'&env=test',
                valueField:'id',
                textField:'group',
                required:false,
                editable:false,
                
                onSelect: function (n, o) {
        			 var group = $('#toGroups').combobox('getValue');
        			 $('#toGroup').val(group);
        			 loadGrid();
        		},
                onLoadSuccess:function(data){
                	var value = data;
                	var defaultGroup = $('#toGroup').val();
                	if(defaultGroup == null || defaultGroup.length == 0){
                		$('#toGroup').val(value[0].id);
                		$('#toGroups').combobox("setValue",value[0].id);
                	} else {
                		var find = false;
                		for(var i=0;i<value.length;i++){
                			if(value[i].id == defaultGroup){
                				find = true;
                				break;
                			}
                		}
                		if(find)
                			$('#toGroups').combobox("setValue",defaultGroup);
                		else{
                			$('#toGroups').combobox("setValue",value[0].id);
                			$('#toGroup').val(value[0].id);
                		}
                	}
                	loadGrid();
                }
            });
        }
    });
	
}

function loadGrid()  
{  
	var pool = $('#defaultPool').val();
	var fromGroup = $('#fromGroup').val();
	var toGroup = $('#toGroup').val();

    //加载数据  
    $('#itemdatas').datagrid({  
        width: 'auto',  
        fit:true,               
        striped: true,  
        singleSelect : true,  
        url:'./admin.do?method=checkGroupConfigs&pool='+pool+'&fromGroup='+fromGroup+'&fromEnv=dev&toGroup='+toGroup+'&toEnv=test&page=1&rows=1000',  
            //queryParams:{},  
            loadMsg:'数据加载中请稍后……',  
            pagination: false,  
            rownumbers: true,     
            columns:[[  
                {field:'stgFileName',title: 'From',align: 'center',width:200},  
                {field:'subFileName',title: 'To',align: 'center',width:200},  
                {field:'createtime',title: '复制操作',align: 'center',width: 150 ,
                	formatter:function(val,rec){
                		if(rec.stgMD5 == rec.subMD5){
                			return "<div style='color:#000'>相等</div>";
                		} else {
                			if(rec.subMD5 == "")
                				return "<div style='color:#45c018'>新增</div>";
                			else if(rec.stgMD5 == "")
                				return "<div style='color:#F00'>删除</div>";
                			else
                				return "<div style='color:#F00'>变更</div>"
                		}
                	}
                },  
                {field:'oper',title: '操作',align: 'center',width: 160,
                  	formatter:function(val,rec){  
                  		return "<a href='javascript:void(0);' onclick='diffItem("+rec.stgId+","+rec.subId+")' class='easyui-linkbutton'>比较</a>&nbsp;&nbsp;"
                            ;  
                    } 
                }                                                  
            ]]  
    });  
}  

function viewItem (pool,group,id) {
	addTab('查看配置文件',basePath+'/admin.do?method=viewProperty&env=dev&pool='+pool+'&group='+group+"&id="+id);
}

function diffItem(lid,rid){
	addTab('对比',basePath+'/admin.do?method=diffProperty&lid='+lid +"&rid="+rid+"&leftTitle=From&rightTitle=To");
}

function copyProperties() {
	var pool = $('#defaultPool').val();
	var fromGroup = $('#fromGroup').val();
	var toGroup = $('#toGroup').val();
	
	var _json = jQuery.param({"method":"copyProperties","pool":pool,"fromGroup":fromGroup,"fromEnv":"dev","toGroup":toGroup,"toEnv":"test" });  
    var request = $.ajax({  
        url: "./admin.do",  
        type: "POST",  
        async: false,  
        data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
        dataType: "json",  
        //contentType: "charset=utf-8",  
        cache: false,  
        success: function(data, textStatus) {  
        	loadGrid();
        },  
        error: function (XMLHttpRequest, textStatus, errorThrown) { 
        	
        }  
    });  
}
