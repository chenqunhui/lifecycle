$(document).ready(
	function(){
		 $('#pools').combobox({
			 onSelect: function (n, o) {
				 var pool = $('#pools').combobox('getValue');
					$('#defaultPool').val(pool);
					$('#defaultGroup').val("");
					loadGroup();
			 }
		});
		 var defaultPool = $('#defaultPool').val();
		 if(defaultPool == null || defaultPool.length == 0){
			 var pool = $('#pools').combobox('getValue');
			 if(pool != null && pool.length >0){
				 $('#defaultPool').val(pool);
					loadGroup();
			 }
		 } else {
			 $('#pools').combobox("setValue",defaultPool);
			 loadGroup();
		 }
	}
)

function loadGroup() {
	var pool = $('#defaultPool').val();
	if ($('#groups').hasClass('combobox-f')) {
		$('#groups').combobox('clear');
	}
	
	
	$('#groups').combobox({
        url: './admin.do?method=getGroups&pool='+pool+"&env=product",
        valueField:'id',   
        textField:'group',
        required:false,
        editable:false,
        
        onSelect: function (n, o) {
			 var group = $('#groups').combobox('getValue');
			 $('#defaultGroup').val(group);
			 loadGrid();	
		},
        onLoadSuccess:function(data){
        	var value = data;
        	var defaultGroup = $('#defaultGroup').val();
        	if(defaultGroup == null || defaultGroup.length == 0){
        		$('#defaultGroup').val(value[0].id);
        		$('#groups').combobox("setValue",value[0].id);
        	} else {
        		var find = false;
        		for(var i=0;i<value.length;i++){
        			if(value[i].id == defaultGroup){
        				find = true;
        				break;
        			}
        		}
        		if(find)
        			$('#groups').combobox("setValue",defaultGroup);
        		else{
        			$('#groups').combobox("setValue",value[0].id);
        			$('#defaultGroup').val(value[0].id);
        		}
        			
        	}
        	
        	loadGrid();	
        }
    });   
}

function loadGrid()  
{  
	var pool = $('#defaultPool').val();
	var group = $('#defaultGroup').val();
	
	$('#itemdatas').datagrid({
    	 width: 'auto',  
        fit:false,               
        striped: true,  
        singleSelect : true,  
        url:'./admin.do?method=getMyApproveConfigList&env=product&page=1&rows=1000&pool='+pool+'&group='+group,  
            //queryParams:{},  
            loadMsg:'数据加载中请稍后……',  
            pagination: false,  
            rownumbers: true,     
            columns:[[  
                {field:'pool',title: 'Pool',align: 'center',width:150},  
                {field:'group',title: '配置组',align: 'center',width:150},  
                {field:'datas',title: '配置文件',align: 'center',width:200,
                	formatter:function(val,rec){
                		var ret = "";
	            		for(var i=0;i<rec.files.length;i++){
	            			ret = ret +"<div>"+
	            			"<a href='javascript:void(0);' onclick='viewItem(\""+pool+"\",\""+group+"\","+rec.files[i].id+")' class='easyui-linkbutton' style='margin-right:5px'>"+rec.files[i].filename+"</a>"
	            			+"</div>";
	            		}
	            		return ret;
                	}	
                },  
                {field:'approvedby',title: '审核者',align: 'center',width:200},  
                {field:'status',title: '状态',align: 'center',width:150,
                	formatter:function(val,rec){
                		return "<div style='color:#F00'>"+rec.status+"</div>";
                	}
                },  
                                                             
            ]] ,
            onLoadSuccess:function(data){//加载完毕后获取所有的checkbox遍历
            	if(data.total >0){
            		if(data.rows[0].status == '待发布'){
            			$('#cancel_btns').css('display','');
            		} else {
            			$('#cancel_btns').css('display','none');
            		}
            	} else {
            		$('#cancel_btns').css('display','none');
            	}
            		
          	},
    });
	
	
	
}  

function loadDiffs(pool,group){
	$('#stagedatas').datagrid({  
        width: 'auto',  
        fit:false,               
        striped: true,  
        singleSelect : true,  
        url:'./admin.do?method=checkConfigList&page=1&rows=1000&pool='+pool+'&group='+group,  
            //queryParams:{},  
            loadMsg:'数据加载中请稍后……',  
            pagination: false,  
            rownumbers: true,     
            singleSelect: false,
            columns:[[  
                {field:'stgFileName',title: 'STG配置',align: 'center',width:200,
                	formatter:function(val,rec){  
                		if(rec.fileType !="txt"&&rec.fileType !="db")
                			return rec.stgFileName;
                		if(rec.stgFileName.length >0){
                			return "<a href='javascript:void(0);' onclick='viewItem(\""+pool+"\",\""+group+"\","+rec.stgId+")' class='easyui-linkbutton' style='margin-right:5px'>"+rec.stgFileName+"</a>"+
                			"&nbsp;&nbsp;[<a href='javascript:void(0);' onclick='diffItem("+rec.stgId+","+rec.subId+")' class='easyui-linkbutton'>比较</a>]";
                		} else {
                			return "";
                		}
                	}
                },  
                {field:'pubFileName',title: '线上配置',align: 'center',width:200,
                	formatter:function(val,rec){  
                		if(rec.fileType !="txt"&&rec.fileType !="db")
                			return rec.pubFileName;
                		if(rec.pubFileName.length >0){
                			return "<a href='javascript:void(0);' onclick='viewItem(\""+pool+"\",\""+group+"\","+rec.pubId+")' class='easyui-linkbutton' style='margin-right:5px'>"+rec.pubFileName+"</a>"+
                			"&nbsp;&nbsp;[<a href='javascript:void(0);' onclick='diffItem("+rec.pubId+","+rec.subId+")' class='easyui-linkbutton'>比较</a>]";
                		} else {
                			return "";
                		}
                	}
                },  
                {field:'subFileName',title: '待审核配置',align: 'center',width:200,
                	formatter:function(val,rec){  
                		if(rec.fileType !="txt"&&rec.fileType !="db")
                			return rec.subFileName;
                		if(rec.subFileName.length >0){
                			return "<a href='javascript:void(0);' onclick='viewItem(\""+pool+"\",\""+group+"\","+rec.subId+")' class='easyui-linkbutton' style='margin-right:5px'>"+rec.subFileName+"</a>"
                		} else {
                			return "";
                		}
                	}
                },  
                {field:'createtime',title: '与线上对比结果',align: 'center',width:200,
                	formatter:function(val,rec){  
                		if(rec.pubMD5 == rec.subMD5){
                			return "<div style='color:#000'>相等</div>";
                		} else {
                			if(rec.pubMD5 == "")
                				return "<div style='color:#45c018'>新增</div>";
                			else if(rec.subMD5 == "")
                				return "<div style='color:#F00'>删除</div>";
                			else
                				return "<div style='color:#F00'>变更</div>"
                		}
                		
                        //return "<a href='javascript:void(0);' onclick='deleteItem("+rec.id+",\""+rec.username+"\")' class='easyui-linkbutton'>删除</a>&nbsp;&nbsp;"
                        //    ;  
                    }
                }                                                 
            ]]  ,
            onLoadSuccess:function(data){//加载完毕后获取所有的checkbox遍历
            	
          	},
          	
    });
}

function publishConfig() {
	var pool = $('#defaultPool').val();
	var group = $('#defaultGroup').val();
	
	var _json = jQuery.param({"method":"publishConfig","pool":pool,"group":group });  
    var request = $.ajax({  
        url: "./admin.do",  
        type: "POST",  
        async: false,  
        data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
        dataType: "json",  
        //contentType: "charset=utf-8",  
        cache: false,  
        success: function(data, textStatus) {  
        	loadGrid();
        },  
        error: function (XMLHttpRequest, textStatus, errorThrown) { 
        	
        }  
    });  
} 

function returnedConfig() {
	var pool = $('#defaultPool').val();
	var group = $('#defaultGroup').val();
	
	var _json = jQuery.param({"method":"returnedConfig","pool":pool,"group":group });  
    var request = $.ajax({  
        url: "./admin.do",  
        type: "POST",  
        async: false,  
        data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
        dataType: "json",  
        //contentType: "charset=utf-8",  
        cache: false,  
        success: function(data, textStatus) {  
        	loadGrid();
        },  
        error: function (XMLHttpRequest, textStatus, errorThrown) { 
        	
        }  
    });  
} 


function viewItem (pool,group,id) {
	addTab('查看配置文件',basePath+'/admin.do?method=viewProperty&env=product&pool='+pool+'&group='+group+"&id="+id);
}

function diffItem(lid,rid){
	addTab('对比',basePath+'/admin.do?method=diffProperty&lid='+lid +"&rid="+rid);
}