$(document).ready(
	function(){
		// get the baseText and newText values from the two textboxes, and split them into lines
		var left = $("#leftContent").val();
		var right = $("#rightContent").val();
		var leftTitle = $("#leftTitle").val();
		var rightTitle = $("#rightTitle").val();
	    var base = difflib.stringAsLines(left);
	    var newtxt = difflib.stringAsLines(right);

	    // create a SequenceMatcher instance that diffs the two sets of lines
	    var sm = new difflib.SequenceMatcher(base, newtxt);

	    // get the opcodes from the SequenceMatcher instance
	    // opcodes is a list of 3-tuples describing what changes should be made to the base text
	    // in order to yield the new text
	    var opcodes = sm.get_opcodes();
	    var diffoutputdiv = $("#diffoutput");
	    while (diffoutputdiv.firstChild) diffoutputdiv.removeChild(diffoutputdiv.firstChild);
	    var contextSize = $("contextSize").value;
	    contextSize = contextSize ? contextSize : null;

	    // build the diff view and add it to the current DOM
	    var html = diffview.buildView({
	        baseTextLines: base,
	        newTextLines: newtxt,
	        opcodes: opcodes,
	        // set the display titles for each resource
	        baseTextName: "当前文件",
	        newTextName: "历史文件",
	        contextSize: 300,
	        viewType: $("inline").checked ? 1 : 0
	    })
	    $("#diffoutput").html(html);

	    var head = $(".diff").children()[0];
	    $(head).html ("<tr><th style='width:30px'></th><th class='texttitle'>"+leftTitle+"</th><th style='width:30px'></th><th class='texttitle'>"+rightTitle+"</th></tr>");

	    // scroll down to the diff view window.
	    //location = url + "#diff";
		
	}
)