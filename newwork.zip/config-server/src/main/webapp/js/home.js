
$(document).ready(
	function(){
		$('#dialog').dialog('close');
	}
)

function showTabs(text,url){
   if($("#maintab").tabs('exists',text)){
      $('#maintab').tabs('select', text);
   } else {
    //打开之前关闭所有已经打开的tabs 
	   /*var tabs = $("#tb").tabs("tabs");
	   var length = tabs.length;
	   for(var i = 0; i < length; i++) {
		   var _tab = tabs[0];
		   var title = _tab.panel('options').tab.text();
           $("#tb").tabs("close", title);
	   } */  
     
       $("#maintab").tabs("add",{
           title:text,
           content:'<iframe src="'+url+'" scrolling="auto" frameborder="0" style="width:100%;height:100%;"></iframe>',
           closable:true,  
           fit:true,  
           selected:true 
        });
        //window.open(url+"?id="+tabId+"&qiymc="+qymc+"&gszch="+gszhuch,"indextab");  
   }
} 

	
	
	