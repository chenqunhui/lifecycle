$(document).ready(
	function(){
		 loadGrid();  
	}
)

function loadGrid()  
{  
	var filter = $('#filter').val();
    //加载数据  
    $('#itemdatas').datagrid({  
        width: 'auto',  
        fit:true,               
        striped: true,  
        singleSelect : true,  
        url:'./user.do?method=getUserList&filter='+filter,  
            //queryParams:{},  
            loadMsg:'数据加载中请稍后……',  
            pagination: true,  
            rownumbers: true,     
            columns:[[  
                {field:'username',title: '用户账号',align: 'center',width:200},  
                {field:'oper',title: '操作',align: 'center',width: 80,
                  	formatter:function(val,rec){  
                        return "<a href='javascript:void(0);' onclick='deleteItem("+rec.id+",\""+rec.username+"\")' class='easyui-linkbutton'>删除</a>&nbsp;&nbsp;"
                            ;  
                    } 
                }                                                  
            ]]  
    });  
}  

function addItem(){
	$('#editwin').window('open');
}


function editSubmitForm() {
	var userName = $('#userName').val();
	var password = $('#password').val();
	if(userName == null||userName.length == 0){
		$.messager.alert("错误", "请填写用户账号","error");  
		return;
	}
	if(password == null||password.length == 0){
		$.messager.alert("错误", "请填写用户密码","error");  
		return;
	}

	$('#filter').val("");
	var _json = jQuery.param({"method":"addUser","username":userName,"password": password});  
    var request = $.ajax({  
        url: "./user.do",  
        type: "POST",  
        async: false,  
        data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
        dataType: "json",  
        //contentType: "charset=utf-8",  
        cache: false,  
        success: function(data, textStatus) {  
        	$('#editwin').window('close');
        	loadGrid();
        },  
        error: function (XMLHttpRequest, textStatus, errorThrown) { 
        	
        }  
    });  
}

function editClearForm() {
	$('#editwin').window('close');
}

function deleteItem(id,name){
	$.messager.confirm('确定','确定要删除'+name+'吗？',function(r){
	    if (r){
	    	var _json = jQuery.param({"method":"delUser","id":id });  
	        var request = $.ajax({  
	            url: "./user.do",  
	            type: "POST",  
	            async: false,  
	            data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
	            dataType: "json",  
	            //contentType: "charset=utf-8",  
	            cache: false,  
	            success: function(data, textStatus) {  
	            	loadGrid();
	            },  
	            error: function (XMLHttpRequest, textStatus, errorThrown) { 
	            	
	            }  
	        });  
	    }
	});
}

function filterData() {
	loadGrid();
}
