$(document).ready(
	function(){
		 loadGrid();  
	}
)

function loadGrid()  
{  
	var filterRole = $('#filterRole').val();
	var filterAuth = $('#filterAuth').combobox('getValue');
    //加载数据  
    $('#itemdatas').datagrid({  
        width: 'auto',  
        fit:true,               
        striped: true,  
        singleSelect : true,  
        url:'./user.do?method=getRoleAuthList&filterRole='+filterRole+"&filterAuth="+filterAuth,  
            //queryParams:{},  
            loadMsg:'数据加载中请稍后……',  
            pagination: true,  
            pageSize: 20,//每页显示的记录条数，默认为10 
            pageList: [20],//可以设置每页记录条数的列表     
            rownumbers: true,     
            columns:[[  
                {field:'rolename',title: '用户角色',align: 'center',width:200}, 
                {field:'authname',title: '权限名称',align: 'center',width:200}, 
                {field:'oper',title: '操作',align: 'center',width: 80,
                  	formatter:function(val,rec){  
                        return "<a href='javascript:void(0);' onclick='deleteItem("+rec.id+",\""+rec.authname+"\")' class='easyui-linkbutton'>删除</a>&nbsp;&nbsp;"
                            ;  
                    } 
                }                                                  
            ]]  
    });  
}  

function addItem(){
	$('#editwin').window('open');
}


function editSubmitForm() {
	var rolename = $('#rolename').val();
	var authname = $('#authname').combobox('getValue');
	if(authname == null||authname.length == 0){
		$.messager.alert("错误", "请选择权限","error");  
		return;
	}
	if(rolename == null||rolename.length == 0){
		$.messager.alert("错误", "请填写用户角色","error");  
		return;
	}

	if($('#filterRole').val() != rolename){
		$('#filterRole').val("")
	}
	
	if($('#filterAuth').combobox('getValue') != authname){
		$('#filterAuth').combobox('setValue','')
	}
	var _json = jQuery.param({"method":"addRoleAuth","authname":authname,"rolename": rolename});  
    var request = $.ajax({  
        url: "./user.do",  
        type: "POST",  
        async: false,  
        data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
        dataType: "json",  
        //contentType: "charset=utf-8",  
        cache: false,  
        success: function(data, textStatus) {  
        	$('#editwin').window('close');
        	loadGrid();
        },  
        error: function (XMLHttpRequest, textStatus, errorThrown) { 
        	
        }  
    });  
}

function editClearForm() {
	$('#editwin').window('close');
}

function deleteItem(id,name){
	$.messager.confirm('确定','确定要删除'+name+'吗？',function(r){
	    if (r){
	    	var _json = jQuery.param({"method":"delRoleAuth","id":id });  
	        var request = $.ajax({  
	            url: "./user.do",  
	            type: "POST",  
	            async: false,  
	            data: _json, //不能直接写成 {id:"123",code:"tomcat"}  
	            dataType: "json",  
	            //contentType: "charset=utf-8",  
	            cache: false,  
	            success: function(data, textStatus) {  
	            	loadGrid();
	            },  
	            error: function (XMLHttpRequest, textStatus, errorThrown) { 
	            	
	            }  
	        });  
	    }
	});
}

function filterData() {
	loadGrid();
}

