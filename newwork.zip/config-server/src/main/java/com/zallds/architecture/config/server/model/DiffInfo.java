package com.zallds.architecture.config.server.model;

public class DiffInfo {
	private int stgId = 0;
	private int subId = 0;
	private int pubId = 0;
	private String stgFileName="";
	private String subFileName="";
	private String pubFileName="";
	
	private String stgMD5;
	private String subMD5;
	private String pubMD5;
	private String fileType;
	
	public int getStgId() {
		return stgId;
	}
	public void setStgId(int stgId) {
		this.stgId = stgId;
	}
	public int getSubId() {
		return subId;
	}
	public void setSubId(int subId) {
		this.subId = subId;
	}
	public int getPubId() {
		return pubId;
	}
	public void setPubId(int pubId) {
		this.pubId = pubId;
	}
	public String getStgFileName() {
		return stgFileName;
	}
	public void setStgFileName(String stgFileName) {
		this.stgFileName = stgFileName;
	}
	public String getSubFileName() {
		return subFileName;
	}
	public void setSubFileName(String subFileName) {
		this.subFileName = subFileName;
	}
	public String getPubFileName() {
		return pubFileName;
	}
	public void setPubFileName(String pubFileName) {
		this.pubFileName = pubFileName;
	}
	public String getStgMD5() {
		return stgMD5;
	}
	public void setStgMD5(String stgMD5) {
		this.stgMD5 = stgMD5;
	}
	public String getSubMD5() {
		return subMD5;
	}
	public void setSubMD5(String subMD5) {
		this.subMD5 = subMD5;
	}
	public String getPubMD5() {
		return pubMD5;
	}
	public void setPubMD5(String pubMD5) {
		this.pubMD5 = pubMD5;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	
}
