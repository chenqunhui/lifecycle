package com.zallds.architecture.config.server.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.dao.DataAccessException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.util.CollectionUtils;

import com.zallds.architecture.config.server.dao.ConfigDao;


public class ConfigUserDetailService implements UserDetailsService, InitializingBean {

	private ConfigDao configDao;
	private String defaultAuthConfig;
	private Set<String> defaultAuthSet;
	
	public Set<String> getDefaultAuthSet() {
		return defaultAuthSet;
	}

	public void setDefaultAuthSet(Set<String> defaultAuthSet) {
		this.defaultAuthSet = defaultAuthSet;
	}

	public String getDefaultAuthConfig() {
		return defaultAuthConfig;
	}

	public void setDefaultAuthConfig(String defaultAuthConfig) {
		this.defaultAuthConfig = defaultAuthConfig;
	}
	

	//@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException, DataAccessException {
		Collection<GrantedAuthority> auths = new ArrayList<GrantedAuthority>();
		
		List<String> roles = new ArrayList<String>();//configDao.findUserAuthorities(username);
		//List<String> roles = null;
		if(!CollectionUtils.isEmpty(roles)) {
			for(String role : roles) {
				SimpleGrantedAuthority auth = new SimpleGrantedAuthority(role);
				auths.add(auth);
			}
			if(username.toLowerCase().equals("zhengchen")){
				auths.add(new SimpleGrantedAuthority("VIEW_SYSTEM"));
				auths.add(new SimpleGrantedAuthority("MANAGE_AUTH"));
				auths.add(new SimpleGrantedAuthority("MANAGE_SYS_POOL"));
				auths.add(new SimpleGrantedAuthority("MANAGE_SYS_CONFIGDB"));
				
			}
		} else {
			auths.add(new SimpleGrantedAuthority("BASIC"));

			if(defaultAuthSet != null) {
				for(String auth : defaultAuthSet) {
					auths.add(new SimpleGrantedAuthority(auth));
				}
			}
		}
		
		User user = new User(username, username, true, true, true, true, auths);
		return user;
	}

	//@Override
	public void afterPropertiesSet() throws Exception {
		if(!StringUtils.isBlank(defaultAuthConfig)) {
			String[] auths = defaultAuthConfig.split(",");
			defaultAuthSet = new HashSet<String>();
			for(String auth : auths) {
				if(!StringUtils.isBlank(auth)) {
					defaultAuthSet.add(auth.trim());
				}
			}
		}
	}

	public ConfigDao getConfigDao() {
		return configDao;
	}

	public void setConfigDao(ConfigDao configDao) {
		this.configDao = configDao;
	}

}
