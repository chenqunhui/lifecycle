package com.zallds.architecture.portal.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.zallds.architecture.portal.service.IApplicationInfoQryService;
import com.zallds.architecture.portal.vo.AppModule;
import com.zallds.architecture.portal.vo.AppRole;

public class AppInfoQryServiceImpl implements IApplicationInfoQryService {

	@Value("${site.root}")
	private String SITE_ROOT;
	
	@Autowired
	HttpSession session;
//	@Autowired
//	private ConfigUserDetailService configUserDetailService;
//	@Autowired
//	private ConfigDao configDao;
	
	@Override
	public List<AppRole> qryAppRoles() {

		List<AppRole> appRoles = new ArrayList<AppRole>();
		
//		List<HashMap> roles = configDao.getAllRoles();
//		if (roles != null) {
//			for (HashMap role : roles) {
//				String roleName = (String) role.get("name");
//				String roleCode = (String) role.get("id");
//				appRoles.add(new AppRole(roleName, roleCode));
//			}
//		}
		
		appRoles.add(new AppRole(AppRoleEnum.BASIC              .getName(), AppRoleEnum.BASIC              .getRoleCode()));
		appRoles.add(new AppRole(AppRoleEnum.VIEW_DEV           .getName(), AppRoleEnum.VIEW_DEV           .getRoleCode()));
		appRoles.add(new AppRole(AppRoleEnum.VIEW_TEST          .getName(), AppRoleEnum.VIEW_TEST          .getRoleCode()));
		appRoles.add(new AppRole(AppRoleEnum.VIEW_STAGE         .getName(), AppRoleEnum.VIEW_STAGE         .getRoleCode()));
		appRoles.add(new AppRole(AppRoleEnum.VIEW_SYSTEM        .getName(), AppRoleEnum.VIEW_SYSTEM        .getRoleCode()));
		
		appRoles.add(new AppRole(AppRoleEnum.MANAGE_DEV         .getName(), AppRoleEnum.MANAGE_DEV         .getRoleCode()));
		appRoles.add(new AppRole(AppRoleEnum.MANAGE_TEST        .getName(), AppRoleEnum.MANAGE_TEST        .getRoleCode()));
		appRoles.add(new AppRole(AppRoleEnum.MANAGE_STAGE        .getName(), AppRoleEnum.MANAGE_STAGE        .getRoleCode()));
		appRoles.add(new AppRole(AppRoleEnum.MANAGE_PRODUCT     .getName(), AppRoleEnum.MANAGE_PRODUCT     .getRoleCode()));
		appRoles.add(new AppRole(AppRoleEnum.VIEW_PRODUCT       .getName(), AppRoleEnum.VIEW_PRODUCT       .getRoleCode()));
		
		appRoles.add(new AppRole(AppRoleEnum.MANAGE_SYS_GROUP   .getName(), AppRoleEnum.MANAGE_SYS_GROUP   .getRoleCode()));
		appRoles.add(new AppRole(AppRoleEnum.MANAGE_SYS_POOL    .getName(), AppRoleEnum.MANAGE_SYS_POOL    .getRoleCode()));
		appRoles.add(new AppRole(AppRoleEnum.MANAGE_SYS_CONFIG.getName(), AppRoleEnum.MANAGE_SYS_CONFIG.getRoleCode()));
		appRoles.add(new AppRole(AppRoleEnum.MANAGE_SYS_CONFIGDB.getName(), AppRoleEnum.MANAGE_SYS_CONFIGDB.getRoleCode()));
		appRoles.add(new AppRole(AppRoleEnum.MANAGE_AUTH        .getName(), AppRoleEnum.MANAGE_AUTH        .getRoleCode()));
		return appRoles;
	}

	public AppModule convertAppModule(AppModuleEnum enu) {
		AppModule appModule = new AppModule();
		appModule.setCode(enu.getCode());
		appModule.setParentCode(enu.getParentCode());
		appModule.setIsLeaf(enu.getIsLeaf());
		appModule.setIcon(enu.getIcon());
		appModule.setUrl(StringUtils.isEmpty(enu.getUrl()) ? "" : SITE_ROOT + enu.getUrl());
		appModule.setName(enu.getName());
		appModule.setIsNewFrame(enu.getIsNewFrame());
		return appModule;
	}
	
	@Override
	public List<AppModule> qryAppSelfModules(String arg0, String arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<AppModule> qryAppRoleModules(String auth) {

		if (StringUtils.isBlank(auth)) {
			return null;
		}
		
//		Set<String> auths = configDao.getAuthsByRole(roleCode);
//		for (String auth : auths) {
//		}

		List<AppModule> appModules = new ArrayList<AppModule>();
		appModules.add(convertAppModule(AppModuleEnum.SYS_HOME));

		if ("VIEW_DEV".equals(auth)) {
			appModules.add(convertAppModule(AppModuleEnum.APP_DEV));//VIEW_DEV
			appModules.add(convertAppModule(AppModuleEnum.APP_DEV_CFG));//VIEW_DEV
		} else if ("MANAGE_DEV".equals(auth)) {
			appModules.add(convertAppModule(AppModuleEnum.APP_DEV_CFG_FROM_DEV));//MANAGE_DEV
		} else if ("VIEW_TEST".equals(auth)) {
			appModules.add(convertAppModule(AppModuleEnum.APP_TEST));//VIEW_TEST
			appModules.add(convertAppModule(AppModuleEnum.APP_TEST_CFG));//VIEW_TEST
		} else if ("MANAGE_TEST".equals(auth)) {
			appModules.add(convertAppModule(AppModuleEnum.APP_TEST_CFG_FROM_DEV));//MANAGE_TEST
			appModules.add(convertAppModule(AppModuleEnum.APP_TEST_CFG_FROM_TEST));//MANAGE_TEST
		} else if ("VIEW_STAGE".equals(auth)) {
			appModules.add(convertAppModule(AppModuleEnum.APP_STG));//VIEW_STAGE
			appModules.add(convertAppModule(AppModuleEnum.APP_STG_CFG));//VIEW_STAGE
		} else if ("VIEW_PRODUCT".equals(auth)) {
			appModules.add(convertAppModule(AppModuleEnum.APP_PRD));//VIEW_PRODUCT
			appModules.add(convertAppModule(AppModuleEnum.APP_PRD_CFG_PUBLISHED));//VIEW_PRODUCT
		} else if ("MANAGE_PRODUCT".equals(auth)) {
			appModules.add(convertAppModule(AppModuleEnum.APP_PRD_CFG_SUBMIT));//MANAGE_PRODUCT
			appModules.add(convertAppModule(AppModuleEnum.APP_PRD_CFG_APPROVE));//MANAGE_PRODUCT
			appModules.add(convertAppModule(AppModuleEnum.APP_PRD_CFG_PUBLISH));//MANAGE_PRODUCT
		} else if ("VIEW_SYSTEM".equals(auth)) {
			appModules.add(convertAppModule(AppModuleEnum.APP_SETTING));//VIEW_SYSTEM
//		} else if ("MANAGE_SYS_POOL".equals(auth)) {
//			appModules.add(convertAppModule(AppModuleEnum.APP_SETTING_POOL));//MANAGE_SYS_POOL
		} else if ("MANAGE_SYS_GROUP".equals(auth)) {

			String globalPath = System.getProperty("global.config.path");
			if (StringUtils.isBlank(globalPath)) {
				globalPath = System.getenv("global.config.path");
//				if (StringUtils.isBlank(globalPath)) {
//					URL url = ZalldsGlobalPropertyConfigurer.class.getResource("/env.ini");
//					if (url != null) {
//						globalPath = new File(url.getFile()).getParent();
//						System.setProperty("global.config.path", globalPath);
//					} else {
//						throw new IllegalArgumentException("env.ini is required");
//					}
//				} else {
//					System.setProperty("global.config.path", globalPath);
//				}
			}
			File rootEnvFile = new File(globalPath, File.separator + "zallds" + File.separator + "env.ini");
			File envFile = null;
			if (rootEnvFile.exists()) {
				envFile = rootEnvFile;
			} else {
				envFile = new File(globalPath, File.separator + "env.ini");
			}
			Hashtable<String, String> baseProperty = null;
			if (envFile != null) {
				baseProperty = loadProperties(envFile);
			}
			String env = (String) baseProperty.get("config.env");

			if ("dev".equals(env) || "test".equals(env)) {
				appModules.add(convertAppModule(AppModuleEnum.APP_SETTING_GROUP));// MANAGE_SYS_GROUP
			}
		} else if ("MANAGE_SYS_CONFIG".equals(auth)) {
			appModules.add(convertAppModule(AppModuleEnum.APP_SETTING_MODEL_KV));//MANAGE_SYS_CONFIG
		} else if ("MANAGE_SYS_CONFIGDB".equals(auth)) {
			appModules.add(convertAppModule(AppModuleEnum.APP_SETTING_DB));//MANAGE_SYS_CONFIGDB
			appModules.add(convertAppModule(AppModuleEnum.APP_SETTING_DB_INSTANCE));//MANAGE_SYS_CONFIGDB
			appModules.add(convertAppModule(AppModuleEnum.APP_SETTING_DB_KV));//MANAGE_SYS_CONFIGDB
			appModules.add(convertAppModule(AppModuleEnum.APP_SETTING_MODEL_KV));//MANAGE_SYS_CONFIGDB
//			appModules.add(convertAppModule(AppModuleEnum.APP_SETTING_DB_CONTACT));//MANAGE_SYS_CONFIGDB
//		} else if ("MANAGE_AUTH".equals(auth)) {
//			appModules.add(convertAppModule(AppModuleEnum.APP_USER));//MANAGE_AUTH
//			appModules.add(convertAppModule(AppModuleEnum.APP_USER_LIST));//MANAGE_AUTH
//			appModules.add(convertAppModule(AppModuleEnum.APP_USER_ROLE));//MANAGE_AUTH
//			appModules.add(convertAppModule(AppModuleEnum.APP_USER_ROLE_AUTH));//MANAGE_AUTH
//			appModules.add(convertAppModule(AppModuleEnum.APP_USER_POOL));//MANAGE_AUTH
		}
		return appModules;
	}

	public static Hashtable<String, String> loadProperties(File propFile) {
		if (!propFile.exists()) {
			throw new RuntimeException("Config file <" + propFile.getAbsolutePath() + "> doesn't exists.");
		}
		Properties prop = new Properties();
		try {
			InputStreamReader isr = new InputStreamReader(new FileInputStream(propFile), "utf-8");

			prop.load(isr);
			isr.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		Hashtable<String, String> result = new Hashtable<String, String>();
		for (Object okey : prop.keySet()) {
			String key = (String) okey;
			String value = prop.getProperty(key);
			result.put(key, value);
		}
		return result;
	}
}

enum AppModuleEnum {

	SYS_HOME("0", "1", "", "配置中心", 0, 0, ""),
	
	APP_DEV("1", "2", "", "开发环境", 0, 0, ""),//VIEW_DEV
	APP_DEV_CFG("2", "20", "/admin.do?method=devConfig", "开发环境配置管理", 1, 1, ""),//VIEW_DEV
	APP_DEV_CFG_FROM_DEV("2", "21", "/admin.do?method=moveConfigFromDevToDev", "开发间配置组复制", 1, 1, ""),//MANAGE_DEV
	
	APP_TEST("1", "3", "", "测试环境", 0, 0, ""),//VIEW_TEST
	APP_TEST_CFG("3", "30", "/admin.do?method=testConfig", "测试环境配置管理", 1, 1, ""),//VIEW_TEST
	APP_TEST_CFG_FROM_DEV("3", "31", "/admin.do?method=moveConfigFromDevToTest", "开发至测试配置组复制", 1, 1, ""),//MANAGE_TEST
	APP_TEST_CFG_FROM_TEST("3", "32", "/admin.do?method=moveConfigFromTestToTest", "测试间配置组复制", 1, 1, ""),//MANAGE_TEST
	
	APP_STG("1", "4", "", "STG环境", 0, 0, ""),//VIEW_STAGE
	APP_STG_CFG("4", "40", "/admin.do?method=stageConfig", "STG环境配置管理", 1, 1, ""),//VIEW_STAGE
	
	APP_PRD("1", "5", "", "生产环境", 0, 0, ""),//VIEW_PRODUCT
	APP_PRD_CFG_SUBMIT("5", "50", "/admin.do?method=productSubmitConfig", "待审核配置管理", 1, 1, ""),//MANAGE_PRODUCT
	APP_PRD_CFG_APPROVE("5", "51", "/admin.do?method=productApproveConfig", "审核配置管理", 1, 1, ""),//MANAGE_PRODUCT
	APP_PRD_CFG_PUBLISH("5", "52", "/admin.do?method=productPublishConfig", "发布配置管理", 1, 1, ""),//MANAGE_PRODUCT
	APP_PRD_CFG_PUBLISHED("5", "53", "/admin.do?method=productPublishedConfig", "已发布配置管理", 1, 1, ""),//VIEW_PRODUCT
	
	APP_SETTING("1", "6", "", "系统设置", 0, 0, ""),//VIEW_SYSTEM
	APP_SETTING_POOL("6", "60", "/sys.do?method=listPool", "POOL管理", 1, 1, ""),//MANAGE_SYS_POOL
	APP_SETTING_GROUP("6", "61", "/sys.do?method=listGroup", "配置组管理", 1, 1, ""),//MANAGE_SYS_GROUP
	APP_SETTING_DB("6", "62", "/sys.do?method=listDb", "数据库管理", 1, 1, ""),//MANAGE_SYS_CONFIGDB
	APP_SETTING_DB_INSTANCE("6", "63", "/sys.do?method=listDbInstance", "数据库实例管理", 1, 1, ""),//MANAGE_SYS_CONFIGDB
	APP_SETTING_DB_KV("6", "64", "/sys.do?method=listDbKv", "数据库KV管理", 1, 1, ""),//MANAGE_SYS_CONFIGDB
//	APP_SETTING_DB_CONTACT("6", "65", "/sys.do?method=listDbContact", "数据库和配置组关系管理", 1, 1, ""),//MANAGE_SYS_CONFIGDB
	APP_SETTING_MODEL_KV("6", "66", "/sys.do?method=listModelKv", "配置模板KV管理", 1, 1, "");//MANAGE_SYS_GROUP
	
//	APP_USER("1", "7", "", "授权管理", 0, 0, ""),//MANAGE_AUTH
//	APP_USER_LIST("7", "70", "/user.do?method=listUser", "配置用户管理", 1, 1, ""),//MANAGE_AUTH
//	APP_USER_ROLE("7", "71", "/user.do?method=listUserRole", "用户角色管理", 1, 1, ""),//MANAGE_AUTH
//	APP_USER_ROLE_AUTH("7", "72", "/user.do?method=listRoleAuth", "角色权限管理", 1, 1, ""),//MANAGE_AUTH
//	APP_USER_POOL("7", "73", "/user.do?method=listUserPool", "用户POOL管理", 1, 1, "");//MANAGE_AUTH


	private String parentCode;
	private String code;
	private String url;
	private String name;
	private Integer isNewFrame;
	private Integer isLeaf;
	private String icon;
	
	/**
	 * <p>
	 * Title:
	 * </p>
	 * <p>
	 * Description:
	 * </p>
	 * 
	 * @param parentCode
	 * @param code
	 * @param url
	 * @param name
	 * @param isLeaf
	 * @param icon
	 */
	private AppModuleEnum(String parentCode, String code, String url, String name, Integer isNewFrame, Integer isLeaf, String icon) {
		this.parentCode = parentCode;
		this.code = code;
		this.url = url;
		this.name = name;
		this.isNewFrame = isNewFrame;
		this.isLeaf = isLeaf;
		this.icon = icon;
	}

	public String getParentCode() {
		return parentCode;
	}

	public void setParentCode(String parentCode) {
		this.parentCode = parentCode;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getIsNewFrame() {
		return isNewFrame;
	}

	public void setIsNewFrame(Integer isNewFrame) {
		this.isNewFrame = isNewFrame;
	}

	public Integer getIsLeaf() {
		return isLeaf;
	}

	public void setIsLeaf(Integer isLeaf) {
		this.isLeaf = isLeaf;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

}


enum AppRoleEnum {

	BASIC            	("基础权限", "BASIC"),
	VIEW_DEV            ("访问开发环境", "VIEW_DEV"),
	VIEW_TEST           ("访问测试环境", "VIEW_TEST"),
	VIEW_STAGE          ("访问STG环境", "VIEW_STAGE"),
	VIEW_PRODUCT        ("访问生产环境", "VIEW_PRODUCT"),
	VIEW_SYSTEM         ("访问系统", "VIEW_SYSTEM"),
	MANAGE_SYS_GROUP    ("管理配置组", "MANAGE_SYS_GROUP"),
	MANAGE_SYS_POOL     ("管理应用", "MANAGE_SYS_POOL"),
	MANAGE_SYS_CONFIG ("管理系统配置", "MANAGE_SYS_CONFIG"),
	MANAGE_SYS_CONFIGDB ("管理数据库配置", "MANAGE_SYS_CONFIGDB"),
	MANAGE_AUTH         ("管理权限", "MANAGE_AUTH"),
	MANAGE_DEV          ("管理开发环境", "MANAGE_DEV"),
	MANAGE_TEST         ("管理测试环境", "MANAGE_TEST"),
	MANAGE_STAGE         ("管理STG环境", "MANAGE_STAGE"),
	MANAGE_PRODUCT      ("管理生产环境", "MANAGE_PRODUCT");

	private String name;
	private String roleCode;

	/**
	 * <p>
	 * Title:
	 * </p>
	 * <p>
	 * Description:
	 * </p>
	 * 
	 * @param name
	 * @param roleCode
	 */
	private AppRoleEnum(String name, String roleCode) {
		this.name = name;
		this.roleCode = roleCode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

}
