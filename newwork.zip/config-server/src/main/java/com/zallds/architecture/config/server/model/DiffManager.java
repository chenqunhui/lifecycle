package com.zallds.architecture.config.server.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DiffManager {
	public static int STAGE = 1;
	public static int SUBMIT = 2;
	public static int PUBLISH = 3;
	private List<DiffInfo> diffList = new ArrayList<DiffInfo>();
	
	private HashMap diffMap = new HashMap();
	public List<DiffInfo> getDiffList() {
		return diffList;
	}
	public void addFile(int env,int id,String fileName,String md5,String filetype){
		DiffInfo diff = (DiffInfo) diffMap.get(fileName);
		if(diff == null){
			diff = new DiffInfo();
			diffMap.put(fileName, diff);
			diffList.add(diff);
		}
		if(env == STAGE){
			diff.setStgId(id);
			diff.setStgFileName(fileName);
			diff.setStgMD5(md5);
		} else if(env == SUBMIT){
			diff.setSubId(id);
			diff.setSubFileName(fileName);
			diff.setSubMD5(md5);
		} else {
			diff.setPubId(id);
			diff.setPubFileName(fileName);
			diff.setPubMD5(md5);
		}
		diff.setFileType(filetype);
	}
}
