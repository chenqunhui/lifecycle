package com.zallds.architecture.config.server.security;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

public class LDAPTools {
	public static boolean checkUser(String ldapserver,String userName,String password){
		//String host = "192.168.62.100";  //AD服务器
		String host = ldapserver;  //AD服务器
		String port = "389";              //端口
		String domain = "@zallds.com";    //邮箱的后缀名
		String url = new String("ldap://" + host + ":" + port);
		String user = userName.indexOf(domain) > 0 ? userName : userName + domain;

		Hashtable env = new Hashtable();
		DirContext ctx;
		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL, user); //不带邮箱后缀名的话，会报错，具体原因还未探究。高手可以解释分享。
		env.put(Context.SECURITY_CREDENTIALS, password);
		env.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, url);
		try {
			ctx = new InitialDirContext(env);
			ctx.close();
			return true;
		} catch (NamingException err) {
			return false;
		}
	}
}
