package com.zallds.architecture.config.server.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zallds.architecture.config.ConfigService;
import com.zallds.architecture.config.model.DBInfo;
import com.zallds.architecture.config.model.DBInstance;
import com.zallds.architecture.config.server.dao.ConfigDao;

@Service("configService")
public class ConfigServiceImpl implements ConfigService{

	@Autowired
	private ConfigDao configDao;
	
	public List<DBInfo> getDatabases(String pool,String env) {
		List<HashMap> datas = configDao.getDbs(env, 0, 1000);
		List<DBInfo> list = new ArrayList<DBInfo>();
		for(int i=0;i<datas.size();i++){
			HashMap item = datas.get(i);
			DBInfo info = new DBInfo();
			info.setName((String)item.get("name"));
			info.setAlias((String)item.get("dbalias"));
			list.add(info);
		}
		return list;
	}

	public List<DBInstance> getDatabaseInstance(String pool, String env, String dbname) {
		
		List<HashMap> datas = configDao.getDbInstancesByName(env, dbname);
//		System.out.println("getDatabaseInstance:"+dbname+" count:"+datas.size());
		List<DBInstance> list = new ArrayList<DBInstance>();
		for(int i=0;i<datas.size();i++){
			HashMap item = datas.get(i);
			DBInstance info = new DBInstance();
			info.setName((String)item.get("dbname"));
			info.setAlias((String)item.get("dbalias"));
			info.setHost((String)item.get("server"));
			info.setPort((Integer)item.get("port"));
			info.setUser((String)item.get("user"));
			info.setPassword((String)item.get("password"));
			String master = (String)item.get("master");
			info.setMaster("master".equals(master));
			list.add(info);
		}
		return list;
	}

	public DBInstance getDatabaseInstanceWithType(String pool, String env, String dbname, boolean master) {

		List<HashMap> datas = configDao.getDbInstancesByName(env, dbname);
		for(int i=0;i<datas.size();i++){
			HashMap item = datas.get(i);
			DBInstance info = new DBInstance();
			info.setName((String)item.get("dbname"));
			info.setAlias((String)item.get("dbalias"));
			info.setHost((String)item.get("server"));
			info.setPort((Integer)item.get("port"));
			info.setUser((String)item.get("user"));
			info.setPassword((String)item.get("password"));
			String m = (String)item.get("master");
			if(m == null)
				continue;
			if(master&&"master".equals(m))
				return info;
			if(!master&&"slave".equals(m))
				return info;
			
		}
		return null;
	}

}
