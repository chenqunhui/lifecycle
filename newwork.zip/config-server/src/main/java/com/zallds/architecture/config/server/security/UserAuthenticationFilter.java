package com.zallds.architecture.config.server.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.util.TextEscapeUtils;

import com.zallds.architecture.config.server.dao.ConfigDao;



public class UserAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

	public static final String SPRING_SECURITY_LAST_USERNAME_KEY = "SPRING_SECURITY_LAST_USERNAME";

	private ConfigDao configDao;
	private String ldapServer;

	public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException {

		// Place the last username attempted into HttpSession for views
		HttpSession session = request.getSession(false);
		String username = obtainUsername(request);
		String password = obtainPassword(request);

		if (StringUtils.isBlank(username) || StringUtils.isBlank(password)) {
			throw new InsufficientAuthenticationException("username and password is requried");	
		}

		username = username.trim();
		UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(username, password);

		if (session != null || getAllowSessionCreation()) {
			request.getSession().setAttribute(SPRING_SECURITY_LAST_USERNAME_KEY, TextEscapeUtils.escapeEntities(username));
		}

		setDetails(request, authRequest);
		 
		// 根据用户和密码查询
//		String encodedPassword = password;//MD5.getInstance().getMD5String(password);
//		boolean isAuth = configDao.authUser(username, encodedPassword);
//		if (!isAuth) {
//			if (!LDAPTools.checkUser(ldapServer, username, password)) {
//				String error = "username or password is error";
//				throw new InsufficientAuthenticationException(error);
//			}
//		}
		
		return this.getAuthenticationManager().authenticate(authRequest);
	}


	public String getLdapServer() {
		return ldapServer;
	}
	public void setLdapServer(String ldapServer) {
		this.ldapServer = ldapServer;
	}

	public ConfigDao getConfigDao() {
		return configDao;
	}
	public void setConfigDao(ConfigDao configDao) {
		this.configDao = configDao;
	}

}
