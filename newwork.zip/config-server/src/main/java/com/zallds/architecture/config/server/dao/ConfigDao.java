package com.zallds.architecture.config.server.dao;

import java.util.HashMap;
import java.util.List;

import com.zallds.architecture.config.server.model.TempFile;

public interface ConfigDao {

//	boolean authUser(String username, String encodedPassword);
//
//	List<String> findUserAuthorities(String username);

//	int getPoolSize();

	List<HashMap> getPools(int start, int rows);

//	void addPool(String poolName);
//
//	void delPool(int id);

	int getGroupSize(String pool, String env);

	List<HashMap> getGroups(String pool, String env, int start, int rows);

	void addGroup(String poolName, String env, String groupName);

	void delGroup(int id);

//	int getUserSize(String filter);
//
//	List<HashMap> getUsers(String filter,int start, int rows);
//
//	void addUser(String userName, String password);
//
//	void delUser(int id);
//
//	List<HashMap> getAllRoles();
//
//	int getUserRoleSize(String filterUser,String filterRole);
//
//	List<HashMap> getUserRoles(String filterUser,String filterRole,int start, int rows);
//
//	void addUserRole(String userName, String rolename);
//
//	void delUserRole(int id);
//
//	List<HashMap> getAllAuths();
//
//	int getRoleAuthSize(String filterRole,String filterAuth);
//
//	Set<String> getAuthsByRole(String filterRole);
//	
//	List<HashMap> getRoleAuths(String filterRole,String filterAuth,int start, int rows);
//
//	void addRoleAuth(String rolename, String authname);
//
//	void delRoleAuth(int id);

	List<HashMap> getDbs(int start, int rows);

	int getDbSize();

	void addDB(String dbname, String dbalias);

	void delDb(int id);

	int getDbInstanceSize(int dbid);

	List<HashMap> getDbInstances(int dbid, int i, int rows);
	
	List<HashMap> getDbInstancesByName(String env,String dbname);

	void addDbInstance(int dbid, String dbname, String dbalias, String server, int port,String user,String password, String env, String master);

	void delDbInstance(int dbid, int id);
	
	void delDbInstanceWithDbId(int dbid);

	int getDbKvSize();

	List<HashMap> getDbKvs(int start, int rows);

	void addDbKv(String key, String value, String env);

	void delDbKv(int id);

	int getModelKvSize();
	
	List<HashMap> getModelKvs(String env, String type, int start, int rows);

	void addModelKv(String key, String value, String env, String type, String group);

	void delModelKv(int id);

	int countData(String pool, String group, String env, String data);

	void addData(String pool, String group, String data, String env, String content, String type, String status, String submitby,String approvedby,String publishedby);

	int getConfigSize(String pool,String group, String env,String status);

	List<HashMap> getConfigs(String pool,String group, String env, String status, int start, int rows);
	
	List<HashMap> getAllConfigs(String pool, String group, String env, String status);
	
	void delConfig(int id);

	HashMap getConfigById(int parseInt);

	void updateData(String pool, String group, String data, String env, String content, String type,String status,String submitby,String approvedby,String publishedby, String oldMd5);

	List<HashMap> getDbs(String env, int start, int rows);

	List<HashMap> getDbInsts(int dbid, String env, int start, int rows);

	List<HashMap> getDbParams(String env, int start, int rows);

	HashMap getDbById(int dbid);

	HashMap getDbInstByName(String dbname, String master, String env);

	int insertFile(String originalFilename, String fileContent,String fileType);

	TempFile getTempFile(int fileid);

	HashMap getConfig(String pool, String group, String data, String env, String status);

	List<HashMap> getHisConfig(String pool, String group, String env, String data);

	HashMap getHisConfigById(int id);

	void submitFromIds(String pool, String group, String[] idl, String submitby);

	void submitConfig(String pool, String group, String approvedby);

	void cancelSubmit(String pool, String group);

	void approveConfig(String pool, String group, String userName);

	void unapproveConfig(String pool, String group, String userName);

	void publishConfig(String pool, String group, String userName);

	void returnedConfig(String pool, String group, String userName);

//	List<HashMap> getAllPools();
//
//	int getUserPoolSize(String username);
//
//	List<HashMap> getUserPools(String username, int i, int rows);
//
//	int getAllUserPoolSize(String filterUser,String filterPool);
//
//	List<HashMap> getAllUserPools(String filterUser,String filterPool,int start, int rows);
//
//	void addUserPool(String username, String pool);
//
//	void delUserPool(int id);

	String getVersion(String pool, String group, String env);
	void addVersion(String pool, String group, String env);
	void updateVersion(String pool, String group, String env);

	int getAllGroupSize(String pool);

	List<HashMap> getAllGroups(String pool, int i, int rows);

	void moveConfigs(String pool, String fromGroup, String fromEnv, String toGroup, String toEnv);
}
