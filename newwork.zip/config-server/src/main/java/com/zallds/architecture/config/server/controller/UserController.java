package com.zallds.architecture.config.server.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.zallds.architecture.config.server.dao.ConfigDao;

@Controller
@RequestMapping(value="/user.do") 
public class UserController extends BaseController{

	@Autowired
	private ConfigDao configDao;
	
	@RequestMapping(params = "method=listUser", method = RequestMethod.GET)
	@PreAuthorize("hasRole('MANAGE_AUTH')")
	public String listUser(HttpServletRequest request, HttpServletResponse response, ModelMap modelMap) {

		return "/user/list_user";
	}
	
	@RequestMapping(params = "method=listUserRole", method = RequestMethod.GET)
	@PreAuthorize("hasRole('MANAGE_AUTH')")
	public String listUserRole(HttpServletRequest request, HttpServletResponse response, ModelMap modelMap) {

		return "/user/list_userrole";
	}
	
	@RequestMapping(params = "method=listUserPool", method = RequestMethod.GET)
	@PreAuthorize("hasRole('MANAGE_AUTH')")
	public String listUserPool(HttpServletRequest request, HttpServletResponse response, ModelMap modelMap) {

		return "/user/list_userpool";
	}
	
	@RequestMapping(params = "method=listRoleAuth", method = RequestMethod.GET)
	@PreAuthorize("hasRole('MANAGE_AUTH')")
	public String listRoleAuth(HttpServletRequest request, HttpServletResponse response, ModelMap modelMap) {

		return "/user/list_roleauth";
	}
	
	@RequestMapping(params = "method=getUserList",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_AUTH')")
	public void getUserList(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value="filter",required=false) String filter,
			@RequestParam(value ="page") int page,
			@RequestParam(value ="rows") int rows,
			ModelMap modelMap) {
		int total = 0;//configDao.getUserSize(filter);
		List<HashMap> rowsData = new ArrayList<HashMap>();//configDao.getUsers(filter,(page -1)*rows, rows);

		HashMap ret =new HashMap();
		ret.put("total", total);
		ret.put("rows", rowsData);
		super.returnObject(response, ret);
	}
	
	@RequestMapping(params = "method=addUser",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_AUTH')")
	public void addGroup(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="username") String username,
			@RequestParam(value ="password") String password,
			ModelMap modelMap) {
		try{
			
//			configDao.addUser(getUserName(username),password);
		super.returnSuccess(response);
		}catch(Exception exp){
			super.returnError(response,"添加失败");
		}
	}
	
	@RequestMapping(params = "method=delUser",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_AUTH')")
	public void delGroup(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="id") int id,
			ModelMap modelMap) {
//		configDao.delUser(id);
		super.returnSuccess(response);
	}
	
	@RequestMapping(params = "method=getAllRoles",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_AUTH')")
	public void getAllRoles(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="withEmpty",required=false) String withEmpty,
			ModelMap modelMap) {
		List<HashMap> roles = new ArrayList<HashMap>();//configDao.getAllRoles();
		if(withEmpty!=null){
			HashMap empty = new HashMap();
			empty.put("id", "");
			empty.put("name", "不限");
			roles.add(0, empty);
		}
		super.returnObject(response,roles);
	}
	
	@RequestMapping(params = "method=getUserRoleList",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_AUTH')")
	public void getUserRoleList(HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value ="filterUser",required=false) String filterUser,
			@RequestParam(value ="filterRole",required=false) String filterRole,
			@RequestParam(value ="page") int page,
			@RequestParam(value ="rows") int rows,
			ModelMap modelMap) {
		int total = 0;//configDao.getUserRoleSize(filterUser,filterRole);
		List<HashMap> roles = new ArrayList<HashMap>();//configDao.getUserRoles(filterUser,filterRole,(page-1)*rows,rows);
		HashMap map = new HashMap();
		map.put("total", total);
		map.put("rows", roles);
		
		super.returnObject(response,map);
	}
	
	@RequestMapping(params = "method=addUserRole",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_AUTH')")
	public void addUserRole(HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value ="username") String username,
			@RequestParam(value ="rolename") String rolename,
			ModelMap modelMap) {
		try{
//			configDao.addUserRole(getUserName(username),rolename);
			super.returnSuccess(response);
		}catch(Exception exp){
			super.returnError(response,"添加失败");
		}
	}

	@RequestMapping(params = "method=delUserRole",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_AUTH')")
	public void delUserRole(HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value ="id") int id,
			ModelMap modelMap) {
//		configDao.delUserRole(id);
		super.returnSuccess(response);
	}

	
	
	@RequestMapping(params = "method=getAllAuths",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_AUTH')")
	public void getAllAuths(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="withEmpty",required=false) String withEmpty,
			ModelMap modelMap) {
		List<HashMap> auths = new ArrayList<HashMap>();//configDao.getAllAuths();
		if(withEmpty != null){
			HashMap empty = new HashMap();
			empty.put("id", "");
			empty.put("name", "不限");
			auths.add(0, empty);
		}
		super.returnObject(response,auths);
	}
	
	@RequestMapping(params = "method=getAllPools",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_AUTH')")
	public void getAllPools(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="withEmpty",required=false) String withEmpty,
			ModelMap modelMap) {
		List<HashMap> pools = new ArrayList<HashMap>();//configDao.getAllPools();
		if(withEmpty != null){
			HashMap empty = new HashMap();
			empty.put("id", "");
			empty.put("name", "不限");
			pools.add(0, empty);
		}
		super.returnObject(response,pools);
	}
	
	@RequestMapping(params = "method=getUserPoolList",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_AUTH')")
	public void getUserPoolList(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="username",required=false ) String username,
			@RequestParam(value ="filterUser",required=false ) String filterUser,
			@RequestParam(value ="filterPool",required=false ) String filterPool,
			
			@RequestParam(value ="page") int page,
			@RequestParam(value ="rows") int rows,
			ModelMap modelMap) {
		int total = 0;
		List<HashMap> pools = new ArrayList<HashMap>();
//		if(username != null && username.length() >0){
//			total = configDao.getUserPoolSize(super.getUserName(username));
//			pools = configDao.getUserPools(super.getUserName(username),(page-1)*rows,rows);
//		} else {
//			if(filterUser != null && filterUser.length() >0)
//				filterUser = super.getUserName(filterUser);
//			total = configDao.getAllUserPoolSize(filterUser,filterPool);
//			pools = configDao.getAllUserPools(filterUser,filterPool,(page-1)*rows,rows);
//		}
		
		HashMap ret = new HashMap();
		ret.put("total", total);
		ret.put("rows", pools);
		super.returnObject(response,ret);
	}
		
	@RequestMapping(params = "method=getRoleAuthList",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_AUTH')")
	public void getRoleAuthList(HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value ="filterRole",required=false) String filterRole,
			@RequestParam(value ="filterAuth",required=false) String filterAuth,
			@RequestParam(value ="page") int page,
			@RequestParam(value ="rows") int rows,
			ModelMap modelMap) {
		int total = 0;//configDao.getRoleAuthSize(filterRole,filterAuth);
		List<HashMap> roles = new ArrayList<HashMap>();//configDao.getRoleAuths(filterRole,filterAuth,(page-1)*rows,rows);
		HashMap map = new HashMap();
		map.put("total", total);
		map.put("rows", roles);
		
		super.returnObject(response,map);
	}
	
	@RequestMapping(params = "method=addRoleAuth",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_AUTH')")
	public void addRoleAuth(HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value ="authname") String authname,
			@RequestParam(value ="rolename") String rolename,
			ModelMap modelMap) {
		try{
//			configDao.addRoleAuth(rolename,authname);
			super.returnSuccess(response);
		}catch(Exception exp){
			super.returnError(response,"添加失败");
		}
	}

	@RequestMapping(params = "method=delRoleAuth",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_AUTH')")
	public void delRoleAuth(HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value ="id") int id,
			ModelMap modelMap) {
//		configDao.delRoleAuth(id);
		super.returnSuccess(response);
	}
	
	
	@RequestMapping(params = "method=addUserPool",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_AUTH')")
	public void addUserPool(HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value ="username") String username,
			@RequestParam(value ="pool") String pool,
			ModelMap modelMap) {
		try{
//			configDao.addUserPool(super.getUserName(username),pool);
			super.returnSuccess(response);
		}catch(Exception exp){
			super.returnError(response,"添加失败");
		}
	}
	@RequestMapping(params = "method=delUserPool",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_AUTH')")
	public void delUserPool(HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value ="id") int id,
			ModelMap modelMap) {
//		configDao.delUserPool(id);
		super.returnSuccess(response);
	}
	
}
