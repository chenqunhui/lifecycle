package com.zallds.architecture.config.server.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.zallds.architecture.config.server.dao.ConfigDao;
import com.zallds.architecture.config.server.model.ConfigInfo;
import com.zallds.architecture.config.server.utils.DownloadTools;
import com.zallds.architecture.config.server.utils.ZipTool;

@Controller
public class UploadController extends BaseController{
	
	@Autowired
	private ConfigDao configDao;
	
	@RequestMapping(value="/uploadFile.do",method=RequestMethod.POST)  
    public void uploadFile(HttpServletResponse response,HttpServletRequest request,
    		@RequestParam(value="file", required=false) MultipartFile file) throws IOException{  
        byte[] bytes = file.getBytes();  
        //System.out.println(file.getOriginalFilename());  
        try{
        	String fileContent = getContentString(bytes,file.getOriginalFilename());
        	String fileType = getFileType(file.getOriginalFilename(),fileContent);
        	int id = configDao.insertFile(file.getOriginalFilename(),fileContent,fileType);
        	HashMap ret = new HashMap();
            ret.put("fileid", id);
            super.returnObject(response, ret); 
            return;
        }catch(Exception exp){
        	
        }
        super.returnError(response, "");
    }

	private String getContentString(byte[] bytes, String originalFilename) throws Exception {
		if(originalFilename.toLowerCase().endsWith(".properties")||
		   originalFilename.toLowerCase().endsWith(".ini")||
		   originalFilename.toLowerCase().endsWith(".xml")){
			return new String(bytes,"UTF-8");
		} else {
			return new String(Base64.encodeBase64(bytes),"UTF-8");
		}
	}  
	
	private String getFileType(String originalFilename,String content){
		String filename = originalFilename.toLowerCase();
		if(filename.endsWith(".properties")){
			if(content.indexOf("jdbc.url=") >=0){
				return "db";
			} else {
				return "txt";
			}
		} else {
			if(filename.endsWith(".ini")||filename.endsWith(".xml")){
				return "txt";
			} else {
				return "other";
			}
		}
	}
	
	@RequestMapping(value="/download.do")  
    public void download(HttpServletResponse response,HttpServletRequest request,
    		@RequestParam(value="pool") String pool,
    		@RequestParam(value="group") String group,
    		@RequestParam(value="env") String env,
    		@RequestParam(value="configs") String config
    		
    		) throws IOException{  
		String version = configDao.getVersion(pool,group,env);
		List<HashMap> list = configDao.getAllConfigs(pool,group,env,"published");
		List<ConfigInfo> configs = new ArrayList<ConfigInfo>();
		
		String [] files = config.split(",");
		HashSet fileSet = new HashSet();
		for(int i=0;i<files.length;i++)
			fileSet.add(files[i].trim().toLowerCase());
		for(int i=0;i<list.size();i++){
			HashMap item = list.get(i);
			ConfigInfo ci = new ConfigInfo();
			String filename =(String)item.get("data").toString().toLowerCase(); 
			if(!fileSet.contains(filename))
				continue;
			ci.setFileName((String)item.get("data"));
			
			String content = (String) item.get("content");
            byte[] bytes;
            if("db".equals(item.get("filetype"))){
            	String data = (String) item.get("data");
				int pos = data.lastIndexOf(".");
				String f1 = data.substring(0,pos);
				pos = f1.lastIndexOf("_");
				String fn = f1.substring(0, pos);
				String type = f1.substring(pos+1);
				//String[] f2 = f1.split("_");
				HashMap dbinst = configDao.getDbInstByName(fn,type,env);
            	if(dbinst == null)
            		continue;
            	content=getDbInfo(content,(Integer)dbinst.get("id"));
            	bytes = content.getBytes("UTF-8");
    		} else if("other".equals(item.get("filetype"))){
    			bytes = Base64.decodeBase64(content);
    		} else {
    			bytes = content.getBytes("UTF-8");
    		}
            ci.setFileContent(bytes);
            Date createTime = (Date) item.get("createtime");
            ci.setCreateTime(createTime.getTime());
            configs.add(ci);
		}
		String fileName = group+"_"+env+"_"+version+".zip";
		String path = DownloadTools.sWorkDir;
		ZipTool.zip(configs, path + File.separator + fileName);
		
		response.setCharacterEncoding("utf-8");
        response.setContentType("multipart/form-data");
        response.setHeader("Content-Disposition", "attachment;fileName="
                + new String(fileName.getBytes(),"iso-8859-1"));
        try {
            InputStream inputStream = new FileInputStream(new File(path
                    + File.separator + fileName));
 
            OutputStream os = response.getOutputStream();
            byte[] b = new byte[2048];
            int length;
            while ((length = inputStream.read(b)) > 0) {
                os.write(b, 0, length);
            }
            os.flush();
             // 这里主要关闭。
            os.close();
 
            inputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
	
	private String getDbInfo(String content,int dbid){
		HashMap map = configDao.getDbById(dbid);
		String [] items = content.split("\n");
		for(int i=0;i<items.length;i++){
			if(items[i].startsWith("jdbc.username=")){
				items[i] = "jdbc.username=" + map.get("user");
			}
			if(items[i].startsWith("jdbc.password")){
				items[i] = "jdbc.password.encrypt=" + map.get("password");
			}
		}
		StringBuffer sb = new StringBuffer();
		for(int i=0;i<items.length;i++){
			sb.append(items[i]).append("\n");
		}
		return sb.toString();
	}
}
