package com.zallds.architecture.config.server.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import com.zallds.architecture.config.server.utils.JsonUtils;


public class BaseController {

	@Autowired
	private HttpSession session;
	
	protected void returnSuccess(HttpServletResponse response){
		try {
			response.setCharacterEncoding("UTF-8");
			response.getWriter().print("{\"success\":true}");
			response.getWriter().flush();
			response.getWriter().close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	protected void returnObject(HttpServletResponse response,Object obj){
		String retSring = JsonUtils.toJson(obj);
		try {
			response.setCharacterEncoding("UTF-8");
			response.getWriter().print(retSring);
			response.getWriter().flush();
			response.getWriter().close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	protected String getUserId() {
		return (String) session.getAttribute("userId");
	}
	protected String getUserName() {
//		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext()
//			    .getAuthentication()
//			    .getPrincipal();
//		String username = userDetails.getUsername();
		String username = (String) session.getAttribute("userId");
		if(username.indexOf("@") >0)
			return username;
		else
			return username+"@zallds.com";
	}
	protected String getUserName(String username) {
		if(username.indexOf("@") >0)
			return username;
		else
			return username+"@zallds.com";
	}
	protected List<HashMap> getUserPools() {
//		String username = getUserName();
		List<HashMap> rs = new ArrayList<HashMap>();
		List<String> pools = (List<String>) session.getAttribute("arch_poolIdList");
		if (pools != null) {
			for (String poolName : pools) {
				HashMap rec = new HashMap();
				rec.put("pool", poolName);
				rs.add(rec);
			}
		}
		return rs;
	}
	public void returnError(HttpServletResponse response,String msg) {
		try {
			response.setCharacterEncoding("UTF-8");
			response.getWriter().print("{\"success\":false,\"errorMessage\":\""+msg+"\"}");
			response.getWriter().flush();
			response.getWriter().close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
