package com.zallds.architecture.config.server.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mysql.jdbc.StringUtils;
import com.zallds.architecture.config.server.dao.ConfigDao;
import com.zallds.architecture.config.server.model.ConfigInfo;
import com.zallds.architecture.config.server.model.DiffManager;
import com.zallds.architecture.config.server.model.TempFile;
import com.zallds.architecture.config.server.utils.DownloadTools;
import com.zallds.architecture.config.server.utils.ZipTool;

@Controller
@RequestMapping(value="/admin.do") 
public class AdminController extends BaseController{
	@Autowired
	private ConfigDao configDao;

	@RequestMapping(params = "method=devConfig", method = RequestMethod.GET)
	@PreAuthorize("hasRole('VIEW_DEV')")
	public String devConfig(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool", required = false) String poolDefault,
			@RequestParam(value ="group", required = false) String group,
			ModelMap modelMap) {
		
		long elapse = 0;
		long currTime = 0;
		
		currTime = System.currentTimeMillis();
		List<HashMap> pools = getUserPools();
		elapse = System.currentTimeMillis() - currTime;
		System.out.println("getUserPools elapse: " + elapse);
		
		for(int i=0;i<pools.size();i++){
			pools.get(i).put("id", pools.get(i).get("pool"));
		}
		modelMap.put("pools", pools);
		if(pools.size()>0){
			String pool = (String) pools.get(0).get("pool");
			if(poolDefault != null)
				pool = poolDefault;
			
			currTime = System.currentTimeMillis();
			String sessionPool = (String)request.getSession().getAttribute("defaultPool");
			elapse = System.currentTimeMillis() - currTime;
			System.out.println("get defaultPool elapse: " + elapse);
			
			if(!StringUtils.isNullOrEmpty(sessionPool)){
				pool = sessionPool;
			}
			modelMap.put("defaultPool", pool);

			currTime = System.currentTimeMillis();
			List<HashMap> groups = configDao.getGroups(pool,"dev", 0, 100);
			elapse = System.currentTimeMillis() - currTime;
			System.out.println("DB getGroups elapse: " + elapse);
			
			List<HashMap> mygroups = new ArrayList<HashMap>();
			HashMap defaultGroup = new HashMap();
			String dgid= pool.replace("/", "_");
			defaultGroup.put("id", dgid);
			defaultGroup.put("group", dgid);
			mygroups.add(defaultGroup);
			for(int i=0;i<groups.size();i++){
				HashMap item = new HashMap();
				item.put("id", dgid+"_"+groups.get(i).get("group"));
				item.put("group", dgid+"_"+groups.get(i).get("group"));
				mygroups.add(item);
			}
			modelMap.put("groups", mygroups);
			if(group!=null)
				modelMap.put("defaultGroup", group);
			else{

				currTime = System.currentTimeMillis();
				String sessionGroup = (String)request.getSession().getAttribute("defaultGroup");
				elapse = System.currentTimeMillis() - currTime;
				System.out.println("get defaultGroup elapse: " + elapse);
				
				if(isValidSessionGroup(mygroups,sessionGroup))
					modelMap.put("defaultGroup", sessionGroup);
				else
					modelMap.put("defaultGroup", dgid);
			}
		}
		return "/admin/config_dev";
	}
	
	private boolean isValidSessionGroup(List<HashMap> groups,String group){
		if(group==null||group.equals(""))
			return false;
		for(int i=0;i<groups.size();i++){
			HashMap item = groups.get(i);
			if(group.equals(item.get(group)))
				return true;
		}
		return false;
	}
	
	
	
	@RequestMapping(params = "method=moveConfigFromDevToDev", method = RequestMethod.GET)
	@PreAuthorize("hasRole('MANAGE_DEV')")
	public String moveConfigFromDevToDev(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool", required = false) String poolDefault,
			@RequestParam(value ="group", required = false) String group,
			ModelMap modelMap) {
		List<HashMap> pools = getUserPools();
		for(int i=0;i<pools.size();i++){
			pools.get(i).put("id", pools.get(i).get("pool"));
		}
		modelMap.put("pools", pools);
		if(pools.size()>0){
			String pool = (String) pools.get(0).get("pool");
			if(poolDefault != null)
				pool = poolDefault;

			String sessionPool = (String)request.getSession().getAttribute("defaultPool");
			if(!StringUtils.isNullOrEmpty(sessionPool)){
				pool = sessionPool;
			}
			modelMap.put("defaultPool", pool);
			List<HashMap> groups = configDao.getGroups(pool,"dev", 0, 100);
			List<HashMap> mygroups = new ArrayList<HashMap>();
			HashMap defaultGroup = new HashMap();
			String dgid= pool.replace("/", "_");
			defaultGroup.put("id", dgid);
			defaultGroup.put("group", dgid);
			mygroups.add(defaultGroup);
			for(int i=0;i<groups.size();i++){
				HashMap item = new HashMap();
				item.put("id", dgid+"_"+groups.get(i).get("group"));
				item.put("group", dgid+"_"+groups.get(i).get("group"));
				mygroups.add(item);
			}
			modelMap.put("groups", mygroups);
			if(group!=null)
				modelMap.put("defaultGroup", group);
			else{
				String sessionGroup = (String)request.getSession().getAttribute("defaultGroup");
				if(isValidSessionGroup(mygroups,sessionGroup))
					modelMap.put("defaultGroup", sessionGroup);
				else
					modelMap.put("defaultGroup", dgid);
			}
		}
		return "/admin/moveconfig_dev2dev";
	}
	
	
	@RequestMapping(params = "method=moveConfigFromDevToTest", method = RequestMethod.GET)
	@PreAuthorize("hasRole('MANAGE_TEST')")
	public String moveConfigFromDevToTest(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool", required = false) String poolDefault,
			@RequestParam(value ="group", required = false) String group,
			ModelMap modelMap) {
		List<HashMap> pools = getUserPools();
		for(int i=0;i<pools.size();i++){
			pools.get(i).put("id", pools.get(i).get("pool"));
		}
		modelMap.put("pools", pools);
		if(pools.size()>0){
			String pool = (String) pools.get(0).get("pool");
			if(poolDefault != null)
				pool = poolDefault;

			String sessionPool = (String)request.getSession().getAttribute("defaultPool");
			if(!StringUtils.isNullOrEmpty(sessionPool)){
				pool = sessionPool;
			}
			modelMap.put("defaultPool", pool);
			List<HashMap> groups = configDao.getGroups(pool,"dev", 0, 100);
			List<HashMap> mygroups = new ArrayList<HashMap>();
			HashMap defaultGroup = new HashMap();
			String dgid= pool.replace("/", "_");
			defaultGroup.put("id", dgid);
			defaultGroup.put("group", dgid);
			mygroups.add(defaultGroup);
			for(int i=0;i<groups.size();i++){
				HashMap item = new HashMap();
				item.put("id", dgid+"_"+groups.get(i).get("group"));
				item.put("group", dgid+"_"+groups.get(i).get("group"));
				mygroups.add(item);
			}
			modelMap.put("groups", mygroups);
			if(group!=null)
				modelMap.put("defaultGroup", group);
			else{
				String sessionGroup = (String)request.getSession().getAttribute("defaultGroup");
				if(isValidSessionGroup(mygroups,sessionGroup))
					modelMap.put("defaultGroup", sessionGroup);
				else
					modelMap.put("defaultGroup", dgid);
			}
		}
		return "/admin/moveconfig_dev2test";
	}
	
	@RequestMapping(params = "method=moveConfigFromTestToTest", method = RequestMethod.GET)
	@PreAuthorize("hasRole('MANAGE_TEST')")
	public String moveConfigFromTestToTest(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool", required = false) String poolDefault,
			@RequestParam(value ="group", required = false) String group,
			ModelMap modelMap) {
		List<HashMap> pools = getUserPools();
		for(int i=0;i<pools.size();i++){
			pools.get(i).put("id", pools.get(i).get("pool"));
		}
		modelMap.put("pools", pools);
		if(pools.size()>0){
			String pool = (String) pools.get(0).get("pool");
			if(poolDefault != null)
				pool = poolDefault;

			String sessionPool = (String)request.getSession().getAttribute("defaultPool");
			if(!StringUtils.isNullOrEmpty(sessionPool)){
				pool = sessionPool;
			}
			modelMap.put("defaultPool", pool);
			List<HashMap> groups = configDao.getGroups(pool,"dev", 0, 100);
			List<HashMap> mygroups = new ArrayList<HashMap>();
			HashMap defaultGroup = new HashMap();
			String dgid= pool.replace("/", "_");
			defaultGroup.put("id", dgid);
			defaultGroup.put("group", dgid);
			mygroups.add(defaultGroup);
			for(int i=0;i<groups.size();i++){
				HashMap item = new HashMap();
				item.put("id", dgid+"_"+groups.get(i).get("group"));
				item.put("group", dgid+"_"+groups.get(i).get("group"));
				mygroups.add(item);
			}
			modelMap.put("groups", mygroups);
			if(group!=null)
				modelMap.put("defaultGroup", group);
			else{
				String sessionGroup = (String)request.getSession().getAttribute("defaultGroup");
				if(isValidSessionGroup(mygroups,sessionGroup))
					modelMap.put("defaultGroup", sessionGroup);
				else
					modelMap.put("defaultGroup", dgid);
			}
		}
		return "/admin/moveconfig_test2test";
	}
	
	@RequestMapping(params = "method=testConfig", method = RequestMethod.GET)
	@PreAuthorize("hasRole('VIEW_TEST')")
	public String testConfig(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool", required = false) String poolDefault,
			@RequestParam(value ="group", required = false) String group,
			ModelMap modelMap) {

		long elapse = 0;
		long currTime = 0;
		
		currTime = System.currentTimeMillis();
		List<HashMap> pools = getUserPools();
		elapse = System.currentTimeMillis() - currTime;
		System.out.println("getUserPools elapse: " + elapse);
		
		for(int i=0;i<pools.size();i++){
			pools.get(i).put("id", pools.get(i).get("pool"));
		}
		modelMap.put("pools", pools);
		if(pools.size()>0){
			String pool = (String) pools.get(0).get("pool");
			if(poolDefault != null)
				pool = poolDefault;

			currTime = System.currentTimeMillis();
			String sessionPool = (String)request.getSession().getAttribute("defaultPool");
			elapse = System.currentTimeMillis() - currTime;
			System.out.println("get defaultPool elapse: " + elapse);
			
			if(!StringUtils.isNullOrEmpty(sessionPool)){
				pool = sessionPool;
			}
			modelMap.put("defaultPool", pool);

			currTime = System.currentTimeMillis();
			List<HashMap> groups = configDao.getGroups(pool,"test", 0, 100);
			elapse = System.currentTimeMillis() - currTime;
			System.out.println("DB getGroups elapse: " + elapse);
			
			List<HashMap> mygroups = new ArrayList<HashMap>();
			HashMap defaultGroup = new HashMap();
			String dgid= pool.replace("/", "_");
			defaultGroup.put("id", dgid);
			defaultGroup.put("group", dgid);
			mygroups.add(defaultGroup);
			for(int i=0;i<groups.size();i++){
				HashMap item = new HashMap();
				item.put("id", dgid+"_"+groups.get(i).get("group"));
				item.put("group", dgid+"_"+groups.get(i).get("group"));
				mygroups.add(item);
			}
			modelMap.put("groups", mygroups);
			if(group!=null)
				modelMap.put("defaultGroup", group);
			else{
				currTime = System.currentTimeMillis();
				String sessionGroup = (String)request.getSession().getAttribute("defaultGroup");
				elapse = System.currentTimeMillis() - currTime;
				System.out.println("get defaultGroup elapse: " + elapse);
				
				if(isValidSessionGroup(mygroups,sessionGroup))
					modelMap.put("defaultGroup", sessionGroup);
				else
					modelMap.put("defaultGroup", dgid);
			}
		}
		return "/admin/config_test";
	}
	
	
	
	@RequestMapping(params = "method=stageConfig", method = RequestMethod.GET)
	@PreAuthorize("hasRole('VIEW_STAGE')")
	public String stageConfig(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool", required = false) String poolDefault,
			@RequestParam(value ="group", required = false) String group,
			ModelMap modelMap) {
		List<HashMap> pools = getUserPools();
		for(int i=0;i<pools.size();i++){
			pools.get(i).put("id", pools.get(i).get("pool"));
		}
		modelMap.put("pools", pools);
		if(pools.size()>0){
			String pool = (String) pools.get(0).get("pool");
			if(poolDefault != null)
				pool = poolDefault;

			String sessionPool = (String)request.getSession().getAttribute("defaultPool");
			if(!StringUtils.isNullOrEmpty(sessionPool)){
				pool = sessionPool;
			}
			modelMap.put("defaultPool", pool);
			List<HashMap> groups = configDao.getGroups(pool,"stage", 0, 100);
			List<HashMap> mygroups = new ArrayList<HashMap>();
			HashMap defaultGroup = new HashMap();
			String dgid= pool.replace("/", "_");
			defaultGroup.put("id", dgid);
			defaultGroup.put("group", dgid);
			mygroups.add(defaultGroup);
			for(int i=0;i<groups.size();i++){
				HashMap item = new HashMap();
				item.put("id", dgid+"_"+groups.get(i).get("group"));
				item.put("group", dgid+"_"+groups.get(i).get("group"));
				mygroups.add(item);
			}
			modelMap.put("groups", mygroups);
			if(group!=null)
				modelMap.put("defaultGroup", group);
			else{
				String sessionGroup = (String)request.getSession().getAttribute("defaultGroup");
				
				if(isValidSessionGroup(mygroups,sessionGroup))
					modelMap.put("defaultGroup", sessionGroup);
				else
					modelMap.put("defaultGroup", dgid);
			}
		}
		return "/admin/config_stage";
	}
	
	@RequestMapping(params = "method=productSubmitConfig", method = RequestMethod.GET)
	@PreAuthorize("hasRole('VIEW_PRODUCT')")
	public String productSubmitConfig(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool", required = false) String poolDefault,
			@RequestParam(value ="group", required = false) String group,
			ModelMap modelMap) {
		List<HashMap> pools = getUserPools();
		for(int i=0;i<pools.size();i++){
			pools.get(i).put("id", pools.get(i).get("pool"));
		}
		modelMap.put("pools", pools);
		if(pools.size()>0){
			String pool = (String) pools.get(0).get("pool");
			if(poolDefault != null)
				pool = poolDefault;

			String sessionPool = (String)request.getSession().getAttribute("defaultPool");
			if(!StringUtils.isNullOrEmpty(sessionPool)){
				pool = sessionPool;
			}
			modelMap.put("defaultPool", pool);
			List<HashMap> groups = configDao.getGroups(pool,"product", 0, 100);
			List<HashMap> mygroups = new ArrayList<HashMap>();
			HashMap defaultGroup = new HashMap();
			String dgid= pool.replace("/", "_");
			defaultGroup.put("id", dgid);
			defaultGroup.put("group", dgid);
			mygroups.add(defaultGroup);
			for(int i=0;i<groups.size();i++){
				HashMap item = new HashMap();
				item.put("id", dgid+"_"+groups.get(i).get("group"));
				item.put("group", dgid+"_"+groups.get(i).get("group"));
				mygroups.add(item);
			}
			modelMap.put("groups", mygroups);
			if(group!=null)
				modelMap.put("defaultGroup", group);
			else{
				String sessionGroup = (String)request.getSession().getAttribute("defaultGroup");
				
				if(isValidSessionGroup(mygroups,sessionGroup))
					modelMap.put("defaultGroup", sessionGroup);
				else
					modelMap.put("defaultGroup", dgid);
			}
		}
		return "/admin/config_productsubmit";
	}
	
	@RequestMapping(params = "method=productApproveConfig", method = RequestMethod.GET)
	@PreAuthorize("hasRole('VIEW_PRODUCT')")
	public String productApproveConfig(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool", required = false) String poolDefault,
			@RequestParam(value ="group", required = false) String group,
			ModelMap modelMap) {
		List<HashMap> pools = getUserPools();
		for(int i=0;i<pools.size();i++){
			pools.get(i).put("id", pools.get(i).get("pool"));
		}
		modelMap.put("pools", pools);
		if(pools.size()>0){
			String pool = (String) pools.get(0).get("pool");
			if(poolDefault != null)
				pool = poolDefault;

			String sessionPool = (String)request.getSession().getAttribute("defaultPool");
			if(!StringUtils.isNullOrEmpty(sessionPool)){
				pool = sessionPool;
			}
			modelMap.put("defaultPool", pool);
			List<HashMap> groups = configDao.getGroups(pool,"product", 0, 100);
			List<HashMap> mygroups = new ArrayList<HashMap>();
			HashMap defaultGroup = new HashMap();
			String dgid= pool.replace("/", "_");
			defaultGroup.put("id", dgid);
			defaultGroup.put("group", dgid);
			mygroups.add(defaultGroup);
			for(int i=0;i<groups.size();i++){
				HashMap item = new HashMap();
				item.put("id", dgid+"_"+groups.get(i).get("group"));
				item.put("group", dgid+"_"+groups.get(i).get("group"));
				mygroups.add(item);
			}
			modelMap.put("groups", mygroups);
			if(group!=null)
				modelMap.put("defaultGroup", group);
			else{
				String sessionGroup = (String)request.getSession().getAttribute("defaultGroup");
				
				if(isValidSessionGroup(mygroups,sessionGroup))
					modelMap.put("defaultGroup", sessionGroup);
				else
					modelMap.put("defaultGroup", dgid);
			}
		}
		return "/admin/config_productapprove";
	}
	
	@RequestMapping(params = "method=productPublishConfig", method = RequestMethod.GET)
	@PreAuthorize("hasRole('VIEW_PRODUCT')")
	public String productPublishConfig(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool", required = false) String poolDefault,
			@RequestParam(value ="group", required = false) String group,
			ModelMap modelMap) {
		List<HashMap> pools = getUserPools();
		for(int i=0;i<pools.size();i++){
			pools.get(i).put("id", pools.get(i).get("pool"));
		}
		modelMap.put("pools", pools);
		if(pools.size()>0){
			String pool = (String) pools.get(0).get("pool");
			if(poolDefault != null)
				pool = poolDefault;

			String sessionPool = (String)request.getSession().getAttribute("defaultPool");
			if(!StringUtils.isNullOrEmpty(sessionPool)){
				pool = sessionPool;
			}
			modelMap.put("defaultPool", pool);
			List<HashMap> groups = configDao.getGroups(pool,"product", 0, 100);
			List<HashMap> mygroups = new ArrayList<HashMap>();
			HashMap defaultGroup = new HashMap();
			String dgid= pool.replace("/", "_");
			defaultGroup.put("id", dgid);
			defaultGroup.put("group", dgid);
			mygroups.add(defaultGroup);
			for(int i=0;i<groups.size();i++){
				HashMap item = new HashMap();
				item.put("id", dgid+"_"+groups.get(i).get("group"));
				item.put("group", dgid+"_"+groups.get(i).get("group"));
				mygroups.add(item);
			}
			modelMap.put("groups", mygroups);
			if(group!=null)
				modelMap.put("defaultGroup", group);
			else{
				String sessionGroup = (String)request.getSession().getAttribute("defaultGroup");
				
				if(isValidSessionGroup(mygroups,sessionGroup))
					modelMap.put("defaultGroup", sessionGroup);
				else
					modelMap.put("defaultGroup", dgid);
			}
		}
		return "/admin/config_productpublish";
	}
	
	@RequestMapping(params = "method=productPublishedConfig", method = RequestMethod.GET)
	@PreAuthorize("hasRole('VIEW_PRODUCT')")
	public String productPublishedConfig(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool", required = false) String poolDefault,
			@RequestParam(value ="group", required = false) String group,
			ModelMap modelMap) {
		List<HashMap> pools = getUserPools();
		for(int i=0;i<pools.size();i++){
			pools.get(i).put("id", pools.get(i).get("pool"));
		}
		modelMap.put("pools", pools);
		if(pools.size()>0){
			String pool = (String) pools.get(0).get("pool");
			if(poolDefault != null)
				pool = poolDefault;

			String sessionPool = (String)request.getSession().getAttribute("defaultPool");
			if(!StringUtils.isNullOrEmpty(sessionPool)){
				pool = sessionPool;
			}
			modelMap.put("defaultPool", pool);
			List<HashMap> groups = configDao.getGroups(pool,"product", 0, 100);
			List<HashMap> mygroups = new ArrayList<HashMap>();
			HashMap defaultGroup = new HashMap();
			String dgid= pool.replace("/", "_");
			defaultGroup.put("id", dgid);
			defaultGroup.put("group", dgid);
			mygroups.add(defaultGroup);
			for(int i=0;i<groups.size();i++){
				HashMap item = new HashMap();
				item.put("id", dgid+"_"+groups.get(i).get("group"));
				item.put("group", dgid+"_"+groups.get(i).get("group"));
				mygroups.add(item);
			}
			modelMap.put("groups", mygroups);
			if(group!=null)
				modelMap.put("defaultGroup", group);
			else{
				String sessionGroup = (String)request.getSession().getAttribute("defaultGroup");
				
				if(isValidSessionGroup(mygroups,sessionGroup))
					modelMap.put("defaultGroup", sessionGroup);
				else
					modelMap.put("defaultGroup", dgid);
			}
		}
		return "/admin/config_productpublished";
	}
	
	@RequestMapping(params = "method=editTxtProperty")
	@PreAuthorize("hasRole('MANAGE_DEV') or hasRole('MANAGE_TEST') or hasRole('MANAGE_STAGE') or hasRole('MANAGE_PRODUCT')")
	public String editTxtProperty(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			@RequestParam(value ="env") String env,
			@RequestParam(value ="id", required = false) String id,
			ModelMap modelMap) {
		modelMap.put("pool", pool);
		modelMap.put("group", group);
		modelMap.put("env", env);
		List<HashMap> groups = configDao.getGroups(pool,env, 0, 100);
		List<HashMap> mygroups = new ArrayList<HashMap>();
		HashMap defaultGroup = new HashMap();
		String dgid= pool.replace("/", "_");
		defaultGroup.put("id", dgid);
		defaultGroup.put("group", dgid);
		mygroups.add(defaultGroup);
		for(int i=0;i<groups.size();i++){
			HashMap item = new HashMap();
			item.put("id", dgid+"_"+groups.get(i).get("group"));
			item.put("group", dgid+"_"+groups.get(i).get("group"));
			mygroups.add(item);
		}
		modelMap.put("groups", mygroups);
		if(id != null)
		{
			HashMap map = configDao.getConfigById(Integer.parseInt(id));
			if(map != null){
				modelMap.put("data", map.get("data"));
				modelMap.put("content", map.get("content"));
			}
		}
		return "/admin/editTxtProperty";
	}
	
	
	@RequestMapping(params = "method=editDbProperty")
	@PreAuthorize("hasRole('MANAGE_DEV') or hasRole('MANAGE_TEST')  or hasRole('MANAGE_STAGE') or hasRole('MANAGE_PRODUCT')")
	public String editDbProperty(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			@RequestParam(value ="env") String env,
			@RequestParam(value ="id", required = false) String id,
			ModelMap modelMap) {
		modelMap.put("pool", pool);
		modelMap.put("group", group);
		modelMap.put("env", env);
		List<HashMap> groups = configDao.getGroups(pool,env, 0, 100);
		List<HashMap> mygroups = new ArrayList<HashMap>();
		HashMap defaultGroup = new HashMap();
		String dgid= pool.replace("/", "_");
		defaultGroup.put("id", dgid);
		defaultGroup.put("group", dgid);
		mygroups.add(defaultGroup);
		for(int i=0;i<groups.size();i++){
			HashMap item = new HashMap();
			item.put("id", dgid+"_"+groups.get(i).get("group"));
			item.put("group", dgid+"_"+groups.get(i).get("group"));
			mygroups.add(item);
		}
		modelMap.put("groups", mygroups);
		if(id != null)
		{
			HashMap map = configDao.getConfigById(Integer.parseInt(id));
			if(map != null){
				modelMap.put("data", map.get("data"));
				modelMap.put("content", map.get("content"));
				String data = (String) map.get("data");
				int pos = data.lastIndexOf(".");
				String f1 = data.substring(0,pos);
				pos = f1.lastIndexOf("_");
				String fn = f1.substring(0, pos);
				String type = f1.substring(pos+1);
				//String[] f2 = f1.split("_");
				HashMap dbinst = configDao.getDbInstByName(fn,type,(String)map.get("env"));
				modelMap.put("db", dbinst.get("dbid"));
				modelMap.put("dbInstid", dbinst.get("id"));
				modelMap.put("dbInst", fn+":"+type);
				modelMap.put("content", encryptDbInfo((String)map.get("content")));
			}
		}
		return "/admin/editDbProperty";
	}
	
	@RequestMapping(params = "method=addTxtProperty", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_DEV') or hasRole('MANAGE_TEST')  or hasRole('MANAGE_STAGE') or hasRole('MANAGE_PRODUCT')")
	public void addTxtProperty(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			@RequestParam(value ="data") String data,
			@RequestParam(value ="content") String content,
			@RequestParam(value ="env") String env,
			@RequestParam(value ="status", required=false) String status,
			ModelMap modelMap) {
		try {
			if(status == null||status.equals(""))
				status = "published";
			content = new String(Base64.decodeBase64(content),"utf-8");
			HashMap map = configDao.getConfig(pool, group, data, env, status);
			//int count = configDao.countData(pool,group,env,data);
			if(map != null)
			{
				returnError(response, "文件已存在");
				return;
			}
			String username = getUserName();
			if(env.equals("product"))
				configDao.addData(pool,group,data,env,content,"txt",status,username,"","");
			else
				configDao.addData(pool,group,data,env,content,"txt",status,username,username,username);
			returnSuccess(response);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
	@RequestMapping(params = "method=addDbProperty", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_DEV') or hasRole('MANAGE_TEST')  or hasRole('MANAGE_STAGE') or hasRole('MANAGE_PRODUCT')")
	public void addDbProperty(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			@RequestParam(value ="data") String data,
			@RequestParam(value ="content") String content,
			@RequestParam(value ="env") String env,
			@RequestParam(value ="status", required=false) String status,
			@RequestParam(value ="dbid") int dbid,
			ModelMap modelMap) {
		try {
			if(status == null|| status.equals(""))
				status = "published";
			content = new String(Base64.decodeBase64(content),"utf-8");
			content = getDbInfo(content,dbid);
			HashMap map = configDao.getConfig(pool, group, data, env, status);
			//int count = configDao.countData(pool,group,env,data);
			if(map != null)
			{
				returnError(response, "文件已存在");
				return;
			}
			String username = getUserName();
			if(env.equals("product"))
				configDao.addData(pool,group,data,env,content,"db",status,username,"","");
			else
				configDao.addData(pool,group,data,env,content,"db",status,username,username,username);
			returnSuccess(response);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
	
	
	@RequestMapping(params = "method=updateTxtProperty", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_DEV') or hasRole('MANAGE_TEST')  or hasRole('MANAGE_STAGE') or hasRole('MANAGE_PRODUCT')")
	public void updateTxtProperty(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			@RequestParam(value ="data") String data,
			@RequestParam(value ="content") String content,
			@RequestParam(value ="status") String status,
			@RequestParam(value ="env") String env,
			ModelMap modelMap) {
		
		String approvedby = "";
		String publishedby = "";
		try {
			String username = getUserName();
			// 线上待审核配置修改，才会带status参数
			if (! "product".equals(env)) {
				approvedby = username;
				publishedby = username;
				status = "published";
			} else if (StringUtils.isNullOrEmpty(status)) {
				approvedby = username;
				publishedby = username;
				status = "published";
			}
			content = new String(Base64.decodeBase64(content),"utf-8");
			HashMap map = configDao.getConfig(pool,group,data,env,status);
			configDao.updateData(pool,group,data,env,content,"txt",status,username,approvedby,publishedby,(String)map.get("md5"));
			returnSuccess(response);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
	
	@RequestMapping(params = "method=updateDbProperty", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_DEV') or hasRole('MANAGE_TEST')  or hasRole('MANAGE_STAGE') or hasRole('MANAGE_PRODUCT')")
	public void updateDbProperty(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			@RequestParam(value ="data") String data,
			@RequestParam(value ="content") String content,
			@RequestParam(value ="status") String status,
			@RequestParam(value ="env") String env,
			@RequestParam(value ="dbid") int dbid,
			ModelMap modelMap) {

		String approvedby = "";
		String publishedby = "";
		try {
			String username = getUserName();
			// 线上待审核配置修改，才会带status参数
			if (! "product".equals(env)) {
				approvedby = username;
				publishedby = username;
				status = "published";
			} else if (StringUtils.isNullOrEmpty(status)) {
				approvedby = username;
				publishedby = username;
				status = "published";
			}
			content = new String(Base64.decodeBase64(content),"utf-8");
			content = getDbInfo(content,dbid);
			HashMap map = configDao.getConfig(pool,group,data,env,status);
			configDao.updateData(pool,group,data,env,content,"db",status,username,approvedby,publishedby,(String)map.get("md5"));
			returnSuccess(response);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
	
	
	@RequestMapping(params = "method=delConfig", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_DEV') or hasRole('MANAGE_TEST')  or hasRole('MANAGE_STAGE') or hasRole('MANAGE_PRODUCT')")
	public void delConfig(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="id") int id,
			ModelMap modelMap) {
		configDao.delConfig(id);

		returnSuccess(response);
	}
	
	@RequestMapping(params = "method=getGroups", method = RequestMethod.POST)
	@PreAuthorize("hasRole('VIEW_DEV') or hasRole('VIEW_TEST') or hasRole('VIEW_STAGE') or hasRole('VIEW_PRODUCT')")
	public void getGroups(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="env") String env,
			ModelMap modelMap) {
		List<HashMap> groups = configDao.getGroups(pool,env, 0, 100);
		List<HashMap> mygroups = new ArrayList<HashMap>();
		HashMap defaultGroup = new HashMap();
		String dgid= pool.replace("/", "_");
		defaultGroup.put("id", dgid);
		defaultGroup.put("group", dgid);
		mygroups.add(defaultGroup);
		for(int i=0;i<groups.size();i++){
			HashMap item = new HashMap();
			item.put("id", dgid+"_"+groups.get(i).get("group"));
			item.put("group", dgid+"_"+groups.get(i).get("group"));
			mygroups.add(item);
		}
		returnObject(response, mygroups);
	}
	
	@RequestMapping(params = "method=getConfigList", method = RequestMethod.POST)
	@PreAuthorize("hasRole('VIEW_DEV') or hasRole('VIEW_TEST') or hasRole('VIEW_STAGE') or hasRole('VIEW_PRODUCT')")
	public void getConfigList(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			@RequestParam(value ="env") String env,
			@RequestParam(value ="status") String status,
			
			@RequestParam(value ="page") int page,
			@RequestParam(value ="rows") int rows,
			ModelMap modelMap) {
		int total = configDao.getConfigSize(pool,group,env,status);
		List<HashMap> configs = configDao.getConfigs(pool,group,env,status,(page-1)*rows,rows);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		for(int i=0;i<configs.size();i++){
			Date d = (Date) configs.get(i).get("createtime");
			if(d == null)
				configs.get(i).put("createtime","");
			else
				configs.get(i).put("createtime",sdf.format(d));
		}
		request.getSession().setAttribute("defaultPool",pool);
		request.getSession().setAttribute("defaultGroup", group);
		HashMap map = new HashMap();
		map.put("total", total);
		map.put("rows", configs);
		returnObject(response, map);
	}
	
	
	
	@RequestMapping(params = "method=getApproveConfigList", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_PRODUCT')")
	public void getApproveConfigList(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			@RequestParam(value ="page") int page,
			@RequestParam(value ="rows") int rows,
			ModelMap modelMap) {
		
		List<HashMap> submitPro = configDao.getConfigs(pool, group, "product", "submit", (page-1)*rows, rows);
		
		HashMap map = new HashMap();
		ArrayList<HashMap> files = new ArrayList<HashMap>();
		if(submitPro.size() == 0){
			submitPro = configDao.getConfigs(pool, group, "product", "approved", (page-1)*rows, rows);
			for(int i=0;i<submitPro.size();i++){
				HashMap item = new HashMap();
				item.put("id", submitPro.get(i).get("id"));
				item.put("filename", submitPro.get(i).get("data"));
				files.add(item);
			}
			map.put("status", "待发布");
		} else {
			for(int i=0;i<submitPro.size();i++){
				HashMap item = new HashMap();
				item.put("id", submitPro.get(i).get("id"));
				item.put("filename", submitPro.get(i).get("data"));
				files.add(item);
			}
			map.put("status", "待审核");
		}
		map.put("files", files);
		map.put("pool", pool);
		map.put("group", group);
		if(submitPro.size()>0)
			map.put("approvedby", submitPro.get(0).get("approvedby"));
		else
			map.put("approvedby","");
		List<HashMap> list = new ArrayList();
		list.add(map);
		HashMap ret = new HashMap();
		ret.put("total", 1);
		ret.put("rows", list);
		returnObject(response, ret);
	}
	
	
	@RequestMapping(params = "method=getMyApproveConfigList", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_PRODUCT')")
	public void getMyApproveConfigList(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			@RequestParam(value ="page") int page,
			@RequestParam(value ="rows") int rows,
			ModelMap modelMap) {
		
		List<HashMap> submitPro = configDao.getConfigs(pool, group, "product", "submit", (page-1)*rows, rows);
		String my = getUserName();
		HashMap map = new HashMap();
		ArrayList<HashMap> files = new ArrayList<HashMap>();
		if(submitPro.size() == 0){
			submitPro = configDao.getConfigs(pool, group, "product", "approved", (page-1)*rows, rows);
			for(int i=0;i<submitPro.size();i++){
				if(my.equals(submitPro.get(i).get("approvedby"))){
					HashMap item = new HashMap();
					item.put("id", submitPro.get(i).get("id"));
					item.put("filename", submitPro.get(i).get("data"));
					files.add(item);
				}
			}
			if(submitPro.size()>0&&submitPro.get(0).get("publishedby").equals("")){
				map.put("status", "待审核");
			}else{
				map.put("status", "待发布");
			}
		} else {
			for(int i=0;i<submitPro.size();i++){
				if(my.equals(submitPro.get(i).get("approvedby"))){
					HashMap item = new HashMap();
					item.put("id", submitPro.get(i).get("id"));
					item.put("filename", submitPro.get(i).get("data"));
					files.add(item);
				}
			}
			map.put("status", "待审核");
		}
		map.put("files", files);
		map.put("pool", pool);
		map.put("group", group);
		if(submitPro.size()>0)
			map.put("approvedby", submitPro.get(0).get("approvedby"));
		else
			map.put("approvedby","");
		List<HashMap> list = new ArrayList();
		
		HashMap ret = new HashMap();
		if(files.size() >0){
			list.add(map);
			ret.put("total", 1);
			ret.put("rows", list);
		} else {
			ret.put("total", 0);
			ret.put("rows", list);
		}
		returnObject(response, ret);
	}
	
	@RequestMapping(params = "method=checkGroupConfigs", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_DEV') or hasRole('MANAGE_TEST')")
	public void checkGroupConfigs(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="fromGroup") String fromGroup,
			@RequestParam(value ="fromEnv") String fromEnv,
			@RequestParam(value ="toGroup") String toGroup,
			@RequestParam(value ="toEnv") String toEnv,
			@RequestParam(value ="page") int page,
			@RequestParam(value ="rows") int rows,
			ModelMap modelMap) {
		List<HashMap> fromPro = configDao.getConfigs(pool, fromGroup, fromEnv, "published", (page-1)*rows, rows);
		List<HashMap> toPro = configDao.getConfigs(pool, toGroup, toEnv, "published", (page-1)*rows, rows);
			
		
		DiffManager dm = new DiffManager();
		for(int i=0;i<fromPro.size();i++)
		{
			HashMap item = fromPro.get(i);
			dm.addFile(1, (Integer)item.get("id"), (String)item.get("data"), (String)item.get("md5"), (String)item.get("filetype"));
		}

		for(int i=0;i<toPro.size();i++)
		{
			HashMap item = toPro.get(i);
			dm.addFile(2, (Integer)item.get("id"), (String)item.get("data"), (String)item.get("md5"), (String)item.get("filetype"));
		}

		returnObject(response, dm.getDiffList());
	}
	
	@RequestMapping(params = "method=checkConfigList", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_PRODUCT')")
	public void checkConfigList(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			@RequestParam(value ="page") int page,
			@RequestParam(value ="rows") int rows,
			ModelMap modelMap) {
		List<HashMap> stg = configDao.getConfigs(pool, group, "stage", "published", (page-1)*rows, rows);
		List<HashMap> publishPro = configDao.getConfigs(pool, group, "product", "published", (page-1)*rows, rows);
		List<HashMap> submitPro = configDao.getConfigs(pool, group, "product", "submit", (page-1)*rows, rows);
		if(submitPro.size() == 0)
			submitPro = configDao.getConfigs(pool, group, "product", "approved", (page-1)*rows, rows);
			
		
		DiffManager dm = new DiffManager();
		for(int i=0;i<stg.size();i++)
		{
			HashMap item = stg.get(i);
			dm.addFile(1, (Integer)item.get("id"), (String)item.get("data"), (String)item.get("md5"), (String)item.get("filetype"));
		}

		for(int i=0;i<submitPro.size();i++)
		{
			HashMap item = submitPro.get(i);
			dm.addFile(2, (Integer)item.get("id"), (String)item.get("data"), (String)item.get("md5"), (String)item.get("filetype"));
		}

		for(int i=0;i<publishPro.size();i++)
		{
			HashMap item = publishPro.get(i);
			dm.addFile(3, (Integer)item.get("id"), (String)item.get("data"), (String)item.get("md5"), (String)item.get("filetype"));
		}
		returnObject(response, dm.getDiffList());
	}
	
	@RequestMapping(params = "method=submitFromIds", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_PRODUCT')")
	public void submitFromIds(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			@RequestParam(value ="ids") String ids,
			ModelMap modelMap) {
		
		List<Integer> idList = new ArrayList<Integer>();
		String [] idl = ids.split(",");
		for(int i=0;i<idl.length;i++){
			idList.add(Integer.parseInt(idl[i]));
		}
		if(idList.size() > 0){
			configDao.submitFromIds(pool,group,idl,getUserName());
		}
		returnSuccess(response);
		return;
		
	}
	
	@RequestMapping(params = "method=submitConfig", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_PRODUCT')")
	public void submitConfig(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			@RequestParam(value ="approver") String approvedby,
			ModelMap modelMap) {

		configDao.submitConfig(pool,group,getUserName(approvedby));
		returnSuccess(response);
		return;
	}
	
	
	
	@RequestMapping(params = "method=approveConfig", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_PRODUCT')")
	public void approveConfig(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			ModelMap modelMap) {

		configDao.approveConfig(pool,group,getUserName());
		returnSuccess(response);
		return;
	}
	
	@RequestMapping(params = "method=unapproveConfig", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_PRODUCT')")
	public void unapproveConfig(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			ModelMap modelMap) {

		configDao.unapproveConfig(pool,group,getUserName());
		returnSuccess(response);
		return;
	}
	
	@RequestMapping(params = "method=publishConfig", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_PRODUCT')")
	public void publishConfig(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			ModelMap modelMap) {

		configDao.publishConfig(pool,group,getUserName());
		returnSuccess(response);
		return;
	}
	
	@RequestMapping(params = "method=returnedConfig", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_PRODUCT')")
	public void returnedConfig(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			ModelMap modelMap) {

		configDao.returnedConfig(pool,group,getUserName());
		returnSuccess(response);
		return;
	}
	
	
	
	@RequestMapping(params = "method=cancelSubmit", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_PRODUCT')")
	public void cancelSubmit(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			ModelMap modelMap) {
		configDao.cancelSubmit(pool,group);
		returnSuccess(response);
	}
	@RequestMapping(params = "method=getConfigStatus", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_PRODUCT')")
	public void getConfigStatus(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			ModelMap modelMap) {

		List<HashMap> submits =  configDao.getConfigs(pool, group, "product", "submit", 0, 1000);
		List<HashMap> approveds =  configDao.getConfigs(pool, group, "product", "approved", 0, 1000);
		HashMap ret = new HashMap();
		if(submits.size()>0){
			String approvedby = (String) submits.get(0).get("approvedby");
			if(approvedby == null || approvedby.equals("")){ // 未提交审核
				ret.put("status", "1");
				ret.put("approvedby", "");
			} else {                                         // 已提交审核未审核
				ret.put("status", "2");
				ret.put("approvedby", approvedby);
			}
			ret.put("publishedby", "");
		} else { // 提交为0
			if(approveds.size() >0){ // 未发布
				String approvedby = (String) approveds.get(0).get("approvedby");
				String publishedby = (String) approveds.get(0).get("publishedby");
				if(publishedby == null || publishedby.equals("")){ // 未批准
					ret.put("status", "3");
					ret.put("approvedby", approvedby);
					ret.put("publishedby", "");
				} else { // 已批准待发布
					ret.put("status", "4");
					ret.put("approvedby", approvedby);
					ret.put("publishedby", publishedby);
				}
				
			} else { // 发布完成
				ret.put("status", "0");
				ret.put("approvedby", "");
				ret.put("publishedby", "");
			}
		}
		returnObject(response,ret);

	}
	
	
	
	
	@RequestMapping(params = "method=getDbs", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_DEV') or hasRole('MANAGE_TEST')  or hasRole('MANAGE_STAGE') or hasRole('MANAGE_PRODUCT')")
	public void getDbs(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="env") String env,
			ModelMap modelMap) {
		List<HashMap> dbs = configDao.getDbs(env, 0,1000);
		returnObject(response, dbs);
	}
	
	@RequestMapping(params = "method=getDbInsts", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_DEV') or hasRole('MANAGE_TEST')  or hasRole('MANAGE_STAGE') or hasRole('MANAGE_PRODUCT')")
	public void getDbInsts(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="dbid") int dbid,
			@RequestParam(value ="env") String env,
			ModelMap modelMap) {
		List<HashMap> dbs = configDao.getDbInsts(dbid,env, 0,1000);
		
		List<HashMap> ret = new ArrayList<HashMap> ();
		for(int i=0;i<dbs.size();i++){
			HashMap map = new HashMap();
			HashMap item = dbs.get(i);
			map.put("id", item.get("id"));
			map.put("name", item.get("dbname")+":"+item.get("master"));
			map.put("master",item.get("master"));
			ret.add(map);
		}
		returnObject(response, ret);
	}

	@RequestMapping(params = "method=getDbParams", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_DEV') or hasRole('MANAGE_TEST')  or hasRole('MANAGE_STAGE') or hasRole('MANAGE_PRODUCT')")
	public void getDbParams(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="env") String env,
			ModelMap modelMap) {
		List<HashMap> params = configDao.getDbParams(env, 0,1000);

		returnObject(response, params);
	}
	
	@RequestMapping(params = "method=loadDbProperty", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_DEV') or hasRole('MANAGE_TEST')  or hasRole('MANAGE_STAGE') or hasRole('MANAGE_PRODUCT')")
	public void loadDbProperty(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="dbid") int  dbid,
			ModelMap modelMap) {
		HashMap dbinfo = configDao.getDbById(dbid);

		//		select id,dbname,dbalias,server,port,`user`,`password`,env,master from config_db where id = #{dbid}

		HashMap ret = new HashMap();
		ret.put("data", dbinfo.get("dbname")+"_"+dbinfo.get("master")+".properties");
		StringBuffer sb = new StringBuffer();
		List<HashMap> params = configDao.getDbParams((String)dbinfo.get("env"), 0,1000);
		
		sb.append("jdbc.url=jdbc:mysql://").append(dbinfo.get("server")).append(":");
		sb.append(dbinfo.get("port")).append("/").append(dbinfo.get("dbalias")).append("?autoReconnect=true&autoReconnectForPools=true&allowMultiQueries=true&zeroDateTimeBehavior=convertToNull").append("\n");
		sb.append("jdbc.username=******\njdbc.password=******\n");
		for(int i=0;i<params.size();i++){
			HashMap map = params.get(i);
			sb.append("jdbc.").append(map.get("name")).append("=").append(map.get("value")).append("\n");
		}
		ret.put("content", sb.toString());
		returnObject(response, ret);
	}
	
	
	@RequestMapping(params = "method=updateDbParam", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_DEV') or hasRole('MANAGE_TEST')  or hasRole('MANAGE_STAGE') or hasRole('MANAGE_PRODUCT')")
	public void updateDbParam(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="param") String param,
			@RequestParam(value ="value") String value,
			@RequestParam(value ="content") String content,
			ModelMap modelMap) {
		try {
			content = new String(Base64.decodeBase64(content),"utf-8");
			String [] items = content.split("\n");
			for(int i=0;i<items.length;i++){
				if(items[i].startsWith("jdbc."+param+"=")){
					items[i] = "jdbc."+param+"=" + value;
				}
			}
			StringBuffer sb = new StringBuffer();
			for(int i=0;i<items.length;i++){
				sb.append(items[i]).append("\n");
			}
			HashMap ret = new HashMap();
			ret.put("content", sb.toString());
			returnObject(response, ret);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@RequestMapping(params = "method=uploadProperty", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_DEV') or hasRole('MANAGE_TEST')  or hasRole('MANAGE_STAGE') or hasRole('MANAGE_PRODUCT')")
	public void uploadProperty(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			@RequestParam(value ="fileid") int fileid,
			@RequestParam(value ="env") String env,
			@RequestParam(value ="status",required= false) String status,
			
			ModelMap modelMap) {
		if(status == null || status.equals(""))
			status = "published";
		TempFile tf = configDao.getTempFile(fileid);
		
		HashMap map = configDao.getConfig(pool,group,tf.getFilename(),env,status);
		
		//int count = configDao.countData(pool,group,env,tf.getFilename().toLowerCase());
		String username = getUserName();
		if(map != null)
		{
			if(status.equals("published"))
				configDao.updateData(pool, group, tf.getFilename(), env, tf.getData(), tf.getFiletype(), status, username, username, username,(String)map.get("md5"));
			else
				configDao.updateData(pool, group, tf.getFilename(), env, tf.getData(), tf.getFiletype(), status, username, "", "",(String)map.get("md5"));
		} else {
			if(status.equals("published"))
				configDao.addData(pool,group,tf.getFilename(),env,tf.getData(),tf.getFiletype(),status,username,username,username);
			else
				configDao.addData(pool,group,tf.getFilename(),env,tf.getData(),tf.getFiletype(),status,username,"","");
		}
		returnSuccess(response);
	}
	
	@RequestMapping(params = "method=viewProperty", method = RequestMethod.GET)
	@PreAuthorize("hasRole('VIEW_DEV') or hasRole('VIEW_TEST') or hasRole('VIEW_STAGE') or hasRole('VIEW_PRODUCT')")
	public String viewProperty(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			@RequestParam(value ="env") String env,
			@RequestParam(value ="id") int id,
			ModelMap modelMap) {
		HashMap map = configDao.getConfigById(id);
		modelMap.put("data", map.get("data"));
		modelMap.put("pool", map.get("pool"));
		modelMap.put("group", map.get("group"));
		modelMap.put("env", map.get("env"));
		modelMap.put("status", map.get("status"));
		if("db".equals(map.get("filetype"))){
			modelMap.put("content", encryptDbInfo(map.get("content").toString()).replace("\n", "<br>"));
		}else {
			modelMap.put("content", map.get("content").toString().replace("\n", "<br>"));
		}
		modelMap.put("submitby", map.get("submitby"));
		modelMap.put("approvedby", map.get("approvedby"));
		modelMap.put("publishedby", map.get("publishedby"));
		Date d = (Date) map.get("createtime");
		if(d != null){
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			modelMap.put("createtime", sdf.format(d));
		} else {
			modelMap.put("createtime", "");
		}
		return "/admin/viewProperty";
	}
	
	
	@RequestMapping(params = "method=historydProperty", method = RequestMethod.GET)
	@PreAuthorize("hasRole('VIEW_DEV') or hasRole('VIEW_TEST') or hasRole('VIEW_STAGE') or hasRole('VIEW_PRODUCT')")
	public String historydProperty(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			@RequestParam(value ="env") String env,
			@RequestParam(value ="id") int id,
			ModelMap modelMap) {
		HashMap map = configDao.getConfigById(id);
		List<HashMap> hisItems = configDao.getHisConfig(pool,group,env,(String)map.get("data"));
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		for(int i=0;i<hisItems.size();i++){
			Date createTime = (Date) hisItems.get(i).get("createtime");
			hisItems.get(i).put("createtime",sdf.format(createTime));
		}
		modelMap.put("configFile", (String)map.get("data"));
		modelMap.put("hisItems", hisItems);
		return "/admin/historyProperty";
	}
	
	@RequestMapping(params = "method=copyProperties", method = RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_DEV') or hasRole('MANAGE_TEST'))")
	public void copyProperties(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="fromGroup") String fromGroup,
			@RequestParam(value ="fromEnv") String fromEnv,
			@RequestParam(value ="toGroup") String toGroup,
			@RequestParam(value ="toEnv") String toEnv,
			ModelMap modelMap) {
		configDao.moveConfigs(pool,fromGroup,fromEnv,toGroup,toEnv);
		returnSuccess(response);
	}
	
	@RequestMapping(params = "method=diffProperty", method = RequestMethod.GET)
	@PreAuthorize("hasRole('VIEW_DEV') or hasRole('VIEW_TEST') or hasRole('VIEW_STAGE') or hasRole('VIEW_PRODUCT')")
	public String diffProperty(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="lid") int lid,
			@RequestParam(value ="rid") int rid,
			@RequestParam(value="leftTitle",required=false) String leftTitle,
			@RequestParam(value="rightTitle",required=false) String rightTitle,
			ModelMap modelMap) {
		HashMap lMap = configDao.getConfigById(lid);
		HashMap rMap = configDao.getConfigById(rid);
		
		if(lMap == null){
			modelMap.put("leftContent","");
		}else {
			if("db".equals(lMap.get("filetype"))){
				modelMap.put("leftContent", this.encryptDbInfo((String)lMap.get("content")));
			} else {
				modelMap.put("leftContent", ((String)lMap.get("content")));
			}
		}
		if(rMap == null){
			modelMap.put("rightContent","");
		} else {
			if("db".equals(rMap.get("filetype"))){
				modelMap.put("rightContent", this.encryptDbInfo((String)rMap.get("content")));
			} else {
				modelMap.put("rightContent", ((String)rMap.get("content")));
			}
		}
		if(leftTitle == null || leftTitle.length() == 0){
			String env = (String) lMap.get("env");
			if(env.equals("stage"))
				modelMap.put("leftTitle", "STG环境配置");
			else
				modelMap.put("leftTitle", "线上环境配置");
		} else {
			modelMap.put("leftTitle", leftTitle);
		}
		if(rightTitle == null || rightTitle.length() == 0)
			modelMap.put("rightTitle", "待审核配置");
		else
			modelMap.put("rightTitle", rightTitle);
		
		return "/admin/diffPropertys";
	}
	
	@RequestMapping(params = "method=diffPropertys", method = RequestMethod.GET)
	@PreAuthorize("hasRole('VIEW_DEV') or hasRole('VIEW_TEST') or hasRole('VIEW_STAGE') or hasRole('VIEW_PRODUCT')")
	public String diffPropertys(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="id") int id,
			ModelMap modelMap) {
		HashMap hisMap = configDao.getHisConfigById(id);
		HashMap baseMap = configDao.getConfig((String)hisMap.get("pool"), (String)hisMap.get("group"), 
				(String)hisMap.get("data"), (String)hisMap.get("env"), (String)hisMap.get("status"));
		
		if("db".equals(hisMap.get("filetype"))){
			modelMap.put("leftContent", this.encryptDbInfo((String)hisMap.get("content")));
			modelMap.put("rightContent", this.encryptDbInfo((String)baseMap.get("content")));
		} else {
			modelMap.put("leftContent", ((String)hisMap.get("content")));
			modelMap.put("rightContent", ((String)baseMap.get("content")));
		}
		modelMap.put("leftTitle", "历史配置");
		modelMap.put("rightTitle", "当前配置");
		return "/admin/diffPropertys";
	}
	
	
	@RequestMapping(params = "method=downloadHisPropertys", method = RequestMethod.GET)
	@PreAuthorize("hasRole('VIEW_DEV') or hasRole('VIEW_TEST') or hasRole('VIEW_STAGE') or hasRole('VIEW_PRODUCT')")
	public String downloadHisPropertys(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="id") int id,
			ModelMap modelMap) throws UnsupportedEncodingException {
		HashMap map = configDao.getHisConfigById(id);
String content = map.get("content").toString();
		
		if("db".equals(map.get("filetype"))){
			modelMap.put("content", encryptDbInfo(map.get("content").toString()).replace("\n", "<br>"));
		}else {
			modelMap.put("content", map.get("content").toString().replace("\n", "<br>"));
		}
		
		response.setCharacterEncoding("utf-8");
        response.setContentType("multipart/form-data");
        response.setHeader("Content-Disposition", "attachment;fileName="
                + new String(map.get("data").toString().getBytes(),"iso-8859-1"));
        try {

 
            OutputStream os = response.getOutputStream();
            InputStream   inputStream   = null;
            byte[] bytes;
            if("db".equals(map.get("filetype"))){
            	content = encryptDbInfo(content);
            	bytes = content.getBytes("UTF-8");
    		} else if("other".equals(map.get("filetype"))){
    			bytes = Base64.decodeBase64(content);
    		} else {
    			bytes = content.getBytes("UTF-8");
    		}
            
            inputStream = new   ByteArrayInputStream(bytes);  
            byte[] b = new byte[2048];
            int length;
            while ((length = inputStream.read(b)) > 0) {
                os.write(b, 0, length);
            }
 
             // 这里主要关闭。
            os.close();
 
            inputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        } 
            //  返回值要注意，要不然就出现下面这句错误！
            //java+getOutputStream() has already been called for this response
        return null;
	}
	@RequestMapping(params = "method=downloadProperty", method = RequestMethod.GET)
	@PreAuthorize("hasRole('VIEW_DEV') or hasRole('VIEW_TEST') or hasRole('VIEW_STAGE') or hasRole('VIEW_PRODUCT')")
	public String downloadProperty(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			@RequestParam(value ="env") String env,
			@RequestParam(value ="id") int id,
			ModelMap modelMap) throws UnsupportedEncodingException {
		
		HashMap map = configDao.getConfigById(id);
		String content = map.get("content").toString();
		
		if("db".equals(map.get("filetype"))){
			modelMap.put("content", encryptDbInfo(map.get("content").toString()).replace("\n", "<br>"));
		}else {
			modelMap.put("content", map.get("content").toString().replace("\n", "<br>"));
		}
		
		response.setCharacterEncoding("utf-8");
        response.setContentType("multipart/form-data");
        response.setHeader("Content-Disposition", "attachment;fileName="
                + new String(map.get("data").toString().getBytes(),"iso-8859-1"));
        try {

 
            OutputStream os = response.getOutputStream();
            InputStream   inputStream   = null;
            byte[] bytes;
            if("db".equals(map.get("filetype"))){
            	content = encryptDbInfo(content);
            	bytes = content.getBytes("UTF-8");
    		} else if("other".equals(map.get("filetype"))){
    			bytes = Base64.decodeBase64(content);
    		} else {
    			bytes = content.getBytes("UTF-8");
    		}
            
            inputStream = new   ByteArrayInputStream(bytes);  
            byte[] b = new byte[2048];
            int length;
            while ((length = inputStream.read(b)) > 0) {
                os.write(b, 0, length);
            }
 
             // 这里主要关闭。
            os.close();
 
            inputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        } 
            //  返回值要注意，要不然就出现下面这句错误！
            //java+getOutputStream() has already been called for this response
        return null;
 
	}
	
	@RequestMapping(params = "method=downloadPropertys", method = RequestMethod.GET)
	@PreAuthorize("hasRole('VIEW_DEV') or hasRole('VIEW_TEST') or hasRole('VIEW_STAGE') or hasRole('VIEW_PRODUCT')")
	public String downloadPropertys(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="group") String group,
			@RequestParam(value ="env") String env,
			@RequestParam(value ="status") String status,
			ModelMap modelMap) throws UnsupportedEncodingException {
		List<HashMap> list = configDao.getAllConfigs(pool,group,env,status);
		List<ConfigInfo> configs = new ArrayList<ConfigInfo>();
		for(int i=0;i<list.size();i++){
			HashMap item = list.get(i);
			ConfigInfo ci = new ConfigInfo();
			ci.setFileName((String)item.get("data"));
			
			String content = (String) item.get("content");
            byte[] bytes;
            if("db".equals(item.get("filetype"))){
            	content = encryptDbInfo(content);
            	bytes = content.getBytes("UTF-8");
    		} else if("other".equals(item.get("filetype"))){
    			bytes = Base64.decodeBase64(content);
    		} else {
    			bytes = content.getBytes("UTF-8");
    		}
            ci.setFileContent(bytes);
            Date createTime = (Date) item.get("createtime");
            ci.setCreateTime(createTime.getTime());
            configs.add(ci);
		}
		String fileName = group+"_"+env+".zip";
		//String path = "/Users/zhengchen/Documents/datas";
		String path = DownloadTools.sWorkDir;
		ZipTool.zip(configs, path + File.separator + fileName);
		
		response.setCharacterEncoding("utf-8");
        response.setContentType("multipart/form-data");
        response.setHeader("Content-Disposition", "attachment;fileName="
                + new String(fileName.getBytes(),"iso-8859-1"));
        try {
            InputStream inputStream = new FileInputStream(new File(path
                    + File.separator + fileName));
 
            OutputStream os = response.getOutputStream();
            byte[] b = new byte[2048];
            int length;
            while ((length = inputStream.read(b)) > 0) {
                os.write(b, 0, length);
            }
            os.flush();
             // 这里主要关闭。
            os.close();
 
            inputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return null;
 
	}
	
	private String encryptDbInfo(String content)
	{
		String [] items = content.split("\n");
		for(int i=0;i<items.length;i++){
			if(items[i].startsWith("jdbc.username=")){
				items[i] = "jdbc.username=******";
			}
			if(items[i].startsWith("jdbc.password")){
				items[i] = "jdbc.password=******";
			}
		}
		StringBuffer sb = new StringBuffer();
		for(int i=0;i<items.length;i++){
			sb.append(items[i]).append("\n");
		}
		return sb.toString();
	}
	private String getDbInfo(String content,int dbid){
		HashMap map = configDao.getDbById(dbid);
		String [] items = content.split("\n");
		for(int i=0;i<items.length;i++){
			if(items[i].startsWith("jdbc.username=")){
				items[i] = "jdbc.username=" + map.get("user");
			}
			if(items[i].startsWith("jdbc.password")){
				items[i] = "jdbc.password=" + map.get("password");
			}
		}
		StringBuffer sb = new StringBuffer();
		for(int i=0;i<items.length;i++){
			sb.append(items[i]).append("\n");
		}
		return sb.toString();
	}
	
	/*
	@RequestMapping(params = "method=getDatabases", method = RequestMethod.GET)
	public void getDatabases(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="env") String env,
			ModelMap modelMap) throws UnsupportedEncodingException {
		List<HashMap> datas = configDao.getDbs(env, 0, 1000);
		List<DBInfo> list = new ArrayList<DBInfo>();
		for(int i=0;i<datas.size();i++){
			HashMap item = datas.get(i);
			DBInfo info = new DBInfo();
			info.setName((String)item.get("name"));
			info.setAlias((String)item.get("dbalias"));
			list.add(info);
		}
		returnObject(response, list);
	}


	@RequestMapping(params = "method=getDatabaseInstances", method = RequestMethod.GET)
	public void getDatabaseInstance(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="env") String env,
			@RequestParam(value ="dbname") String dbname,
			ModelMap modelMap) throws UnsupportedEncodingException {
		List<HashMap> datas = configDao.getDbInstancesByName(env, dbname);
		List<DBInstance> list = new ArrayList<DBInstance>();
		for(int i=0;i<datas.size();i++){
			HashMap item = datas.get(i);
			DBInstance info = new DBInstance();
			info.setName((String)item.get("dbname"));
			info.setAlias((String)item.get("dbalias"));
			info.setHost((String)item.get("server"));
			info.setPort((Integer)item.get("port"));
			info.setUser((String)item.get("user"));
			info.setPassword((String)item.get("password"));
			String master = (String)item.get("master");
			info.setMaster("master".equals(master));
			list.add(info);
		}
		returnObject(response, list);
	}

	@RequestMapping(params = "method=getDatabaseInstanceWithType", method = RequestMethod.GET)
	public void getDatabaseInstanceWithType(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="env") String env,
			@RequestParam(value ="dbname") String dbname,
			@RequestParam(value ="master") Boolean master,
			ModelMap modelMap) throws UnsupportedEncodingException {
		List<HashMap> datas = configDao.getDbInstancesByName(env, dbname);
		for(int i=0;i<datas.size();i++){
			HashMap item = datas.get(i);
			DBInstance info = new DBInstance();
			info.setName((String)item.get("dbname"));
			info.setAlias((String)item.get("dbalias"));
			info.setHost((String)item.get("server"));
			info.setPort((Integer)item.get("port"));
			info.setUser((String)item.get("user"));
			info.setPassword((String)item.get("password"));
			String m = (String)item.get("master");
			if(m == null)
				continue;
			if(master&&"master".equals(m))
				returnObject(response, info);
			if(!master&&"slave".equals(m))
				returnObject(response, info);
			
		}
	}*/
	
	
}
