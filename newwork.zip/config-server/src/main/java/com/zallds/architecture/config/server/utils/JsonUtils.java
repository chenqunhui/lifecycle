package com.zallds.architecture.config.server.utils;

import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class JsonUtils {
	public static String toJson(Object obj){
		String ret = null;
		if(obj instanceof List ){
			ret = encode(JSONArray.fromObject(obj).toString());
		}else{
			ret = encode(JSONObject.fromObject(obj).toString());
		}
		return ret;
	}
	
	public static String encode(String json){
		//System.out.println(json);
		StringBuilder encodedJson = new StringBuilder();
		for(int i=0; i<json.length();i++){
		    char c = json.charAt(i);
		    if(c>127){
		        encodedJson.append("\\u").append(Integer.toHexString(c));
		    }else{
		        encodedJson.append(c);
		    }
		}
		String ret = encodedJson.toString();
		ret = ret.replace("\n", "\\n");
		//encodedJson =encodedJson.replace(start, end, str) 
//		System.out.println(ret);
		return ret; 
	}
}

