package com.zallds.architecture.config.server.controller;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.zallds.architecture.config.server.dao.ConfigDao;
import com.zallds.architecture.config.server.utils.Encrypter;

@Controller
@RequestMapping(value="/sys.do") 
public class SystemController extends BaseController{

	Log log = LogFactory.getLog(SystemController.class);
	
	@Autowired
	private ConfigDao configDao;
	
	@RequestMapping(params = "method=listPool", method = RequestMethod.GET)
	@PreAuthorize("hasRole('MANAGE_SYS_POOL')")
	public String listPool(HttpServletRequest request, HttpServletResponse response, ModelMap modelMap) {

		return "/system/list_pool";
	}
	
	@RequestMapping(params = "method=listGroup", method = RequestMethod.GET)
	@PreAuthorize("hasRole('MANAGE_SYS_GROUP')")
	public String listGroup(HttpServletRequest request, HttpServletResponse response, ModelMap modelMap) {

		List<HashMap> pools = getUserPools();
		modelMap.put("pools", pools);
		if(pools.size()>0){
			modelMap.put("defaultPool", pools.get(0).get("pool"));
		}
		return "/system/list_group";
	}
	
	@RequestMapping(params = "method=listDb", method = RequestMethod.GET)
	@PreAuthorize("hasRole('MANAGE_SYS_CONFIGDB')")
	public String listDb(HttpServletRequest request, HttpServletResponse response, ModelMap modelMap) {

		return "/system/list_db";
	}
	
	@RequestMapping(params = "method=listDbInstance", method = RequestMethod.GET)
	@PreAuthorize("hasRole('MANAGE_SYS_CONFIGDB')")
	public String listDbInstance(HttpServletRequest request, HttpServletResponse response, ModelMap modelMap) {
		List<HashMap> dbs = configDao.getDbs(0,1000);
		modelMap.put("dbs", dbs);
		if(dbs.size()>0){
			modelMap.put("defaultDb", dbs.get(0).get("id"));
		}
		return "/system/list_dbInstance";
	}
	
	@RequestMapping(params = "method=listDbKv", method = RequestMethod.GET)
	@PreAuthorize("hasRole('MANAGE_SYS_CONFIGDB')")
	public String listDbKv(HttpServletRequest request, HttpServletResponse response, ModelMap modelMap) {
		return "/system/list_dbkv";
	}
	
	@RequestMapping(params = "method=listModelKv", method = RequestMethod.GET)
	@PreAuthorize("hasRole('MANAGE_SYS_CONFIGDB')")
	public String listModelKv(HttpServletRequest request, HttpServletResponse response, ModelMap modelMap) {
		return "/system/list_modelkv";
	}
	
	@RequestMapping(params = "method=getPoolList",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_SYS_POOL')")
	public void getPoolList(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="page") int page,
			@RequestParam(value ="rows") int rows,
			ModelMap modelMap) {
		int total = 0;//configDao.getPoolSize();
		List<HashMap> rowsData = configDao.getPools((page -1)*rows, rows);

		HashMap ret =new HashMap();
		ret.put("total", total);
		ret.put("rows", rowsData);
		super.returnObject(response, ret);
	}
	
	@RequestMapping(params = "method=getGroups",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_SYS_GROUP')")
	public void getGroups(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="pool") String pool,
			@RequestParam(value ="page") int page,
			@RequestParam(value ="rows") int rows,
			ModelMap modelMap) {
		int total = configDao.getAllGroupSize(pool);
		List<HashMap> rowsData = configDao.getAllGroups(pool,(page -1)*rows, rows);

		HashMap ret =new HashMap();
		ret.put("total", total);
		ret.put("rows", rowsData);
		super.returnObject(response, ret);
	}
	@RequestMapping(params = "method=addGroup",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_SYS_GROUP')")
	public void addGroup(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="poolName") String poolName,
			@RequestParam(value ="env") String env,
			@RequestParam(value ="groupName") String groupName,
			ModelMap modelMap) {
		try{
			
			configDao.addGroup(poolName,env,groupName);
		super.returnSuccess(response);
		}catch(Exception exp){
			super.returnError(response,"添加失败");
		}
	}
	
	@RequestMapping(params = "method=delGroup",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_SYS_GROUP')")
	public void delGroup(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="id") int id,
			ModelMap modelMap) {
		configDao.delGroup(id);
		super.returnSuccess(response);
	}
	
	@RequestMapping(params = "method=addPool",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_SYS_POOL')")
	public void addPool(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="poolName") String poolName,
			ModelMap modelMap) {
		try{
			String pools[] = poolName.split(",");
			for(int i=0;i<pools.length;i++){
				String pool = pools[i].trim();
				if(pool.length() >0){
					try{
//						configDao.addPool(pool);	
					}catch(Exception exp){
						
					}
				}
			}
		super.returnSuccess(response);
		}catch(Exception exp){
			super.returnError(response,"添加失败");
		}
	}
	
	@RequestMapping(params = "method=delPool",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_SYS_POOL')")
	public void delPool(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="id") int id,
			ModelMap modelMap) {
//		configDao.delPool(id);
		super.returnSuccess(response);
	}
	
	@RequestMapping(params = "method=getDbList",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_SYS_CONFIGDB')")
	public void getDbList(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="page") int page,
			@RequestParam(value ="rows") int rows,
			ModelMap modelMap) {
		int total = configDao.getDbSize();
		List<HashMap> rowsData = configDao.getDbs((page -1)*rows, rows);

		HashMap ret =new HashMap();
		ret.put("total", total);
		ret.put("rows", rowsData);
		super.returnObject(response, ret);
	}
	
	@RequestMapping(params = "method=addDb",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_SYS_CONFIGDB')")
	public void addDb(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="dbName") String dbname,
			@RequestParam(value ="dbAlias") String dbalias,
			ModelMap modelMap) {
		try{
			configDao.addDB(dbname,dbalias);
		super.returnSuccess(response);
		}catch(Exception exp){
			super.returnError(response,"添加失败");
		}
	}
	
	@RequestMapping(params = "method=delDb",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_SYS_CONFIGDB')")
	public void delDb(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="id") int id,
			ModelMap modelMap) {
		configDao.delDb(id);
		configDao.delDbInstanceWithDbId(id);
		super.returnSuccess(response);
	}
	
	
	@RequestMapping(params = "method=getDbInstanceList",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_SYS_CONFIGDB')")
	public void getDbInstanceList(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="dbid") int dbid,
			@RequestParam(value ="page") int page,
			@RequestParam(value ="rows") int rows,
			ModelMap modelMap) {
		int total = configDao.getDbInstanceSize(dbid);
		List<HashMap> rowsData = configDao.getDbInstances(dbid,(page -1)*rows, rows);

		HashMap ret =new HashMap();
		ret.put("total", total);
		ret.put("rows", rowsData);
		super.returnObject(response, ret);
	}
	
	@RequestMapping(params = "method=addDbInstance",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_SYS_CONFIGDB')")
	public void addDbInstance(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="dbid") int dbid,
			@RequestParam(value ="dbname") String dbname,
			@RequestParam(value ="dbalias") String dbalias,
			@RequestParam(value ="server") String server,
			@RequestParam(value ="port") int  port,
			@RequestParam(value ="user") String user,
			@RequestParam(value ="password") String password,
			
			@RequestParam(value ="env") String env,
			@RequestParam(value ="master") String master,
			ModelMap modelMap) {
		try{
			password = Encrypter.encrypt(password);
			configDao.addDbInstance(dbid,dbname,dbalias,server,port,user,password,env,master);
		super.returnSuccess(response);
		}catch(Exception exp){
			super.returnError(response,"添加失败");
		}
	}
	
	@RequestMapping(params = "method=delDbInstance",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_SYS_CONFIGDB')")
	public void delDbInstance(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="dbid") int dbid,
			@RequestParam(value ="id") int id,
			ModelMap modelMap) {
		configDao.delDbInstance(dbid,id);
		super.returnSuccess(response);
	}
	
	@RequestMapping(params = "method=getDbKvList",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_SYS_CONFIGDB')")
	public void getDbKvList(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="page") int page,
			@RequestParam(value ="rows") int rows,
			ModelMap modelMap) {
		int total = configDao.getDbKvSize();
		List<HashMap> rowsData = configDao.getDbKvs((page -1)*rows, rows);

		HashMap ret =new HashMap();
		ret.put("total", total);
		ret.put("rows", rowsData);
		super.returnObject(response, ret);
	}
	
	@RequestMapping(params = "method=addDbKv",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_SYS_CONFIGDB')")
	public void addDbKv(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="key") String key,
			@RequestParam(value ="value") String value,
			@RequestParam(value ="env") String env,
			ModelMap modelMap) {
		try{
			configDao.addDbKv(key,value,env);
		super.returnSuccess(response);
		}catch(Exception exp){
			super.returnError(response,"添加失败");
		}
	}
	
	@RequestMapping(params = "method=delDbKv",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_SYS_CONFIGDB')")
	public void delDbKv(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="id") int id,
			ModelMap modelMap) {
		configDao.delDbKv(id);
		super.returnSuccess(response);
	}

	@RequestMapping(params = "method=getModelKvList",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_SYS_CONFIGDB') or hasRole('MANAGE_SYS_CONFIG')")
	public void getModelKvList(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="env") String env,
			@RequestParam(value ="type") String type,
			@RequestParam(value ="group", required = false) String group,
			@RequestParam(value ="page") int page,
			@RequestParam(value ="rows") int rows,
			ModelMap modelMap) {
		int total = configDao.getModelKvSize();
		if (StringUtils.isBlank(type)) {
			type = null;
		}
		if (StringUtils.isBlank(env)) {
			env = null;
		}
		List<HashMap> rowsData = configDao.getModelKvs(env, type, (page -1)*rows, rows);
		
		//redis模板，配置com.zallds.redis.prefix默认使用group
		if (rowsData != null && group != null) {
			String prefixKey = "com.zallds.redis.prefix";
			String prefixDefVal = "test";
			for (HashMap map : rowsData) {
				if (! prefixKey.equals(map.get("key"))) {
					continue;
				}
				String prefix = (String) map.get(prefixKey);
				if (prefix == null || prefix.length() == 0 || prefixDefVal.equals(prefix)) {
					map.put("value", group);
				}
			}
		}

		HashMap ret =new HashMap();
		ret.put("total", total);
		ret.put("rows", rowsData);
		super.returnObject(response, ret);
	}
	
	@RequestMapping(params = "method=addModelKv",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_SYS_CONFIGDB') or hasRole('MANAGE_SYS_CONFIG')")
	public void addModelKv(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="key") String key,
			@RequestParam(value ="value") String value,
			@RequestParam(value ="env") String env,
			@RequestParam(value ="type") String type,
			@RequestParam(value ="group") String group,
			ModelMap modelMap) {
		try{
			configDao.addModelKv(key,value,env,type,group);
		super.returnSuccess(response);
		}catch(Exception exp){
			super.returnError(response,"添加失败");
		}
	}
	
	@RequestMapping(params = "method=delModelKv",method= RequestMethod.POST)
	@PreAuthorize("hasRole('MANAGE_SYS_CONFIGDB' or hasRole('MANAGE_SYS_CONFIG'))")
	public void delModelKv(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam(value ="id") int id,
			ModelMap modelMap) {
		configDao.delModelKv(id);
		super.returnSuccess(response);
	}
	
}
