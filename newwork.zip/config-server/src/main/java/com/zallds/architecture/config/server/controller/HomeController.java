package com.zallds.architecture.config.server.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	@RequestMapping(value="/home.do")  
	public String index(HttpServletRequest request, HttpServletResponse response, ModelMap modelMap) {
		HttpSession session = request.getSession();
		if(session.isNew())
			return "login";
		if(session == null)
			return "login";
		List<String> results = new ArrayList<String>();
		//List<HashMap> dbs = venusService.getMysqlDatabasee(getUserName());
		//modelMap.addAttribute("databases", dbs);
		return "home";
	}
}
