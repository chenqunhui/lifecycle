package com.zallds.architecture.config.server.dao.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.mybatis.spring.support.SqlSessionDaoSupport;

import com.zallds.architecture.config.server.dao.ConfigDao;
import com.zallds.architecture.config.server.model.TempFile;
import com.zallds.architecture.config.server.utils.MD5;

public class ConfigDaoImpl extends SqlSessionDaoSupport implements ConfigDao{

	public boolean authUser(String username, String encodedPassword) {
		HashMap map = new HashMap();
		map.put("username", getUserName(username));
		map.put("password", encodedPassword);
		int count = this.getSqlSession().selectOne("authUser",map);
		return count>0;
	}

	public List<String> findUserAuthorities(String username) {

		return this.getSqlSession().selectList("findUserAuthorities", getUserName(username));
	}

	private String getUserName(String username){
		if(username.endsWith("@zallds.com")){
			return username;
		} else {
			return username +"@zallds.com";
		}
	}

	public int getPoolSize() {
		
		return this.getSqlSession().selectOne("getPoolSize");
	}

	public List<HashMap> getPools(int start, int rows) {
		HashMap map = new HashMap();
		map.put("start", start);
		map.put("rows", rows);
		return this.getSqlSession().selectList("getPools",map);
	}

	public void addPool(String poolName) {
		this.getSqlSession().insert("addPool",poolName);
		
	}

	public void delPool(int id) {
		this.getSqlSession().delete("delPool",id);
		
	}

	public int getGroupSize(String pool,String env) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("env", env);
		return this.getSqlSession().selectOne("getGroupSize",map);
	}

	public List<HashMap> getGroups(String pool,String env, int start, int rows) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("env", env);
		map.put("start", start);
		map.put("rows", rows);
		return this.getSqlSession().selectList("getGroups",map);
	}

	public int getAllGroupSize(String pool) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		return this.getSqlSession().selectOne("getAllGroupSize",map);
	}

	public List<HashMap> getAllGroups(String pool, int start, int rows) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("start", start);
		map.put("rows", rows);
		return this.getSqlSession().selectList("getAllGroups",map);
	}
	
	public void addGroup(String poolName,String env, String groupName) {
		HashMap map = new HashMap();
		map.put("pool", poolName);
		map.put("env", env);
		map.put("group", groupName);
		this.getSqlSession().insert("addGroup",map);
		
	}

	public void delGroup(int id) {
		this.getSqlSession().delete("delGroup",id);
		
	}

	public int getUserSize(String filter) {
		HashMap map = new HashMap();
		if(filter != null && filter.length() >0)
			map.put("filter", filter);
		return this.getSqlSession().selectOne("getUserSize",map);
	}

	public List<HashMap> getUsers(String filter,int start, int rows) {
		HashMap map = new HashMap();
		map.put("start", start);
		map.put("rows", rows);
		if(filter != null && filter.length() >0)
			map.put("filter", filter);
		return this.getSqlSession().selectList("getUsers",map);
	}

	public void addUser(String userName, String password) {
		HashMap map = new HashMap();
		map.put("username", userName);
		map.put("password", password);
		this.getSqlSession().insert("addUser",map);
	}

	public void delUser(int id) {
		this.getSqlSession().delete("delUser",id);
	}

	public List<HashMap> getAllRoles() {
		return this.getSqlSession().selectList("getAllRoles");
	}

	public int getUserRoleSize(String filterUser,String filterRole) {
		HashMap map = new HashMap();
		if(filterUser!= null&&filterUser.length()>0)
			map.put("filterUser", filterUser);
		if(filterRole!= null&&filterRole.length()>0)
			map.put("filterRole", filterRole);
		return this.getSqlSession().selectOne("getUserRoleSize",map);
	}

	public List<HashMap> getUserRoles(String filterUser,String filterRole,int start, int rows) {
		HashMap map = new HashMap();
		if(filterUser!= null&&filterUser.length()>0)
			map.put("filterUser", filterUser);
		if(filterRole!= null&&filterRole.length()>0)
			map.put("filterRole", filterRole);
		map.put("start", start);
		map.put("rows", rows);
		return this.getSqlSession().selectList("getUserRoles",map);
	}

	public void addUserRole(String userName, String rolename) {
		HashMap map = new HashMap();
		map.put("username", userName);
		map.put("rolename", rolename);
		this.getSqlSession().insert("addUserRole",map);
	}

	public void delUserRole(int id) {
		this.getSqlSession().delete("delUserRole",id);
	}

	public List<HashMap> getAllAuths() {
		
		return this.getSqlSession().selectList("getAllAuths");
	}

	public int getRoleAuthSize(String filterRole,String filterAuth) {
		HashMap map = new HashMap();
		if(filterRole!=null&&filterRole.length()>0)
			map.put("filterRole", filterRole);
		if(filterAuth!=null&&filterAuth.length()>0)
			map.put("filterAuth", filterAuth);
		return this.getSqlSession().selectOne("getRoleAuthSize",map);
	}

	public Set<String> getAuthsByRole(String filterRole) {
		return new HashSet(this.getSqlSession().selectList("getAuthsByRole", filterRole));
	}

	public List<HashMap> getRoleAuths(String filterRole,String filterAuth,int start, int rows) {
		HashMap map = new HashMap();
		if(filterRole!=null&&filterRole.length()>0)
			map.put("filterRole", filterRole);
		if(filterAuth!=null&&filterAuth.length()>0)
			map.put("filterAuth", filterAuth);
		map.put("start", start);
		map.put("rows", rows);
		return this.getSqlSession().selectList("getRoleAuths",map);
	}

	public void addRoleAuth(String rolename, String authname) {
		HashMap map = new HashMap();
		map.put("authname", authname);
		map.put("rolename", rolename);
		this.getSqlSession().insert("addRoleAuth",map);
	}

	public void delRoleAuth(int id) {
		this.getSqlSession().delete("delRoleAuth",id);
		
	}

	public List<HashMap> getDbs(int start, int rows) {
		HashMap map = new HashMap();
		map.put("start", start);
		map.put("rows", rows);
		return this.getSqlSession().selectList("getDbs",map);
	}
	public List<HashMap> getDbs(String env, int start, int rows){
		HashMap map = new HashMap();
		map.put("env", env);
		map.put("start", start);
		map.put("rows", rows);
		return this.getSqlSession().selectList("getDbsWithEnv",map);
	}

	public int getDbSize() {
		return this.getSqlSession().selectOne("getDbSize");
	}

	public void addDB(String dbname, String dbalias) {
		HashMap map = new HashMap();
		map.put("dbname", dbname);
		map.put("dbalias", dbalias);
		this.getSqlSession().insert("addDb",map);
	}

	public void delDb(int id) {
		this.getSqlSession().delete("delDb",id);
		
	}

	public int getDbInstanceSize(int dbid) {
		
		return this.getSqlSession().selectOne("getDbInstanceSize",dbid);
	}

	public List<HashMap> getDbInstances(int dbid, int start, int rows) {
		HashMap map = new HashMap();
		map.put("start", start);
		map.put("rows", rows);
		map.put("dbid", dbid);
		return this.getSqlSession().selectList("getDbInstances",map);
	}

	public HashMap getDbById(int dbid){
		return this.getSqlSession().selectOne("getDbById",dbid);
	}
	public List<HashMap> getDbInsts(int dbid, String env, int start, int rows){
		HashMap map = new HashMap();
		map.put("start", start);
		map.put("rows", rows);
		map.put("dbid", dbid);
		map.put("env", env);
		return this.getSqlSession().selectList("getDbInsts",map);
	}
	
	public List<HashMap> getDbInstancesByName(String env,String dbname){
		HashMap map = new HashMap();
		map.put("dbname", dbname);
		map.put("env", env);
		return this.getSqlSession().selectList("getDbInstsByName",map);
	}
	public void addDbInstance(int dbid, String dbname, String dbalias, String server, int port,String user,String password, String env,
			String master) {
		HashMap map = new HashMap();
		map.put("dbname", dbname);
		map.put("dbalias", dbalias);
		map.put("dbid", dbid);
		map.put("server", server);
		map.put("port", port);
		map.put("user", user);
		map.put("password", password);
		map.put("env", env);
		map.put("master", master);
		 this.getSqlSession().insert("addDbInstance",map);
		
	}

	public void delDbInstance(int dbid, int id) {
		HashMap map = new HashMap();
		map.put("dbid", dbid);
		map.put("id", id);
		this.getSqlSession().delete("delDbInstance",map);
		
	}
	
	public void delDbInstanceWithDbId(int dbid) {
		this.getSqlSession().delete("delDbInstanceWithDbId",dbid);
	}
	
	

	public int getDbKvSize() {
		return this.getSqlSession().selectOne("getDbKvSize");
	}

	public List<HashMap> getDbKvs(int start, int rows) {
		HashMap map = new HashMap();
		map.put("start", start);
		map.put("rows", rows);
		return this.getSqlSession().selectList("getDbKvs",map);
	}

	public List<HashMap> getDbParams(String env, int start, int rows){
		HashMap map = new HashMap();
		map.put("env", env);
		map.put("start", start);
		map.put("rows", rows);
		return this.getSqlSession().selectList("getDbParams",map);
	}
	public void addDbKv(String key, String value, String env) {
		HashMap map = new HashMap();
		map.put("key", key);
		map.put("value", value);
		map.put("env", env);
		 this.getSqlSession().insert("addDbKv",map);
	}

	public void delDbKv(int id) {
		this.getSqlSession().delete("delDbKv",id);
		
	}

	public int getModelKvSize() {
		return this.getSqlSession().selectOne("getModelKvSize");
	}

	public List<HashMap> getModelKvs(String env, String type, int start, int rows) {
		HashMap map = new HashMap();
		map.put("env", env);
		map.put("type", type);
		map.put("start", start);
		map.put("rows", rows);
		return this.getSqlSession().selectList("getModelKvs",map);
	}

	public void addModelKv(String key, String value, String env, String type, String group) {
		HashMap map = new HashMap();
		map.put("key", key);
		map.put("value", value);
		map.put("env", env);
		map.put("type", type);
		map.put("group", group);
		 this.getSqlSession().insert("addModelKv",map);
	}

	public void delModelKv(int id) {
		this.getSqlSession().delete("delModelKv",id);
		
	}

	public int countData(String pool, String group, String env, String data) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("group", group);
		map.put("env", env);
		map.put("data", data);
		return this.getSqlSession().selectOne("countData",map);
	}

	public void addData(String pool, String group, String data, String env, String content, String type,
			String status,String submitby,String approvedby,String publishedby) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("group", group);
		map.put("env", env);
		map.put("data", data);
		map.put("content", content);
		map.put("md5", MD5.getInstance().getMD5String(content));
		map.put("status", status);
		map.put("filetype", type);
		map.put("submitby", submitby);
		map.put("approvedby", approvedby);
		map.put("publishedby", publishedby);
		this.getSqlSession().insert("addData",map);
		
		if(!env.equals("product")){
			String v = this.getVersion(pool, group, env);
			if(v == null)
				this.addVersion(pool, group, env);
			else
				this.updateVersion(pool, group, env);
		}
	}

	public int getConfigSize(String pool,String group, String env,String status) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("group", group);
		map.put("env", env);
		map.put("status", status);
		return this.getSqlSession().selectOne("getConfigSize",map);
	}

	public List<HashMap> getConfigs(String pool,String group, String env,String status, int start, int rows) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("group", group);
		map.put("env", env);
		map.put("status", status);
		map.put("start", start);
		map.put("rows", rows);
		return this.getSqlSession().selectList("getConfigs",map);
	}

	public void delConfig(int id) {
		
		
		HashMap map = this.getConfigById(id);
		String env = (String) map.get("env");
		this.getSqlSession().delete("delConfig",id);
		if(!env.equals("product")){
			String pool = (String) map.get("pool");
			String group = (String) map.get("group");
			String v = this.getVersion(pool, group, env);
			if(v == null)
				this.addVersion(pool, group, env);
			else
				this.updateVersion(pool, group, env);
		}
	}
	
	public HashMap getConfigById(int id){
		return this.getSqlSession().selectOne("getConfigById",id);
	}
	
	public HashMap getHisConfigById(int id){
		return this.getSqlSession().selectOne("getHisConfigById",id);
	}

	public void updateData(String pool, String group, String data, String env, String content, String type,String status,
			String submitby,String approvedby,String publishedby,String oldMd5) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("group", group);
		map.put("env", env);
		map.put("data", data);
		map.put("content", content);
		String md5 = MD5.getInstance().getMD5String(content);
		if(md5.equals(oldMd5))
			return;
		map.put("md5", md5);
		map.put("status", status);
		map.put("filetype", type);
		map.put("submitby", submitby);
		map.put("approvedby", approvedby);
		map.put("publishedby", publishedby);
		if(status == "published"){
			this.getSqlSession().insert("moveDataToHis",map);
			String v = this.getVersion(pool, group, env);
			if(v == null)
				this.addVersion(pool, group, env);
			else
				this.updateVersion(pool, group, env);
		}
		this.getSqlSession().update("updateData",map);
	}
	
	public HashMap getDbInstByName(String dbname, String master, String env){
		HashMap map = new HashMap();
		map.put("dbname", dbname);
		map.put("master", master);
		map.put("env", env);
		return this.getSqlSession().selectOne("getDbInstByName",map);
	}

	public int insertFile(String originalFilename, String fileContent,String fileType) {
		TempFile tf = new TempFile();
		tf.setFilename(originalFilename);
		tf.setData(fileContent);
		tf.setFiletype(fileType);
		this.getSqlSession().insert("insertTempFile",tf);
		return tf.getId();
	}

	public TempFile getTempFile(int fileid) {
		
		return this.getSqlSession().selectOne("getTempFile",fileid);
	}

	public List<HashMap> getAllConfigs(String pool, String group, String env, String status) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("group", group);
		map.put("env", env);
		map.put("status", status);
		return this.getSqlSession().selectList("getAllConfigs",map);
	}

	public HashMap getConfig(String pool, String group, String data, String env, String status) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("group", group);
		map.put("env", env);
		map.put("data", data);
		map.put("status", status);
		return this.getSqlSession().selectOne("getSingleConfig",map);
	}

	public List<HashMap> getHisConfig(String pool, String group, String env, String data) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("group", group);
		map.put("env", env);
		map.put("data", data);
		return this.getSqlSession().selectList("getHisConfig",map);
	}

	public void submitFromIds(String pool, String group, String[] idl,String submitby) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("group", group);
		map.put("ids", idl);
		map.put("submitby", submitby);
		this.getSqlSession().insert("submitFromIds",map);
	}

	public void submitConfig(String pool, String group, String approvedby) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("group", group);
		map.put("approvedby", approvedby);
		this.getSqlSession().update("submitConfigForApprove",map);
	}
	
	public void cancelSubmit(String pool, String group) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("group", group);
		this.getSqlSession().update("cancelSubmit",map);
	}

	public void approveConfig(String pool, String group, String userName) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("group", group);
		map.put("username", userName);
		this.getSqlSession().update("approveConfig",map);
	}

	public void unapproveConfig(String pool, String group, String userName) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("group", group);
		map.put("username", userName);
		this.getSqlSession().update("unapproveConfig",map);
	}

	public void moveConfigs(String pool, String fromGroup, String fromEnv, String toGroup, String toEnv){
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("group", toGroup);
		map.put("fgroup", fromGroup);
		map.put("tgroup", toGroup);
		map.put("status", "published");
		map.put("env", toEnv);
		map.put("fenv", fromEnv);
		map.put("tenv", toEnv);
		this.getSqlSession().insert("moveDatasToHis",map);
		this.getSqlSession().delete("deleteOldConfigs",map);
		this.getSqlSession().insert("copyConfigs",map);
		

		String v = this.getVersion(pool, toGroup, toEnv);
		if(v == null)
			this.addVersion(pool, toGroup, toEnv);
		else
			this.updateVersion(pool, toGroup, toEnv);
	}
	
	public void publishConfig(String pool, String group, String userName) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("group", group);
		map.put("status", "published");
		map.put("env", "product");
		map.put("username", userName);
		
		this.getSqlSession().insert("moveDatasToHis",map);
		this.getSqlSession().delete("deleteOldPublishConfig",map);
		this.getSqlSession().update("publishConfig",map);
		
		String v = this.getVersion(pool, group, "product");
		if(v == null)
			this.addVersion(pool, group, "product");
		else
			this.updateVersion(pool, group, "product");

		// 发布配置文件，同时复制线上配置到待审核
//		this.getSqlSession().insert("copyConfigs",map);
		List<HashMap> confs = this.getConfigs(pool, group, "product", "published", 0, 1000);
		int i = 0;
		String[] ids = new String[confs.size()];
		for (HashMap conf : confs) {
			ids[i] = String.valueOf(conf.get("id"));
			i++;
		}
		this.submitFromIds(pool,group,ids,userName);
	}

	public void returnedConfig(String pool, String group, String userName) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("group", group);
		map.put("username", userName);
		this.getSqlSession().update("returnedConfig",map);
	}

	public List<HashMap> getAllPools() {
		return this.getSqlSession().selectList("getAllPools");
	}

	public int getUserPoolSize(String username) {
		return this.getSqlSession().selectOne("getUserPoolSize",username);
	}

	public List<HashMap> getUserPools(String username, int start, int rows) {
		HashMap map = new HashMap();
		map.put("username", username);
		map.put("start", start);
		map.put("rows", rows);
		return this.getSqlSession().selectList("getUserPools",map);
	}

	public int getAllUserPoolSize(String filterUser,String filterPool) {
		HashMap map = new HashMap();
		if(filterUser != null && filterUser.length()>0)
			map.put("filterUser", filterUser);
		if(filterPool != null && filterPool.length()>0)
			map.put("filterPool", filterPool);
		return this.getSqlSession().selectOne("getAllUserPoolSize",map);
	}

	public List<HashMap> getAllUserPools(String filterUser,String filterPool,int start, int rows) {
		HashMap map = new HashMap();
		if(filterUser != null && filterUser.length()>0)
			map.put("filterUser", filterUser);
		if(filterPool != null && filterPool.length()>0)
			map.put("filterPool", filterPool);
		map.put("start", start);
		map.put("rows", rows);
		return this.getSqlSession().selectList("getAllUserPools",map);
	}

	public void addUserPool(String username, String pool) {
		HashMap map = new HashMap();
		map.put("username", username);
		map.put("pool", pool);
		this.getSqlSession().insert("addUserPool",map);
	}

	public void delUserPool(int id) {
		this.getSqlSession().delete("delUserPool",id);
	}

	public String getVersion(String pool, String group, String env) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("group", group);
		map.put("env", env);
		return this.getSqlSession().selectOne("getVersion",map);
	}

	public void addVersion(String pool, String group, String env) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("group", group);
		map.put("env", env);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String version = sdf.format(new Date());
		map.put("version", version);
		this.getSqlSession().insert("addVersion",map);
	}

	public void updateVersion(String pool, String group, String env) {
		HashMap map = new HashMap();
		map.put("pool", pool);
		map.put("group", group);
		map.put("env", env);
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String version = sdf.format(new Date());
		map.put("version", version);
		this.getSqlSession().update("updateVersion",map);
		
	}

}
