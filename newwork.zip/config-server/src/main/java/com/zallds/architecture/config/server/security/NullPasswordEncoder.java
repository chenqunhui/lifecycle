package com.zallds.architecture.config.server.security;

import org.springframework.security.authentication.encoding.BasePasswordEncoder;

public class NullPasswordEncoder extends BasePasswordEncoder {

	/* (non-Javadoc)
	 * @see org.springframework.security.authentication.encoding.PasswordEncoder#encodePassword(java.lang.String, java.lang.Object)
	 */
	//@Override
	public String encodePassword(String rawPass, Object salt) {
		return null;
	}

	/* (non-Javadoc)
	 * @see org.springframework.security.authentication.encoding.PasswordEncoder#isPasswordValid(java.lang.String, java.lang.String, java.lang.Object)
	 */
	//@Override
	public boolean isPasswordValid(String encPass, String rawPass, Object salt) {
		return true;
	}

}
