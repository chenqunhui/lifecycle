package com.zallds.architecture.config.server.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.access.SecurityConfig;
import org.springframework.security.web.FilterInvocation;
import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.PathMatcher;

import com.zallds.architecture.config.server.dao.ConfigDao;



public class ConfigInvocationSecurityMetadataSource implements FilterInvocationSecurityMetadataSource, InitializingBean {
	private PathMatcher urlMatcher = new AntPathMatcher();
    private static Map<String, Collection<ConfigAttribute>> resourceMap = new HashMap<String, Collection<ConfigAttribute>>();
    private ConfigDao configDao;
	
    public ConfigInvocationSecurityMetadataSource() {
    }

    private void loadResourceDefine() {
    	//Map<String, Collection<String>> results = venusServiceMapper.findAllResourceAuthorities();
    	Map<String, Collection<String>> results = null;
    	if(results == null)
    		return;
    	for(String res : results.keySet()) {
    		Collection<String> roles = results.get(res);
    		Collection<ConfigAttribute> atts = new ArrayList<ConfigAttribute>();
    		for(String role : roles) {
    			atts.add(new SecurityConfig(role));
    		}
    		resourceMap.put(res, atts);
    	}
    }

    // According to a URL, Find out permission configuration of this URL.
    public Collection<ConfigAttribute> getAttributes(Object object)
            throws IllegalArgumentException {
        // guess object is a URL.
        String url = ((FilterInvocation)object).getRequestUrl();
        //System.out.println("***getAttributes***"+url);
        if(resourceMap != null) {
        	Iterator<String> ite = resourceMap.keySet().iterator();
            while (ite.hasNext()) {
                String resURL = ite.next();
                if (urlMatcher.match(resURL, url)) {
                    return resourceMap.get(resURL);
                }
            }
        }
        return null;
    }

    public boolean supports(Class<?> clazz) {
        return true;
    }
    
    public Collection<ConfigAttribute> getAllConfigAttributes() {
        return null;
    }

	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	//@Override
	public void afterPropertiesSet() throws Exception {
		loadResourceDefine();		
	}

	public ConfigDao getConfigDao() {
		return configDao;
	}

	public void setConfigDao(ConfigDao configDao) {
		this.configDao = configDao;
	}

}
