package com.zallds.architecture.config.server.utils;

public class DownloadTools {
	public static String sWorkDir;
	
	private String workDir;
	public String getWorkDir() {
		return workDir;
	}

	public void setWorkDir(String workDir) {
		this.workDir = workDir;
		sWorkDir = workDir;
	}
}
