package com.zallds.architecture.config.property;

import java.beans.PropertyEditor;

import org.springframework.beans.PropertyEditorRegistrar;
import org.springframework.beans.PropertyEditorRegistry;

public class ZalldsPropertyEditorRegistrar implements PropertyEditorRegistrar {

	private PropertyEditor integerPropertyEditor;
	private PropertyEditor longPropertyEditor;
	private PropertyEditor booleanPropertyEditor;
	private PropertyEditor stringPropertyEditor;
	private PropertyEditor floatPropertyEditor;
	private PropertyEditor doublePropertyEditor;
	public void registerCustomEditors(PropertyEditorRegistry peRegistry) {
		peRegistry.registerCustomEditor(java.lang.Integer.class, getIntegerPropertyEditor());
		peRegistry.registerCustomEditor(java.lang.Boolean.class, getBooleanPropertyEditor());
		peRegistry.registerCustomEditor(java.lang.String.class, getStringPropertyEditor());
		peRegistry.registerCustomEditor(java.lang.Long.class, getLongPropertyEditor());
		peRegistry.registerCustomEditor(java.lang.Double.class, getDoublePropertyEditor());
		peRegistry.registerCustomEditor(java.lang.Float.class, getFloatPropertyEditor());
		
	}

	public PropertyEditor getIntegerPropertyEditor() {
		return integerPropertyEditor;
	}
	public void setIntegerPropertyEditor(PropertyEditor integerPropertyEditor) {
		this.integerPropertyEditor = integerPropertyEditor;
	}

	public PropertyEditor getBooleanPropertyEditor() {
		return booleanPropertyEditor;
	}

	public void setBooleanPropertyEditor(PropertyEditor booleanPropertyEditor) {
		this.booleanPropertyEditor = booleanPropertyEditor;
	}

	public PropertyEditor getStringPropertyEditor() {
		return stringPropertyEditor;
	}

	public void setStringPropertyEditor(PropertyEditor stringPropertyEditor) {
		this.stringPropertyEditor = stringPropertyEditor;
	}

	public PropertyEditor getLongPropertyEditor() {
		return longPropertyEditor;
	}

	public void setLongPropertyEditor(PropertyEditor longPropertyEditor) {
		this.longPropertyEditor = longPropertyEditor;
	}

	public PropertyEditor getFloatPropertyEditor() {
		return floatPropertyEditor;
	}

	public void setFloatPropertyEditor(PropertyEditor floatPropertyEditor) {
		this.floatPropertyEditor = floatPropertyEditor;
	}

	public PropertyEditor getDoublePropertyEditor() {
		return doublePropertyEditor;
	}

	public void setDoublePropertyEditor(PropertyEditor doublePropertyEditor) {
		this.doublePropertyEditor = doublePropertyEditor;
	}
}