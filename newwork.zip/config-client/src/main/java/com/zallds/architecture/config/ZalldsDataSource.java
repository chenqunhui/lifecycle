package com.zallds.architecture.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;


import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.alibaba.druid.support.logging.Log;
import com.alibaba.druid.support.logging.LogFactory;
import com.alibaba.druid.support.logging.Resources;
import com.zallds.architecture.config.utils.Encrypter;

public class ZalldsDataSource extends com.alibaba.druid.pool.DruidDataSource implements InitializingBean,ApplicationContextAware,BeanNameAware{
	
	private String beanName;
	private String jdbcUrl;
	public String getBeanName() {
		return beanName;
	}

	public void setBeanName(String beanName) {
		this.beanName = beanName;
	}
	
	//@Override
	public boolean isSingleton() {
		return true;
	}
	
	private static ApplicationContext context;
	public void setApplicationContext(ApplicationContext arg0) throws BeansException {
		this.context = arg0;
	}
	

	private Hashtable<String, String> prop;
	
	public static void waitForInitialized() {
		int waittime = 0;
		Map<String, ZalldsGlobalPropertyConfigurer> configs = context.getBeansOfType(ZalldsGlobalPropertyConfigurer.class,false,false);
		
		while ( waittime < 60000) {
			Iterator iter = configs.keySet().iterator();
			boolean finish = true;
			while(iter.hasNext()){
				String key = (String)iter.next();
				ZalldsGlobalPropertyConfigurer item = configs.get(key);
				if(!item.isInitialized()){
					finish = false;
					break;
				}
			}
			if(finish) break;
			try {
				Thread.sleep(100);
				waittime += 100;
			} catch (InterruptedException e) {
			}
		}
	}

	public void afterPropertiesSet() throws Exception {          
		com.alibaba.druid.support.logging.LogFactory.selectLog4JLogging();
		try{
		waitForInitialized();
		System.out.println(" * Init ZalldsDataSource of ["+ beanName +"]");
		//Thread.sleep(1000);
		//ZalldsGlobalPropertyConfigurer configure = context.getBean(ZalldsGlobalPropertyConfigurer.class);
		Map<String, ZalldsGlobalPropertyConfigurer> configMap = context.getBeansOfType(ZalldsGlobalPropertyConfigurer.class,false,false);
		Iterator iter = configMap.keySet().iterator();
		while(iter.hasNext()){
			String key = (String) iter.next();
			ZalldsGlobalPropertyConfigurer configure = configMap.get(key);
			
			Properties p = configure.getProperties(beanName + ".properties");
			if(p!= null){
				prop = configure.propertiesToHashtable(p);
				initJdbcByProperties(this,prop);
				return;
			}
		}
		}catch(Exception exp){
			
		}
	}

	public void initJdbcByProperties(Object dcBean, Hashtable<String, String> prop) {
		BeanWrapper wdc = new BeanWrapperImpl(dcBean);
		for (Object okey : prop.keySet()) {
			String key = (String) okey;
			if (!key.startsWith("jdbc"))
				continue;

			String propName = key.substring(key.indexOf('.') + 1);
			String propValue = prop.get(key);
			if (propName.equals("password.encrypt")) {
				propName = "password";
				propValue = Encrypter.decrypt(propValue);
			}
			if(propValue != null && !propValue.trim().equals("")){
				try{
					wdc.setPropertyValue(propName, propValue);
				}catch(Exception exp){
					
				}
			}
			if(propName.equals("url")){
				this.jdbcUrl = propValue;
			}
		}
		wdc.setPropertyValue("driverClassName", "com.mysql.jdbc.Driver");
	}
	
	public static Hashtable<String, String> loadProperties(File propFile) {
		if (! propFile.exists())
			throw new RuntimeException("Config file <"+ propFile.getAbsolutePath() +"> doesn't exists.");
		Properties prop = new Properties();
		try {
			InputStream is = new FileInputStream(propFile);
			prop.load(is);
			is.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		
		Hashtable<String, String> result = new Hashtable<String, String>();
		for (Object okey : prop.keySet()) {
			String key = (String)okey;
			String value = prop.getProperty(key);
			result.put(key, value);
		}
		return result;
	}

	public String getJdbcUrl() {
		return jdbcUrl;
	}

	public void setJdbcUrl(String jdbcUrl) {
		this.jdbcUrl = jdbcUrl;
	}
	
	public static void main(String args[]){
		ZalldsDataSource ds = new ZalldsDataSource();
		try {
			ds.afterPropertiesSet();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
