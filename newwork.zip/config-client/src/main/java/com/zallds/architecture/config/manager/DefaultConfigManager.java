package com.zallds.architecture.config.manager;

import java.io.File;
import java.util.Hashtable;

import com.zallds.architecture.config.utils.DownloadUtils;
import com.zallds.architecture.config.utils.FileTool;
import com.zallds.architecture.config.utils.ZipTool;

public class DefaultConfigManager {

	public static ConfigInfo getConfigs(Hashtable<String, String> baseProperty, String poolId,String group, String workGroup, String version, String configs) throws Exception {
		String globalPath = System.getProperty("global.config.path");
		String configPath = globalPath + File.separator +"zallds"+File.separator + "snapshot" +File.separator+ group;
		String localPath = globalPath + File.separator +"zallds"+File.separator + "local" + group;
		File tempDir = new File(globalPath + File.separator +"zallds"+File.separator +"temp");
		if(!tempDir.exists()){
			tempDir.mkdirs();
		}
		ConfigInfo ci = new ConfigInfo();
		String env = baseProperty.get("config.env").trim();
		String configServer = baseProperty.get("config.path").trim();
		String downloadFile = workGroup +"_"+version+".zip";
		String tempPath = globalPath + File.separator +"zallds"+File.separator +"temp";
		String savePath = DownloadUtils.downloadFile(configServer + "/download.do?pool="+poolId+"&group="+workGroup +"&env="+env+"&configs="+ configs, tempPath);
		if(savePath == null)
		{
			return null;
		}
		String newVersion = getFileVersion(savePath);
		if(newVersion.equals("")||newVersion.equals("null")){
			System.out.println(" * There is none properties for pool "+ poolId +" and group "+workGroup+" !!! ");
			FileTool.deleteDirectoryOrFile(tempDir+File.separator+savePath);
			return null;
		} else if(newVersion.equals(version)){
			ci.setVersion(newVersion);
			System.out.println(" * None properties for pool "+ poolId +" has changed!!! ");
		} else {
			ci.setVersion(newVersion);
			System.out.println(" * New version ["+newVersion+"] properties for pool "+poolId+" has been get!!! ");
			// 删除旧配置
		}
		if(env.equals("test")||env.equals("dev")){ // 开发测试环境只删除需要更新的文件
			String configFile[] = configs.split(",");
			for(int i=0;i<configFile.length;i++){
				FileTool.deleteDirectoryOrFile(configPath+File.separator+configFile[i]);
			}
		} else { // stg和线上环境删除整目录
			FileTool.deleteDirectoryOrFile(configPath);
		}
		ZipTool.unzip(configPath, tempDir +File.separator+savePath);
		FileTool.deleteDirectoryOrFile(tempDir+File.separator+savePath);
		return ci;
	}
	
	private static String getFileVersion(String file){
		int pos = file.lastIndexOf("_");
		if(pos >0){
			String fileName = file.substring(pos+1);
			return fileName.substring(0, fileName.length()-4);
		}
		return "";
	}
	
}
