package com.zallds.architecture.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import com.zallds.architecture.config.manager.ConfigInfo;
import com.zallds.architecture.config.manager.DefaultConfigManager;

import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

//public class ZalldsGlobalPropertyConfigurer extends PropertySourcesPlaceholderConfigurer implements InitializingBean, BeanNameAware,ApplicationContextAware{
public class ZalldsGlobalPropertyConfigurer extends PropertyPlaceholderConfigurer implements InitializingBean, BeanNameAware,ApplicationContextAware{

	private static String env;
	
	private Long timeout = 4000l;
	
	private List<String> locations;

	private List<Resource> resources;
	
	private String groupId;

	private boolean envOverride =false;

	private String poolId;
	
	private static List<String> groupIdList = new ArrayList<String>();

	private static String mainGroupId = null;

	private static String mainPoolId = null;

	private volatile boolean initialized = false;
	public boolean isInitialized() {
		return initialized;
	}
	
	private static Map<String,String> filePathMap = new ConcurrentHashMap<String, String>();
	
	private static Map<String, String> overrideGroupIds = new ConcurrentHashMap<String, String>();
	
	private static volatile Map<String, String> snapshopProps = new ConcurrentHashMap<String, String>();

	private static volatile Map<String,Map> propertiesMap = new ConcurrentHashMap<String, Map>();
	
	private Map<String,List> resourceList = new HashMap<String,List>();
	
	private static int initializedTimeout = 60000;
	
	private String beanName;
	
	private boolean mainPool = false;

	public boolean isMainPool() {
		return mainPool;
	}


	public void setMainPool(boolean mainPool) {
		this.mainPool = mainPool;
	}


	private static ApplicationContext applicationContext;
	private boolean showPropertyValue = false;

	public boolean isShowPropertyValue() {
		return showPropertyValue;
	}


	public void setShowPropertyValue(boolean showPropertyValue) {
		this.showPropertyValue = showPropertyValue;
	}


	public void setBeanName(String beanName) {
		this.beanName = beanName;
	}


	public void afterPropertiesSet() throws Exception {
		initialized = false;
		System.out.println("========== ZalldsGlobalPropertyConfigurer init ======== ");
		String globalPath = System.getProperty("global.config.path");
		if (StringUtils.isBlank(globalPath)) {
			globalPath = System.getenv("global.config.path");
			if (StringUtils.isBlank(globalPath)) {
				URL url = ZalldsGlobalPropertyConfigurer.class.getResource("/env.ini");
				if (url != null) {
					globalPath = new File(url.getFile()).getParent();
					System.setProperty("global.config.path", globalPath);
				} else {
					throw new IllegalArgumentException("env.ini is required");
				}
			} else {
				System.setProperty("global.config.path", globalPath);
			}
		}
		
		if (StringUtils.isBlank(poolId)) {
			throw new RuntimeException("the property 'poolId' is required");
		}
		
		groupId = toGroupId(poolId);
		if(this.mainPool)
			mainPoolId = poolId;
		
		File rootEnvFile = new File(globalPath, File.separator+"zallds"+File.separator+"env.ini");
		File envFile = null;
		if (rootEnvFile.exists()) {
			envFile = rootEnvFile;
		}else {
			envFile = new File(globalPath, File.separator+"env.ini");
		}
		
		Hashtable<String, String> baseProperty = null;
		if(envFile != null) {
			baseProperty = loadProperties(envFile);
		}
		
		System.out.println(" * config.path = " + baseProperty.get("config.path"));
		System.out.println(" * config.env  = " + baseProperty.get("config.env"));
		System.out.println(" * poolId      = " + poolId);
		System.out.println(" * groupId     = " + groupId);
		System.out.println(" * mainPool    = " + mainPool);
		
		File poolEnvFile = new File(globalPath, File.separator+"zallds"+File.separator+ "snapshot" + File.separator + "env.ini");
		if(poolEnvFile.exists()){
			snapshopProps = loadProperties(poolEnvFile);
		} else {
			File poolEnvDir = new File(globalPath, File.separator+"zallds"+File.separator+ "snapshot");
			if(!poolEnvDir.exists()){
				try{
					poolEnvDir.mkdirs();
				}catch(Exception exp){}
			}
		}
		
		String version = snapshopProps.get(groupId+".version"); 
		File groupDir = new File(globalPath, File.separator+"zallds"+ File.separator+groupId);
		if(!groupDir.exists()){
			groupDir.mkdirs();
			Hashtable<String, String> prop = new Hashtable<String, String>();
			prop.put("group", groupId);
			saveProperties(prop,globalPath+File.separator+"zallds"+ File.separator+groupId+File.separator+"env.ini");
		}
		File groupEnv = new File(globalPath, File.separator+"zallds"+ File.separator+groupId+File.separator+ "env.ini");
		String workGroup = groupId;
		if(groupEnv.exists()){
			Hashtable<String, String> groupProperty = loadProperties(groupEnv);
			String ownerGroup = baseProperty.get(groupId+".group");
			if(ownerGroup == null || ownerGroup.equals("")){
				ownerGroup = groupProperty.get("group");
				if(ownerGroup!= null&&!ownerGroup.equals("")){
					System.out.println(" * Load properties for group [" + ownerGroup+"]");
					workGroup = ownerGroup;
				}
			} else {
				System.out.println(" * Load properties for group [" + ownerGroup+"]");
				workGroup = ownerGroup;
			}
		} 
		//String workGroup = snapshopProps.get(groupId+".group");
		//if(workGroup == null || workGroup.equals(""))
		//	workGroup = groupId;
		
		StringBuffer files = new StringBuffer();
		for(int i=0;i<locations.size();i++){
			if(i>0)
				files.append(",");
			files.append(locations.get(i));
		}
		
		this.env = baseProperty.get("config.env").trim();
		ConfigInfo configInfo = DefaultConfigManager.getConfigs(baseProperty,poolId,groupId,workGroup,version,files.toString());
		if(configInfo!= null){ // 正确获取了配置
			if(!configInfo.getVersion().equals(version)){
				snapshopProps.put(groupId+".version", configInfo.getVersion());
				saveProperties(snapshopProps,globalPath + File.separator+"zallds"+File.separator+ "snapshot" + File.separator + "env.ini");
			}
			System.out.println(" * Load Properties from Server success");
		} else { // 未正确获取配置
			System.out.println("*** [ERROR] Load Properties from Server failed ***");
			
		}
		
		//locations[i] = new FileSystemResource(globalPath + File.separator + configfileList.get(i));
		
		Map poolProps = new HashMap();
		List<Properties> list = new ArrayList<Properties>();
		resources = new ArrayList<Resource>();
		for(int i=0;i<locations.size();i++){
			String fileName = locations.get(i);
			String file = getLocalConfigPath()+File.separator + fileName;
			File localFile = new File(file);
			if(localFile.exists()){
				
				filePathMap.put(poolId+"/"+fileName, file);
				if(fileName.endsWith(".properties")){
					Properties prop = new Properties();
					try {
						//InputStream is = new FileInputStream(file,"utf-8");
						InputStreamReader isr=new InputStreamReader(new FileInputStream(file),"utf-8");
						prop.load(isr);
						isr.close();
						
						resources.add(new FileSystemResource(file));
					} catch (IOException e) {
						throw new RuntimeException(e);
					}
					poolProps.put(fileName, prop);
					System.out.println(" * Load [" + fileName +"] from [local]["+poolId+"]["+workGroup+"]");
					list.add(prop);
				}
			} else {
				file = getConfigPath()+File.separator + fileName;
				File snapFile = new File(file);
				if(snapFile.exists()){
					filePathMap.put(poolId+"/"+fileName, file);
					if(fileName.endsWith(".properties")){
						Properties prop = new Properties();
						try {
							InputStreamReader isr=new InputStreamReader(new FileInputStream(file),"utf-8");
							prop.load(isr);
							isr.close();
							
							resources.add(new FileSystemResource(file));
						} catch (IOException e) {
							throw new RuntimeException(e);
						}
						poolProps.put(fileName, prop);
						System.out.println(" * Load [" + fileName +"] from [snapshot]["+poolId+"]["+workGroup+"]");
						list.add(prop);
					}
				} else {
					filePathMap.put(poolId+"/"+fileName, "");
					System.out.println("*** [ERROR] None [" + fileName +"] in [local] and [snapshot] ***");
				}
			}
		}
		
		this.propertiesMap.put(groupId, poolProps);
		
		
		Properties[] properties_local = new Properties[list.size()];
		for(int i=0;i<list.size();i++){
			properties_local[i] = list.get(i);
		}
		Resource[] resourceArray = new Resource[resources.size()];
		for(int i=0;i<resources.size();i++){
			resourceArray[i] = resources.get(i);
		}
		//super.setPropertiesArray(properties_local);
		super.setLocations(resourceArray);
		initialized = true;
		
		resourceList.put(groupId, resources);
		if(applicationContext!= null){
			Map<String, ZalldsGlobalPropertyConfigurer> configs = applicationContext.getBeansOfType(ZalldsGlobalPropertyConfigurer.class,false,false);
			if(configs.size() >1){
				Iterator<String> iter = configs.keySet().iterator();
				while(iter.hasNext()){
					String key = iter.next();
					ZalldsGlobalPropertyConfigurer config = configs.get(key);
					config.initProperties(groupId,resources);
				}
			}
		}
		
		if(mainPool){
			String log4jPath = filePathMap.get(poolId+"/"+"log4j.properties");
			if(log4jPath!=null && !log4jPath.isEmpty()){
				PropertyConfigurator.configureAndWatch(log4jPath, 60000);  
			}
		}
	}
	
	public void initProperties(String group,List<Resource> properties){
		if(!resourceList.containsKey(group)){
			resourceList.put(group, properties);
		}
		
		List<Resource> allProps = new ArrayList<Resource>();
		
		Iterator iter = resourceList.keySet().iterator();
		while(iter.hasNext()){
			String key = (String) iter.next();
			List<Resource> list = resourceList.get(key);
			allProps.addAll(list);
		}
		Resource[] pl = new Resource[allProps.size()];
		for(int i=0;i<allProps.size();i++){
			pl[i] = allProps.get(i);
		}
		if(showPropertyValue){
			/*
			for(int i=0;i<allProps.size();i++){
				Properties prop = allProps.get(i);
				Hashtable<String, String> map = propertiesToHashtable(prop);
				Iterator iter1 = map.keySet().iterator();
				while(iter1.hasNext()){
					String key = (String) iter1.next();
					String value = map.get(key);
					System.out.println(" * Key["+key+"] Value["+value+"]");
				}
			}*/
		}
		//System.out.println(" * "+ beanName +" setPropertiesArray :" + pl.length);
		//super.setPropertiesArray(pl);
		super.setLocations(pl);
	}
	
	private void saveProperties(Map<String, String> snapshopProps, String path) {
		Properties prop = new Properties();
		java.util.Iterator<String> iter = snapshopProps.keySet().iterator();
		while(iter.hasNext()){
			String key = iter.next();
			prop.setProperty(key, snapshopProps.get(key));
		}
		//File file = new File(path);
		FileOutputStream fOut;
		try {
			fOut = new FileOutputStream(path);
			prop.store(fOut, null);
			fOut.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	public static Hashtable<String, String> loadProperties(File propFile) {
		if (!propFile.exists())
			throw new RuntimeException("Config file <" + propFile.getAbsolutePath() + "> doesn't exists.");
		Properties prop = new Properties();
		try {
			InputStreamReader isr=new InputStreamReader(new FileInputStream(propFile),"utf-8");
			//InputStream is = new FileInputStream(propFile,"UTF-8");
			prop.load(isr);
			isr.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		Hashtable<String, String> result = new Hashtable<String, String>();
		for (Object okey : prop.keySet()) {
			String key = (String) okey;
			String value = prop.getProperty(key);
			result.put(key, value);
		}
		return result;
	}

	public static Hashtable<String, String> loadProperties(String properties) {
		Properties prop = new Properties();
		if (properties != null) {
			try {
				prop.load(new StringReader(properties));
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
		Hashtable<String, String> result = new Hashtable<String, String>();
		for (Object okey : prop.keySet()) {
			String key = (String) okey;
			String value = prop.getProperty(key);
			result.put(key, value);
		}
		return result;
	}
	
	/**
	 * 等待初始化完成
	 */
	public static void waitForInitialized() {
		int waittime = 0;
		Map<String, ZalldsGlobalPropertyConfigurer> configs = applicationContext.getBeansOfType(ZalldsGlobalPropertyConfigurer.class,false,false);
		
		while ( waittime < initializedTimeout) {
			Iterator iter = configs.keySet().iterator();
			boolean finish = true;
			while(iter.hasNext()){
				String key = (String)iter.next();
				ZalldsGlobalPropertyConfigurer item = configs.get(key);
				if(!item.initialized){
					finish = false;
					break;
				}
			}
			if(finish) break;
			try {
				Thread.sleep(100);
				waittime += 100;
			} catch (InterruptedException e) {
			}
		}
	}
	
	
	private static void addGroupId(String poolId, String groupId, boolean envOverride) {
		if (mainPoolId == null && envOverride) {
			mainPoolId = poolId;
		}
		if (mainGroupId == null && envOverride) {
			mainGroupId = groupId;
		}
		if (!groupIdList.contains(groupId)) {
			groupIdList.add(groupId);
		}
		if (!overrideGroupIds.containsKey(toGroupId(poolId))) {
			overrideGroupIds.put(toGroupId(poolId), groupId);
		}
	}
	
	public Properties getProperties(String filename){
		waitForInitialized();
		Map map = this.propertiesMap.get(this.groupId);
		if(map == null)
			return null;
		return (Properties) map.get(filename);
	}
	
	public static Hashtable<String, String> propertiesToHashtable(Properties prop) {
		if (prop == null) {
			return new Hashtable<String,String>();
		}
		Hashtable<String, String> result = new Hashtable<String, String>();
		for (Object okey : prop.keySet()) {
			String key = (String) okey;
			String value = prop.getProperty(key);
			result.put(key, value);
		}
		return result;
	}
	
	public String getProperty(String key){
		waitForInitialized();
		Iterator iter = propertiesMap.keySet().iterator();
		while(iter.hasNext()){
			String gname = (String) iter.next();
			Map map = propertiesMap.get(gname);
			Iterator iter1 = map.keySet().iterator();
			while(iter1.hasNext()){
				String pname = (String) iter1.next();
				Map pMap = (Map) map.get(pname);
				if(pMap.get(key) != null){
					return pMap.get(key).toString();
				}
			}
			
		}
		return "";
	}
	public static Properties getProperties(String groupId,String filename){
		waitForInitialized();
		Map map = propertiesMap.get(groupId);
		if(map == null)
			return null;
		return (Properties) map.get(filename);
	}

	public static String getMainPoolId() {
		waitForInitialized();
		return mainPoolId;
	}

	public static String getMainGroupId() {
		waitForInitialized();
		return mainGroupId;
	}

	public static List<String> getGroupIdList() {
		waitForInitialized();
		return groupIdList;
	}
	public String getConfigPath() {
		String dirPath = System.getProperty("global.config.path") + File.separator + "zallds" + File.separator + "snapshot" + File.separator + groupId;
		if (StringUtils.isNotBlank(dirPath))
			return dirPath;
		else
			return System.getProperty("user.home");
	}

	public String getLocalConfigPath() {
		String dirPath = System.getProperty("global.config.path") + File.separator + "zallds" + File.separator + "local" + File.separator + groupId;
		if (StringUtils.isNotBlank(dirPath))
			return dirPath;
		else
			return System.getProperty("user.home");
	}

	public List<String> getLocations() {
		return locations;
	}

	public void setLocations(List<String> locations) {
		this.locations = locations;
	}

	public String getPoolId() {
		return poolId;
	}

	public void setPoolId(String poolId) {
		this.poolId = poolId;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	
	private static String toGroupId(String poolId) {
		if (StringUtils.isBlank(poolId)) {
			return "";
		}
		String poolIdReturn = poolId;
		if (poolId.indexOf("/") != -1) {
			poolIdReturn = poolId.replaceAll("\\/", "_");// 可以支持pool全称
		}
		return poolIdReturn.trim();
	}
	
	


	public static String getEnv() {
		return env;
	}


	private String[] parseLocation(String location) {
		int idx = location.lastIndexOf("}");
		if (idx != -1) {
			location = location.substring(idx + 1);
			idx = location.lastIndexOf("/");
			if (idx != -1) {
				location = location.substring(idx + 1);
			}
			idx = location.lastIndexOf("\\");
			if (idx != -1) {
				location = location.substring(idx + 1);
			}
			return new String[] { groupId, location };
		}
		idx = location.lastIndexOf(":");
		if (idx != -1) {
			location = location.substring(idx + 1);
			idx = location.lastIndexOf("/");
			if (idx != -1) {
				location = location.substring(idx + 1);
			}
			idx = location.lastIndexOf("\\");
			if (idx != -1) {
				location = location.substring(idx + 1);
			}
			return new String[] { groupId, location };
		}
		idx = location.lastIndexOf("/");
		/*
		if (idx != -1) {
			if (locationOverride) {
				return null;
			}
			String groupId = location.substring(0, idx);
			String dataId = location.substring(idx + 1);

			return new String[] { toGroupId(groupId), dataId };
		}
		idx = location.lastIndexOf("\\");
		if (idx != -1) {
			if (locationOverride) {
				return null;
			}
			String groupId = location.substring(0, idx);
			String dataId = location.substring(idx + 1);

			return new String[] { toGroupId(groupId), dataId };
		}*/

		return new String[] { groupId, location };
	}
	
	public static void setEnv(String env) {
		ZalldsGlobalPropertyConfigurer.env = env;
	}
	
	public static void main(String args[]){
		ZalldsGlobalPropertyConfigurer zpc = new ZalldsGlobalPropertyConfigurer();
		zpc.setPoolId("zallpay/pay-backend");
		
		List locations = new ArrayList();

		locations.add("dubbo.properties");
		locations.add("pay_gateway_master.properties");
		locations.add("zallgo_front_slave.properties");
		locations.add("zallgo_merchant_slave.properties");
		locations.add("zallgo_order_slave.properties");
		locations.add("zallgo_user_slave.properties");
		locations.add("redis.properties");
		locations.add("config-backend.properties");
		locations.add("env.properties");


		
		zpc.setLocations(locations);
		System.setProperty("global.config.path","/Users/zhengchen/Documents/Projects/Config");
		try {
			zpc.afterPropertiesSet();
		} catch (Exception e) {
			e.printStackTrace();
		}
		String path =zpc.getPropertyPath("zallpay/pay-backend", "dubbo.properties");
		System.out.println("server");
	}

	public static String getPropertyPath(String pool,String fileName){
		return (String)(filePathMap.get(pool+"/"+fileName));
	}
	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext= applicationContext;
		
	}
}
