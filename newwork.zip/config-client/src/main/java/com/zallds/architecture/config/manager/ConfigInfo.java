package com.zallds.architecture.config.manager;

import java.util.List;
import java.util.Map;
import java.util.Properties;

public class ConfigInfo {
	private String version;
	
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}

}
