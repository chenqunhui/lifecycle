package com.zallds.architecture.config.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreConnectionPNames;

public class DownloadUtils {
	public static String downloadFile(String httpUrl,String path){
		
		try{
			HttpClient client = new DefaultHttpClient();
			HttpGet httpget = new HttpGet(httpUrl);
			// 请求超时
            client.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 10000);
            // 读取超时
            client.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, 20000);
            
			HttpResponse response = client.execute(httpget);
			
			if(response.getStatusLine().getStatusCode() != 200){
				return null;
			}
			Header[]  headers = response.getHeaders("Content-Disposition");
			String saveFile="";
			for(int i=0;i<headers.length;i++){
				String value = headers[i].getValue();
				int pos = value.indexOf("fileName=");
				if(pos >0)
					saveFile = value.substring(pos +9);
			}
			HttpEntity entity = response.getEntity();
			InputStream is = entity.getContent();
			File file = new File(path +File.separator+saveFile);
			FileOutputStream fileout = new FileOutputStream(file);
			byte[] buffer = new byte[10*1024];
			int ch = 0;
			while((ch= is.read(buffer)) !=-1){
				fileout.write(buffer, 0, ch);
			}
			is.close();
			fileout.flush();
			fileout.close();
			
		
			return saveFile;
		}catch(Exception exp){
			return null;
		}
		
	}
}
