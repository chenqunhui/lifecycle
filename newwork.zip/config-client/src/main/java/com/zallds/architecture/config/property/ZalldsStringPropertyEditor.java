package com.zallds.architecture.config.property;

import java.beans.PropertyEditorSupport;
import java.util.Map;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.zallds.architecture.config.ZalldsGlobalPropertyConfigurer;

public class ZalldsStringPropertyEditor extends PropertyEditorSupport 
implements ApplicationContextAware{

	private ApplicationContext context;
	public void setAsText(String text) throws IllegalArgumentException {  
		//System.out.println("setAsText"+text);
		Map<String, ZalldsGlobalPropertyConfigurer> configMap = context.getBeansOfType(ZalldsGlobalPropertyConfigurer.class);
		ZalldsGlobalPropertyConfigurer configurer = configMap.values().iterator().next();
		if(text.startsWith("${"))
		{
			text = text.substring(2,text.length()-1);
			String value = configurer.getProperty(text);
			this.setValue(value);
		} else {
			
			this.setValue(text);
		}
	
	}
	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		context = applicationContext;
		
	}  
}
